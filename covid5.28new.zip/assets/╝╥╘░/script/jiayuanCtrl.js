// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        newsPanel:cc.Node,
        ourMessage:cc.Node,
        webBox:cc.WebView,
        now:0,
        news:0,
        nowLabel:cc.Label,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.news=["https://ncov.dxy.cn/ncovh5/view/pneumonia"];
        this.newsTitle=["丁香园疫情实况"];
        this.now=0;
        this.webBox.url=this.news[this.now];
        this.nowLabel.string=this.newsTitle[this.now];
    },

    previousNews(){
        if(this.now==0){
            this.nowLabel.string="前面没有了哦";
        }
        else{
            this.now-=1;
            this.webBox.url=this.news[this.now];
            this.nowLabel.string=this.newsTitle[this.now];
        }
        
    },

    nextNews(){
        if(this.now==this.news.length-1){
            this.nowLabel.string="后面没有了哦";
        }
        else{
            this.now+=1;
            this.webBox.url=this.news[this.now];
            this.nowLabel.string=this.newsTitle[this.now];
        }
    },

    openNews(){
        this.newsPanel.active=true;
    },

    closeNews(){
        this.newsPanel.active=false;
    },

    openMessage(){
        this.ourMessage.active=true;
    },
    closeMessage(){
        this.ourMessage.active=false;
    },

    returnBack(){
        cc.director.loadScene("衔接场景");
    }
    // update (dt) {},
});
