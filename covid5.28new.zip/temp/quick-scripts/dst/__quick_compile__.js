
(function () {
var scripts = [{"deps":{"./assets/个人防护/scripts/UIcontrol":2,"./assets/个人防护/scripts/closestoolJS":10,"./assets/个人防护/scripts/informationJS":16,"./assets/个人防护/scripts/judgeFailOrSucceed":14,"./assets/个人防护/scripts/gamePlayer":61,"./assets/个人防护/scripts/handWashingSinkJS":17,"./assets/个人防护/scripts/neighborJS":15,"./assets/个人防护/scripts/oppositeOnceJS":23,"./assets/个人防护/scripts/oppositeTwiceJS":18,"./assets/个人防护/scripts/neighborMoveJS":19,"./assets/个人防护/scripts/propTool":20,"./assets/个人防护/scripts/npc":62,"./assets/个人防护/scripts/sameOnceJS":21,"./assets/个人防护/scripts/showPossibility":25,"./assets/个人防护/scripts/sameTwiceJS":22,"./assets/个人防护/scripts/showTime":26,"./assets/个人防护/scripts/AudioMgr":27,"./assets/个人防护/scripts/buttonConfirmJS":60,"./assets/人体免疫/scripts/antiviral":24,"./assets/人体免疫/scripts/bianxing":28,"./assets/人体免疫/scripts/biaoji":30,"./assets/人体免疫/scripts/bozhong":4,"./assets/人体免疫/scripts/gameControl":29,"./assets/人体免疫/scripts/fashe":31,"./assets/人体免疫/scripts/huohua":33,"./assets/人体免疫/scripts/jingong":1,"./assets/人体免疫/scripts/juxing":32,"./assets/人体免疫/scripts/jujue":5,"./assets/人体免疫/scripts/ningju":34,"./assets/人体免疫/scripts/qiehuan":35,"./assets/人体免疫/scripts/piao":6,"./assets/人体免疫/scripts/showCoolingTime":36,"./assets/人体免疫/scripts/sun":37,"./assets/人体免疫/scripts/zou":7,"./assets/人体免疫/scripts/showDeadNormalCell":38,"./assets/人体免疫/scripts/tujian":44,"./assets/人体免疫/scripts/TCytotoxicCell":41,"./assets/人体免疫/scripts/THelperCell":42,"./assets/家园/script/jiayuanCtrl":8,"./assets/疫苗研制/script/y_pcrMachine":39,"./assets/疫苗研制/script/y_itemControl":9,"./assets/疫苗研制/script/y_liejieControl":43,"./assets/疫苗研制/script/y_safeBox":40,"./assets/疫苗研制/script/y_thawControl":50,"./assets/疫苗研制/script/y_zhendangyi":54,"./assets/疫苗研制/script/y_thawSecond":51,"./assets/疫苗研制/script/y_sceneController":47,"./assets/疫苗研制/script/y_fencengControl":56,"./assets/疫苗研制/script/y_item":57,"./assets/社区防疫/scripts/s_map":45,"./assets/社区防疫/scripts/s_placeTemplate":46,"./assets/社区防疫/scripts/s_office":49,"./assets/社区防疫/scripts/s_store":48,"./assets/社区防疫/scripts/s_globalParameter":3,"./assets/社区防疫/结算页/s_jiesuan":13,"./assets/社区防疫/scripts/s_hospital":52,"./assets/衔接场景/scripts/tempJs":11,"./assets/衔接场景/scripts/yidao":55,"./assets/谣言破除/script/r_globalStage":58,"./assets/谣言破除/script/r_contentCtrl":12,"./assets/谣言破除/script/r_bar":53,"./assets/个人防护/scripts/conveyInformation":59},"path":"preview-scripts/__qc_index__.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/jingong.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/UIcontrol.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_globalParameter.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/bozhong.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/jujue.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/piao.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/zou.js"},{"deps":{},"path":"preview-scripts/assets/家园/script/jiayuanCtrl.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_itemControl.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/closestoolJS.js"},{"deps":{},"path":"preview-scripts/assets/衔接场景/scripts/tempJs.js"},{"deps":{},"path":"preview-scripts/assets/谣言破除/script/r_contentCtrl.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/结算页/s_jiesuan.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/judgeFailOrSucceed.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/neighborJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/informationJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/handWashingSinkJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/oppositeTwiceJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/neighborMoveJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/propTool.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/sameOnceJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/sameTwiceJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/oppositeOnceJS.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/antiviral.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/showPossibility.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/showTime.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/AudioMgr.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/bianxing.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/gameControl.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/biaoji.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/fashe.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/juxing.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/huohua.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/ningju.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/qiehuan.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/showCoolingTime.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/sun.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/showDeadNormalCell.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_pcrMachine.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_safeBox.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/TCytotoxicCell.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/THelperCell.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_liejieControl.js"},{"deps":{},"path":"preview-scripts/assets/人体免疫/scripts/tujian.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_map.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_placeTemplate.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_sceneController.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_store.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_office.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_thawControl.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_thawSecond.js"},{"deps":{},"path":"preview-scripts/assets/社区防疫/scripts/s_hospital.js"},{"deps":{},"path":"preview-scripts/assets/谣言破除/script/r_bar.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_zhendangyi.js"},{"deps":{},"path":"preview-scripts/assets/衔接场景/scripts/yidao.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_fencengControl.js"},{"deps":{},"path":"preview-scripts/assets/疫苗研制/script/y_item.js"},{"deps":{},"path":"preview-scripts/assets/谣言破除/script/r_globalStage.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/conveyInformation.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/buttonConfirmJS.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/gamePlayer.js"},{"deps":{},"path":"preview-scripts/assets/个人防护/scripts/npc.js"}];
var entries = ["preview-scripts/__qc_index__.js"];

/**
 * Notice: This file can not use ES6 (for IE 11)
 */
var modules = {};
var name2path = {};

if (typeof global === 'undefined') {
    window.global = window;
}

function loadScript (src, cb) {
    if (typeof require !== 'undefined') {
        require(src);
        return cb();
    }

    // var timer = 'load ' + src;
    // console.time(timer);

    var scriptElement = document.createElement('script');

    function done() {
        // console.timeEnd(timer);
        // deallocation immediate whatever
        scriptElement.remove();
    }

    scriptElement.onload = function () {
        done();
        cb();
    };
    scriptElement.onerror = function () {
        done();
        var error = 'Failed to load ' + src;
        console.error(error);
        cb(new Error(error));
    };
    scriptElement.setAttribute('type','text/javascript');
    scriptElement.setAttribute('charset', 'utf-8');
    scriptElement.setAttribute('src', src);

    document.head.appendChild(scriptElement);
}

function loadScripts (srcs, cb) {
    var n = srcs.length;

    srcs.forEach(function (src) {
        loadScript(src, function () {
            n--;
            if (n === 0) {
                cb();
            }
        });
    })
}

function formatPath (path) {
    let destPath = window.__quick_compile_project__.destPath;
    if (destPath) {
        let prefix = 'preview-scripts';
        if (destPath[destPath.length - 1] === '/') {
            prefix += '/';
        }
        path = path.replace(prefix, destPath);
    }
    return path;
}

window.__quick_compile_project__ = {
    destPath: '',

    registerModule: function (path, module) {
        path = formatPath(path);
        modules[path].module = module;
    },

    registerModuleFunc: function (path, func) {
        path = formatPath(path);
        modules[path].func = func;

        var sections = path.split('/');
        var name = sections[sections.length - 1];
        name = name.replace(/\.(?:js|ts|json)$/i, '');
        name2path[name] = path;
    },

    require: function (request, path) {
        var m, requestScript;

        path = formatPath(path);
        if (path) {
            m = modules[path];
            if (!m) {
                console.warn('Can not find module for path : ' + path);
                return null;
            }
        }

        if (m) {
            requestScript = scripts[ m.deps[request] ];
        }
        
        path = '';
        if (!requestScript) {
            // search from name2path when request is a dynamic module name
            if (/^[\w- .]*$/.test(request)) {
                path = name2path[request];
            }

            if (!path) {
                if (CC_JSB) {
                    return require(request);
                }
                else {
                    console.warn('Can not find deps [' + request + '] for path : ' + path);
                    return null;
                }
            }
        }
        else {
            path = formatPath(requestScript.path);
        }

        m = modules[path];
        
        if (!m) {
            console.warn('Can not find module for path : ' + path);
            return null;
        }

        if (!m.module && m.func) {
            m.func();
        }

        if (!m.module) {
            console.warn('Can not find module.module for path : ' + path);
            return null;
        }

        return m.module.exports;
    },

    run: function () {
        entries.forEach(function (entry) {
            entry = formatPath(entry);
            var module = modules[entry];
            if (!module.module) {
                module.func();
            }
        });
    },

    load: function (cb) {
        var self = this;

        var srcs = scripts.map(function (script) {
            var path = formatPath(script.path);
            modules[path] = script;
        
            if (script.mtime) {
                path += ("?mtime=" + script.mtime);
            }
        
            return path;
        });

        loadScripts(srcs, function () {
            self.run();
            cb();
        });
    }
};

// Polyfill for IE 11
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function () {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
})();
    