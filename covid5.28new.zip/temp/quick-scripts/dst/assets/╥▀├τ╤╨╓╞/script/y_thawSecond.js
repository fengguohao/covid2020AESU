
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_thawSecond.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9f599/qav1CSZxOCkVT1Oi8', 'y_thawSecond');
// 疫苗研制/script/y_thawSecond.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    safeBox: cc.Node,
    itemLayOut: cc.Node,
    afterChange: cc.SpriteFrame,
    sceneControl: cc.Node,
    showTimeLabel: cc.Label,
    successClip: {
      "default": null,
      type: cc.AudioClip
    },
    timeProcessClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.itemLayOut = this.itemLayOut.getComponent("y_itemControl");
    this.sceneControl = this.sceneControl.getComponent("y_sceneController");
  },
  putFinished: function putFinished(box) {
    cc.audioEngine.playEffect(this.successClip, false);
    console.log("完成放置");
    box.node.destroy();
    this.safeBox.getComponent(cc.Sprite).spriteFrame = this.afterChange;
    this.safeBox.width = 330;
    this.safeBox.height = 200;
    this.tempTime = 30;
    cc.audioEngine.playEffect(this.timeProcessClip, false);
    this.scheduleOnce(function () {
      cc.audioEngine.playEffect(this.timeProcessClip, false);
    }.bind(this), 5);
    this.schedule(function () {
      this.showTimeLabel.string = this.tempTime + "分钟";
      this.sceneControl.changeSidePrompt("解冻还需\n" + this.tempTime + "\n分钟\n请耐心等待");
      this.tempTime -= 1;
      console.log("success");
    }.bind(this), 0.33, 30, 1);
    this.scheduleOnce(function () {
      this.sceneControl.changeSidePrompt("解冻完成\n获得物品\n病毒样品\n裂解液\n移液管\n微离心管");
      this.showTimeLabel.string = "";
      this.sceneControl.changeStage(2);
      console.log('this.itemLayOut.node.getChildren() :>> ', this.itemLayOut.node.getChildren());
    }.bind(this), 11.5);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfdGhhd1NlY29uZC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNhZmVCb3giLCJOb2RlIiwiaXRlbUxheU91dCIsImFmdGVyQ2hhbmdlIiwiU3ByaXRlRnJhbWUiLCJzY2VuZUNvbnRyb2wiLCJzaG93VGltZUxhYmVsIiwiTGFiZWwiLCJzdWNjZXNzQ2xpcCIsInR5cGUiLCJBdWRpb0NsaXAiLCJ0aW1lUHJvY2Vzc0NsaXAiLCJzdGFydCIsImdldENvbXBvbmVudCIsInB1dEZpbmlzaGVkIiwiYm94IiwiYXVkaW9FbmdpbmUiLCJwbGF5RWZmZWN0IiwiY29uc29sZSIsImxvZyIsIm5vZGUiLCJkZXN0cm95IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJ3aWR0aCIsImhlaWdodCIsInRlbXBUaW1lIiwic2NoZWR1bGVPbmNlIiwiYmluZCIsInNjaGVkdWxlIiwic3RyaW5nIiwiY2hhbmdlU2lkZVByb21wdCIsImNoYW5nZVN0YWdlIiwiZ2V0Q2hpbGRyZW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxPQUFPLEVBQUNKLEVBQUUsQ0FBQ0ssSUFESDtBQUVSQyxJQUFBQSxVQUFVLEVBQUNOLEVBQUUsQ0FBQ0ssSUFGTjtBQUdSRSxJQUFBQSxXQUFXLEVBQUNQLEVBQUUsQ0FBQ1EsV0FIUDtBQUlSQyxJQUFBQSxZQUFZLEVBQUNULEVBQUUsQ0FBQ0ssSUFKUjtBQUtSSyxJQUFBQSxhQUFhLEVBQUNWLEVBQUUsQ0FBQ1csS0FMVDtBQU1SQyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUSxJQURBO0FBRVJDLE1BQUFBLElBQUksRUFBQ2IsRUFBRSxDQUFDYztBQUZBLEtBTko7QUFVUkMsSUFBQUEsZUFBZSxFQUFDO0FBQ1osaUJBQVEsSUFESTtBQUVaRixNQUFBQSxJQUFJLEVBQUNiLEVBQUUsQ0FBQ2M7QUFGSTtBQVZSLEdBSFA7QUFtQkw7QUFFQTtBQUVBRSxFQUFBQSxLQXZCSyxtQkF1Qkk7QUFDTCxTQUFLVixVQUFMLEdBQWdCLEtBQUtBLFVBQUwsQ0FBZ0JXLFlBQWhCLENBQTZCLGVBQTdCLENBQWhCO0FBQ0EsU0FBS1IsWUFBTCxHQUFrQixLQUFLQSxZQUFMLENBQWtCUSxZQUFsQixDQUErQixtQkFBL0IsQ0FBbEI7QUFDSCxHQTFCSTtBQTRCTEMsRUFBQUEsV0E1QkssdUJBNEJPQyxHQTVCUCxFQTRCVztBQUNabkIsSUFBQUEsRUFBRSxDQUFDb0IsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtULFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0FVLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQUosSUFBQUEsR0FBRyxDQUFDSyxJQUFKLENBQVNDLE9BQVQ7QUFDQSxTQUFLckIsT0FBTCxDQUFhYSxZQUFiLENBQTBCakIsRUFBRSxDQUFDMEIsTUFBN0IsRUFBcUNDLFdBQXJDLEdBQWlELEtBQUtwQixXQUF0RDtBQUNBLFNBQUtILE9BQUwsQ0FBYXdCLEtBQWIsR0FBbUIsR0FBbkI7QUFDQSxTQUFLeEIsT0FBTCxDQUFheUIsTUFBYixHQUFvQixHQUFwQjtBQUNBLFNBQUtDLFFBQUwsR0FBYyxFQUFkO0FBQ0E5QixJQUFBQSxFQUFFLENBQUNvQixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS04sZUFBL0IsRUFBK0MsS0FBL0M7QUFDQSxTQUFLZ0IsWUFBTCxDQUFrQixZQUFVO0FBQ3hCL0IsTUFBQUEsRUFBRSxDQUFDb0IsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtOLGVBQS9CLEVBQStDLEtBQS9DO0FBQ0gsS0FGaUIsQ0FFaEJpQixJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYSxDQUZiO0FBR0EsU0FBS0MsUUFBTCxDQUFjLFlBQVU7QUFDcEIsV0FBS3ZCLGFBQUwsQ0FBbUJ3QixNQUFuQixHQUEwQixLQUFLSixRQUFMLEdBQWMsSUFBeEM7QUFDQSxXQUFLckIsWUFBTCxDQUFrQjBCLGdCQUFsQixDQUFtQyxXQUFTLEtBQUtMLFFBQWQsR0FBdUIsYUFBMUQ7QUFDQSxXQUFLQSxRQUFMLElBQWUsQ0FBZjtBQUNBUixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0gsS0FMYSxDQUtaUyxJQUxZLENBS1AsSUFMTyxDQUFkLEVBS2EsSUFMYixFQUtrQixFQUxsQixFQUtxQixDQUxyQjtBQU1BLFNBQUtELFlBQUwsQ0FBa0IsWUFBVTtBQUN4QixXQUFLdEIsWUFBTCxDQUFrQjBCLGdCQUFsQixDQUFtQyxrQ0FBbkM7QUFDQSxXQUFLekIsYUFBTCxDQUFtQndCLE1BQW5CLEdBQTBCLEVBQTFCO0FBQ0EsV0FBS3pCLFlBQUwsQ0FBa0IyQixXQUFsQixDQUE4QixDQUE5QjtBQUNBZCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx5Q0FBWixFQUF1RCxLQUFLakIsVUFBTCxDQUFnQmtCLElBQWhCLENBQXFCYSxXQUFyQixFQUF2RDtBQUVILEtBTmlCLENBTWhCTCxJQU5nQixDQU1YLElBTlcsQ0FBbEIsRUFNYSxJQU5iO0FBT0gsR0FyREksQ0F3REw7O0FBeERLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzYWZlQm94OmNjLk5vZGUsXHJcbiAgICAgICAgaXRlbUxheU91dDpjYy5Ob2RlLFxyXG4gICAgICAgIGFmdGVyQ2hhbmdlOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIHNjZW5lQ29udHJvbDpjYy5Ob2RlLFxyXG4gICAgICAgIHNob3dUaW1lTGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgc3VjY2Vzc0NsaXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfSxcclxuICAgICAgICB0aW1lUHJvY2Vzc0NsaXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuaXRlbUxheU91dD10aGlzLml0ZW1MYXlPdXQuZ2V0Q29tcG9uZW50KFwieV9pdGVtQ29udHJvbFwiKTtcclxuICAgICAgICB0aGlzLnNjZW5lQ29udHJvbD10aGlzLnNjZW5lQ29udHJvbC5nZXRDb21wb25lbnQoXCJ5X3NjZW5lQ29udHJvbGxlclwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgcHV0RmluaXNoZWQoYm94KXtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5a6M5oiQ5pS+572uXCIpO1xyXG4gICAgICAgIGJveC5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICB0aGlzLnNhZmVCb3guZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9dGhpcy5hZnRlckNoYW5nZTtcclxuICAgICAgICB0aGlzLnNhZmVCb3gud2lkdGg9MzMwO1xyXG4gICAgICAgIHRoaXMuc2FmZUJveC5oZWlnaHQ9MjAwO1xyXG4gICAgICAgIHRoaXMudGVtcFRpbWU9MzA7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnRpbWVQcm9jZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnRpbWVQcm9jZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLDUpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5zaG93VGltZUxhYmVsLnN0cmluZz10aGlzLnRlbXBUaW1lK1wi5YiG6ZKfXCI7XHJcbiAgICAgICAgICAgIHRoaXMuc2NlbmVDb250cm9sLmNoYW5nZVNpZGVQcm9tcHQoXCLop6Plhrvov5jpnIBcXG5cIit0aGlzLnRlbXBUaW1lK1wiXFxu5YiG6ZKfXFxu6K+36ICQ5b+D562J5b6FXCIpO1xyXG4gICAgICAgICAgICB0aGlzLnRlbXBUaW1lLT0xO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInN1Y2Nlc3NcIik7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLDAuMzMsMzAsMSk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgdGhpcy5zY2VuZUNvbnRyb2wuY2hhbmdlU2lkZVByb21wdChcIuino+WGu+WujOaIkFxcbuiOt+W+l+eJqeWTgVxcbueXheavkuagt+WTgVxcbuijguino+a2slxcbuenu+a2sueuoVxcbuW+ruemu+W/g+euoVwiKTtcclxuICAgICAgICAgICAgdGhpcy5zaG93VGltZUxhYmVsLnN0cmluZz1cIlwiO1xyXG4gICAgICAgICAgICB0aGlzLnNjZW5lQ29udHJvbC5jaGFuZ2VTdGFnZSgyKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuaXRlbUxheU91dC5ub2RlLmdldENoaWxkcmVuKCkgOj4+ICcsIHRoaXMuaXRlbUxheU91dC5ub2RlLmdldENoaWxkcmVuKCkpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9LmJpbmQodGhpcyksMTEuNSk7XHJcbiAgICB9LFxyXG5cclxuICAgIFxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=