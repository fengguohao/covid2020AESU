
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_item.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8139a7bUKZGBprPLElLDW6J', 'y_item');
// 疫苗研制/script/y_item.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    movable: false,
    defaultParent: cc.Node,
    defaultPos: null,
    stageNode: cc.Node,
    startLoc: null,
    lastMove: null,
    onBump: 0,
    moveOutClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.defaultParent = this.node.parent;
    this.defaultPos = this.node.getPosition();
  },
  callBindEvent: function callBindEvent() {
    this.node.on(cc.Node.EventType.TOUCH_START, function () {
      cc.audioEngine.playEffect(this.moveOutClip, false);
      this.node.opacity = 255;

      if (this.node.parent == this.defaultParent) {
        console.log('this.stageNode :>> ', this.stageNode);
        this.startLoc = this.stageNode.convertToNodeSpaceAR(this.node.parent.convertToWorldSpaceAR(this.node.getPosition()));
        this.node.parent = this.stageNode;
        this.node.setPosition(this.startLoc);
        this.lastMove = this.startLoc;
      } else {
        this.startLoc = this.node.getPosition();
        this.lastMove = this.startLoc;
      }
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, function (event) {
      var pos = this.stageNode.convertToNodeSpaceAR(event.getTouches()[0].getLocation());
      this.node.setPosition(this.node.getPosition().add(pos.sub(this.lastMove)));
      this.lastMove = pos;
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_END, function (event) {
      if (this.onBump == 1) {
        this.node.parent = this.defaultParent;
        this.node.setPosition(this.defaultPos);
        this.lastMove = null;
        this.startLoc = null;
      } else {
        this.lastMove = null;
        this.startLoc = null;
      }
    }, this);
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log(this.node.parent.name);

    if (this.node.parent.name == "裂解") {
      this.node.parent.getComponent("y_liejieControl").moveProcess(self.node, other.node);
    }

    if (this.node.parent.name == "分层") {
      this.node.parent.getComponent("y_fencengControl").moveProcess(self.node, other.node);
    }

    this.onBump = other.tag;
    console.log(this.onBump);
  },
  onCollisionExit: function onCollisionExit() {
    this.onBump = 0;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfaXRlbS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm1vdmFibGUiLCJkZWZhdWx0UGFyZW50IiwiTm9kZSIsImRlZmF1bHRQb3MiLCJzdGFnZU5vZGUiLCJzdGFydExvYyIsImxhc3RNb3ZlIiwib25CdW1wIiwibW92ZU91dENsaXAiLCJ0eXBlIiwiQXVkaW9DbGlwIiwic3RhcnQiLCJub2RlIiwicGFyZW50IiwiZ2V0UG9zaXRpb24iLCJjYWxsQmluZEV2ZW50Iiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImF1ZGlvRW5naW5lIiwicGxheUVmZmVjdCIsIm9wYWNpdHkiLCJjb25zb2xlIiwibG9nIiwiY29udmVydFRvTm9kZVNwYWNlQVIiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJzZXRQb3NpdGlvbiIsIlRPVUNIX01PVkUiLCJldmVudCIsInBvcyIsImdldFRvdWNoZXMiLCJnZXRMb2NhdGlvbiIsImFkZCIsInN1YiIsIlRPVUNIX0VORCIsIm9uQ29sbGlzaW9uRW50ZXIiLCJvdGhlciIsInNlbGYiLCJuYW1lIiwiZ2V0Q29tcG9uZW50IiwibW92ZVByb2Nlc3MiLCJ0YWciLCJvbkNvbGxpc2lvbkV4aXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxPQUFPLEVBQUMsS0FEQTtBQUVSQyxJQUFBQSxhQUFhLEVBQUNMLEVBQUUsQ0FBQ00sSUFGVDtBQUdSQyxJQUFBQSxVQUFVLEVBQUMsSUFISDtBQUlSQyxJQUFBQSxTQUFTLEVBQUNSLEVBQUUsQ0FBQ00sSUFKTDtBQUtSRyxJQUFBQSxRQUFRLEVBQUMsSUFMRDtBQU1SQyxJQUFBQSxRQUFRLEVBQUMsSUFORDtBQU9SQyxJQUFBQSxNQUFNLEVBQUMsQ0FQQztBQVFSQyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUSxJQURBO0FBRVJDLE1BQUFBLElBQUksRUFBQ2IsRUFBRSxDQUFDYztBQUZBO0FBUkosR0FIUDtBQWlCTDtBQUVBO0FBRUFDLEVBQUFBLEtBckJLLG1CQXFCSTtBQUNQLFNBQUtWLGFBQUwsR0FBbUIsS0FBS1csSUFBTCxDQUFVQyxNQUE3QjtBQUNBLFNBQUtWLFVBQUwsR0FBZ0IsS0FBS1MsSUFBTCxDQUFVRSxXQUFWLEVBQWhCO0FBQ0QsR0F4Qkk7QUEyQkxDLEVBQUFBLGFBM0JLLDJCQTJCVTtBQUNYLFNBQUtILElBQUwsQ0FBVUksRUFBVixDQUFhcEIsRUFBRSxDQUFDTSxJQUFILENBQVFlLFNBQVIsQ0FBa0JDLFdBQS9CLEVBQTJDLFlBQVU7QUFDakR0QixNQUFBQSxFQUFFLENBQUN1QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS1osV0FBL0IsRUFBMkMsS0FBM0M7QUFDQSxXQUFLSSxJQUFMLENBQVVTLE9BQVYsR0FBa0IsR0FBbEI7O0FBQ0EsVUFBRyxLQUFLVCxJQUFMLENBQVVDLE1BQVYsSUFBa0IsS0FBS1osYUFBMUIsRUFBd0M7QUFDcENxQixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQyxLQUFLbkIsU0FBeEM7QUFDQSxhQUFLQyxRQUFMLEdBQWMsS0FBS0QsU0FBTCxDQUFlb0Isb0JBQWYsQ0FBb0MsS0FBS1osSUFBTCxDQUFVQyxNQUFWLENBQWlCWSxxQkFBakIsQ0FBdUMsS0FBS2IsSUFBTCxDQUFVRSxXQUFWLEVBQXZDLENBQXBDLENBQWQ7QUFDQSxhQUFLRixJQUFMLENBQVVDLE1BQVYsR0FBaUIsS0FBS1QsU0FBdEI7QUFDQSxhQUFLUSxJQUFMLENBQVVjLFdBQVYsQ0FBc0IsS0FBS3JCLFFBQTNCO0FBQ0EsYUFBS0MsUUFBTCxHQUFjLEtBQUtELFFBQW5CO0FBRUgsT0FQRCxNQVFJO0FBQ0EsYUFBS0EsUUFBTCxHQUFjLEtBQUtPLElBQUwsQ0FBVUUsV0FBVixFQUFkO0FBQ0EsYUFBS1IsUUFBTCxHQUFjLEtBQUtELFFBQW5CO0FBQ0g7QUFFSixLQWhCRCxFQWdCRSxJQWhCRjtBQWtCQSxTQUFLTyxJQUFMLENBQVVJLEVBQVYsQ0FBYXBCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRZSxTQUFSLENBQWtCVSxVQUEvQixFQUEwQyxVQUFTQyxLQUFULEVBQWU7QUFDckQsVUFBSUMsR0FBRyxHQUFDLEtBQUt6QixTQUFMLENBQWVvQixvQkFBZixDQUFvQ0ksS0FBSyxDQUFDRSxVQUFOLEdBQW1CLENBQW5CLEVBQXNCQyxXQUF0QixFQUFwQyxDQUFSO0FBQ0EsV0FBS25CLElBQUwsQ0FBVWMsV0FBVixDQUFzQixLQUFLZCxJQUFMLENBQVVFLFdBQVYsR0FBd0JrQixHQUF4QixDQUE0QkgsR0FBRyxDQUFDSSxHQUFKLENBQVEsS0FBSzNCLFFBQWIsQ0FBNUIsQ0FBdEI7QUFDQSxXQUFLQSxRQUFMLEdBQWN1QixHQUFkO0FBQ0gsS0FKRCxFQUlFLElBSkY7QUFNQSxTQUFLakIsSUFBTCxDQUFVSSxFQUFWLENBQWFwQixFQUFFLENBQUNNLElBQUgsQ0FBUWUsU0FBUixDQUFrQmlCLFNBQS9CLEVBQXlDLFVBQVNOLEtBQVQsRUFBZTtBQUNwRCxVQUFHLEtBQUtyQixNQUFMLElBQWEsQ0FBaEIsRUFBa0I7QUFDZCxhQUFLSyxJQUFMLENBQVVDLE1BQVYsR0FBaUIsS0FBS1osYUFBdEI7QUFDQSxhQUFLVyxJQUFMLENBQVVjLFdBQVYsQ0FBc0IsS0FBS3ZCLFVBQTNCO0FBQ0EsYUFBS0csUUFBTCxHQUFjLElBQWQ7QUFDQSxhQUFLRCxRQUFMLEdBQWMsSUFBZDtBQUNILE9BTEQsTUFNSTtBQUNBLGFBQUtDLFFBQUwsR0FBYyxJQUFkO0FBQ0EsYUFBS0QsUUFBTCxHQUFjLElBQWQ7QUFDSDtBQUNKLEtBWEQsRUFXRSxJQVhGO0FBWUgsR0FoRUk7QUFtRUw4QixFQUFBQSxnQkFBZ0IsRUFBRSwwQkFBVUMsS0FBVixFQUFpQkMsSUFBakIsRUFBdUI7QUFDckNmLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUtYLElBQUwsQ0FBVUMsTUFBVixDQUFpQnlCLElBQTdCOztBQUNBLFFBQUcsS0FBSzFCLElBQUwsQ0FBVUMsTUFBVixDQUFpQnlCLElBQWpCLElBQXVCLElBQTFCLEVBQStCO0FBQzNCLFdBQUsxQixJQUFMLENBQVVDLE1BQVYsQ0FBaUIwQixZQUFqQixDQUE4QixpQkFBOUIsRUFBaURDLFdBQWpELENBQTZESCxJQUFJLENBQUN6QixJQUFsRSxFQUF1RXdCLEtBQUssQ0FBQ3hCLElBQTdFO0FBQ0g7O0FBQ0QsUUFBRyxLQUFLQSxJQUFMLENBQVVDLE1BQVYsQ0FBaUJ5QixJQUFqQixJQUF1QixJQUExQixFQUErQjtBQUMzQixXQUFLMUIsSUFBTCxDQUFVQyxNQUFWLENBQWlCMEIsWUFBakIsQ0FBOEIsa0JBQTlCLEVBQWtEQyxXQUFsRCxDQUE4REgsSUFBSSxDQUFDekIsSUFBbkUsRUFBd0V3QixLQUFLLENBQUN4QixJQUE5RTtBQUNIOztBQUNBLFNBQUtMLE1BQUwsR0FBWTZCLEtBQUssQ0FBQ0ssR0FBbEI7QUFDQW5CLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUtoQixNQUFqQjtBQUVILEdBOUVHO0FBK0VMbUMsRUFBQUEsZUFBZSxFQUFFLDJCQUFXO0FBQ3ZCLFNBQUtuQyxNQUFMLEdBQVksQ0FBWjtBQUNILEdBakZHLENBa0ZMOztBQWxGSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgbW92YWJsZTpmYWxzZSxcclxuICAgICAgICBkZWZhdWx0UGFyZW50OmNjLk5vZGUsXHJcbiAgICAgICAgZGVmYXVsdFBvczpudWxsLFxyXG4gICAgICAgIHN0YWdlTm9kZTpjYy5Ob2RlLFxyXG4gICAgICAgIHN0YXJ0TG9jOm51bGwsXHJcbiAgICAgICAgbGFzdE1vdmU6bnVsbCxcclxuICAgICAgICBvbkJ1bXA6MCxcclxuICAgICAgICBtb3ZlT3V0Q2xpcDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5BdWRpb0NsaXBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgIHRoaXMuZGVmYXVsdFBhcmVudD10aGlzLm5vZGUucGFyZW50OyAgXHJcbiAgICAgIHRoaXMuZGVmYXVsdFBvcz10aGlzLm5vZGUuZ2V0UG9zaXRpb24oKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIGNhbGxCaW5kRXZlbnQoKXtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLm1vdmVPdXRDbGlwLGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHk9MjU1O1xyXG4gICAgICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50PT10aGlzLmRlZmF1bHRQYXJlbnQpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuc3RhZ2VOb2RlIDo+PiAnLCB0aGlzLnN0YWdlTm9kZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXJ0TG9jPXRoaXMuc3RhZ2VOb2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMubm9kZS5wYXJlbnQuY29udmVydFRvV29ybGRTcGFjZUFSKHRoaXMubm9kZS5nZXRQb3NpdGlvbigpKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50PXRoaXMuc3RhZ2VOb2RlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKHRoaXMuc3RhcnRMb2MpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sYXN0TW92ZT10aGlzLnN0YXJ0TG9jO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydExvYz10aGlzLm5vZGUuZ2V0UG9zaXRpb24oKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubGFzdE1vdmU9dGhpcy5zdGFydExvYztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9LHRoaXMpXHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLGZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICAgICAgdmFyIHBvcz10aGlzLnN0YWdlTm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihldmVudC5nZXRUb3VjaGVzKClbMF0uZ2V0TG9jYXRpb24oKSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLm5vZGUuZ2V0UG9zaXRpb24oKS5hZGQocG9zLnN1Yih0aGlzLmxhc3RNb3ZlKSkpO1xyXG4gICAgICAgICAgICB0aGlzLmxhc3RNb3ZlPXBvcztcclxuICAgICAgICB9LHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKGV2ZW50KXtcclxuICAgICAgICAgICAgaWYodGhpcy5vbkJ1bXA9PTEpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudD10aGlzLmRlZmF1bHRQYXJlbnQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5kZWZhdWx0UG9zKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubGFzdE1vdmU9bnVsbDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3RhcnRMb2M9bnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sYXN0TW92ZT1udWxsO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdGFydExvYz1udWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSx0aGlzKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXI6IGZ1bmN0aW9uIChvdGhlciwgc2VsZikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHRoaXMubm9kZS5wYXJlbnQubmFtZSk7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5uYW1lPT1cIuijguino1wiKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudC5nZXRDb21wb25lbnQoXCJ5X2xpZWppZUNvbnRyb2xcIikubW92ZVByb2Nlc3Moc2VsZi5ub2RlLG90aGVyLm5vZGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50Lm5hbWU9PVwi5YiG5bGCXCIpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENvbXBvbmVudChcInlfZmVuY2VuZ0NvbnRyb2xcIikubW92ZVByb2Nlc3Moc2VsZi5ub2RlLG90aGVyLm5vZGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAgdGhpcy5vbkJ1bXA9b3RoZXIudGFnO1xyXG4gICAgICAgICBjb25zb2xlLmxvZyh0aGlzLm9uQnVtcCk7XHJcblxyXG4gICAgIH0sXHJcbiAgICBvbkNvbGxpc2lvbkV4aXQ6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICB0aGlzLm9uQnVtcD0wO1xyXG4gICAgIH0sXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==