
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_thawControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b487amrp8BBYpHHflq2cFJs', 'y_thawControl');
// 疫苗研制/script/y_thawControl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    stage: 0,
    thawButton: cc.Node,
    beforeThaw: cc.Node,
    afterThaw: cc.Node,
    yangpinBox: cc.Node,
    itemLayOut: cc.Node,
    itemAdd: cc.Prefab,
    sceneControl: cc.Node,
    successClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    //stage 0:未开始操作  1:解冻开启
    this.stage = 0;
    this.itemLayOut = this.itemLayOut.getComponent("y_itemControl");
    this.sceneControl = this.sceneControl.getComponent("y_sceneController");
  },
  thawButtonOnClick: function thawButtonOnClick() {
    cc.audioEngine.playEffect(this.successClip, false);
    this.sceneControl.changeSidePrompt("操作的时候\n注意防护哦，\n不要冻伤自己，\n同时不要让病毒泄露哦");
    this.thawButton.getComponent(cc.Button).interactable = false;
    this.stage = 1;
    var delayTime = 0.8;
    var fadeAction = cc.fadeOut(delayTime);
    this.beforeThaw.runAction(fadeAction);
    this.scheduleOnce(function () {
      this.beforeThaw.active = false;
      this.afterThaw.active = true;
      var seq = cc.sequence(cc.fadeIn(1), cc.moveBy(1, -120, 0));
      this.afterThaw.runAction(seq);
      this.yangpinBox.active = true;
      this.yangpinBox.runAction(cc.sequence(cc.fadeIn(1), cc.moveBy(1, 130, 0)));
      this.scheduleOnce(function () {
        this.itemLayOut.add(this.yangpinBox, "样品毒株", [this.beforeThaw, this.afterThaw], 0.5);
        this.scheduleOnce(function () {
          this.sceneControl.changeStage(1);
        }.bind(this), 3.2); // this.scheduleOnce(function(){
        //     this.yangpinBox.runAction(cc.scaleBy(1,0.5));
        //      this.itemLayOut.addItem();
        //      this.yangpinBox.runAction(cc.moveTo(1,this.itemLayOut.getFinalLoc(this.node)));
        //      this.scheduleOnce(function(){
        //         this.itemLayOut.showItem(this.afterThaw.getComponent(cc.Sprite).spriteFrame); 
        //         this.yangpinBox.destroy();
        //      }.bind(this),2);
        // }.bind(this),1);
      }.bind(this), 2);
    }.bind(this), delayTime + 0.02);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfdGhhd0NvbnRyb2wuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFnZSIsInRoYXdCdXR0b24iLCJOb2RlIiwiYmVmb3JlVGhhdyIsImFmdGVyVGhhdyIsInlhbmdwaW5Cb3giLCJpdGVtTGF5T3V0IiwiaXRlbUFkZCIsIlByZWZhYiIsInNjZW5lQ29udHJvbCIsInN1Y2Nlc3NDbGlwIiwidHlwZSIsIkF1ZGlvQ2xpcCIsInN0YXJ0IiwiZ2V0Q29tcG9uZW50IiwidGhhd0J1dHRvbk9uQ2xpY2siLCJhdWRpb0VuZ2luZSIsInBsYXlFZmZlY3QiLCJjaGFuZ2VTaWRlUHJvbXB0IiwiQnV0dG9uIiwiaW50ZXJhY3RhYmxlIiwiZGVsYXlUaW1lIiwiZmFkZUFjdGlvbiIsImZhZGVPdXQiLCJydW5BY3Rpb24iLCJzY2hlZHVsZU9uY2UiLCJhY3RpdmUiLCJzZXEiLCJzZXF1ZW5jZSIsImZhZGVJbiIsIm1vdmVCeSIsImFkZCIsImNoYW5nZVN0YWdlIiwiYmluZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBQyxDQURFO0FBRVJDLElBQUFBLFVBQVUsRUFBQ0wsRUFBRSxDQUFDTSxJQUZOO0FBR1JDLElBQUFBLFVBQVUsRUFBQ1AsRUFBRSxDQUFDTSxJQUhOO0FBSVJFLElBQUFBLFNBQVMsRUFBQ1IsRUFBRSxDQUFDTSxJQUpMO0FBS1JHLElBQUFBLFVBQVUsRUFBQ1QsRUFBRSxDQUFDTSxJQUxOO0FBTVJJLElBQUFBLFVBQVUsRUFBQ1YsRUFBRSxDQUFDTSxJQU5OO0FBT1JLLElBQUFBLE9BQU8sRUFBQ1gsRUFBRSxDQUFDWSxNQVBIO0FBUVJDLElBQUFBLFlBQVksRUFBQ2IsRUFBRSxDQUFDTSxJQVJSO0FBU1JRLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUkMsTUFBQUEsSUFBSSxFQUFDZixFQUFFLENBQUNnQjtBQUZBO0FBVEosR0FIUDtBQW1CTDtBQUVBO0FBRUFDLEVBQUFBLEtBdkJLLG1CQXVCSTtBQUNMO0FBQ0EsU0FBS2IsS0FBTCxHQUFXLENBQVg7QUFDQSxTQUFLTSxVQUFMLEdBQWdCLEtBQUtBLFVBQUwsQ0FBZ0JRLFlBQWhCLENBQTZCLGVBQTdCLENBQWhCO0FBQ0EsU0FBS0wsWUFBTCxHQUFrQixLQUFLQSxZQUFMLENBQWtCSyxZQUFsQixDQUErQixtQkFBL0IsQ0FBbEI7QUFDSCxHQTVCSTtBQWdDTEMsRUFBQUEsaUJBaENLLCtCQWdDYztBQUNmbkIsSUFBQUEsRUFBRSxDQUFDb0IsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtQLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0EsU0FBS0QsWUFBTCxDQUFrQlMsZ0JBQWxCLENBQW1DLG9DQUFuQztBQUNBLFNBQUtqQixVQUFMLENBQWdCYSxZQUFoQixDQUE2QmxCLEVBQUUsQ0FBQ3VCLE1BQWhDLEVBQXdDQyxZQUF4QyxHQUFxRCxLQUFyRDtBQUNBLFNBQUtwQixLQUFMLEdBQVcsQ0FBWDtBQUNBLFFBQUlxQixTQUFTLEdBQUMsR0FBZDtBQUNBLFFBQUlDLFVBQVUsR0FBQzFCLEVBQUUsQ0FBQzJCLE9BQUgsQ0FBV0YsU0FBWCxDQUFmO0FBQ0EsU0FBS2xCLFVBQUwsQ0FBZ0JxQixTQUFoQixDQUEwQkYsVUFBMUI7QUFFQSxTQUFLRyxZQUFMLENBQWtCLFlBQVU7QUFDeEIsV0FBS3RCLFVBQUwsQ0FBZ0J1QixNQUFoQixHQUF1QixLQUF2QjtBQUNBLFdBQUt0QixTQUFMLENBQWVzQixNQUFmLEdBQXNCLElBQXRCO0FBQ0EsVUFBSUMsR0FBRyxHQUFDL0IsRUFBRSxDQUFDZ0MsUUFBSCxDQUFZaEMsRUFBRSxDQUFDaUMsTUFBSCxDQUFVLENBQVYsQ0FBWixFQUF5QmpDLEVBQUUsQ0FBQ2tDLE1BQUgsQ0FBVSxDQUFWLEVBQVksQ0FBQyxHQUFiLEVBQWlCLENBQWpCLENBQXpCLENBQVI7QUFDQSxXQUFLMUIsU0FBTCxDQUFlb0IsU0FBZixDQUF5QkcsR0FBekI7QUFDQSxXQUFLdEIsVUFBTCxDQUFnQnFCLE1BQWhCLEdBQXVCLElBQXZCO0FBQ0EsV0FBS3JCLFVBQUwsQ0FBZ0JtQixTQUFoQixDQUEwQjVCLEVBQUUsQ0FBQ2dDLFFBQUgsQ0FBWWhDLEVBQUUsQ0FBQ2lDLE1BQUgsQ0FBVSxDQUFWLENBQVosRUFBeUJqQyxFQUFFLENBQUNrQyxNQUFILENBQVUsQ0FBVixFQUFZLEdBQVosRUFBZ0IsQ0FBaEIsQ0FBekIsQ0FBMUI7QUFDQSxXQUFLTCxZQUFMLENBQWtCLFlBQVU7QUFFdkIsYUFBS25CLFVBQUwsQ0FBZ0J5QixHQUFoQixDQUFvQixLQUFLMUIsVUFBekIsRUFBb0MsTUFBcEMsRUFBMkMsQ0FBQyxLQUFLRixVQUFOLEVBQWlCLEtBQUtDLFNBQXRCLENBQTNDLEVBQTRFLEdBQTVFO0FBQ0EsYUFBS3FCLFlBQUwsQ0FBa0IsWUFBVTtBQUN6QixlQUFLaEIsWUFBTCxDQUFrQnVCLFdBQWxCLENBQThCLENBQTlCO0FBQ0YsU0FGaUIsQ0FFaEJDLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVhLEdBRmIsRUFIdUIsQ0FNeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUgsT0FoQmlCLENBZ0JoQkEsSUFoQmdCLENBZ0JYLElBaEJXLENBQWxCLEVBZ0JhLENBaEJiO0FBa0JILEtBekJpQixDQXlCaEJBLElBekJnQixDQXlCWCxJQXpCVyxDQUFsQixFQXlCYVosU0FBUyxHQUFDLElBekJ2QjtBQTJCSCxHQXBFSSxDQXdFTDs7QUF4RUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHN0YWdlOjAsXHJcbiAgICAgICAgdGhhd0J1dHRvbjpjYy5Ob2RlLFxyXG4gICAgICAgIGJlZm9yZVRoYXc6Y2MuTm9kZSxcclxuICAgICAgICBhZnRlclRoYXc6Y2MuTm9kZSxcclxuICAgICAgICB5YW5ncGluQm94OmNjLk5vZGUsXHJcbiAgICAgICAgaXRlbUxheU91dDpjYy5Ob2RlLFxyXG4gICAgICAgIGl0ZW1BZGQ6Y2MuUHJlZmFiLFxyXG4gICAgICAgIHNjZW5lQ29udHJvbDpjYy5Ob2RlLFxyXG4gICAgICAgIHN1Y2Nlc3NDbGlwOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgLy9zdGFnZSAwOuacquW8gOWni+aTjeS9nCAgMTrop6PlhrvlvIDlkK9cclxuICAgICAgICB0aGlzLnN0YWdlPTA7XHJcbiAgICAgICAgdGhpcy5pdGVtTGF5T3V0PXRoaXMuaXRlbUxheU91dC5nZXRDb21wb25lbnQoXCJ5X2l0ZW1Db250cm9sXCIpO1xyXG4gICAgICAgIHRoaXMuc2NlbmVDb250cm9sPXRoaXMuc2NlbmVDb250cm9sLmdldENvbXBvbmVudChcInlfc2NlbmVDb250cm9sbGVyXCIpO1xyXG4gICAgfSxcclxuXHJcblxyXG5cclxuICAgIHRoYXdCdXR0b25PbkNsaWNrKCl7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnN1Y2Nlc3NDbGlwLGZhbHNlKTtcclxuICAgICAgICB0aGlzLnNjZW5lQ29udHJvbC5jaGFuZ2VTaWRlUHJvbXB0KFwi5pON5L2c55qE5pe25YCZXFxu5rOo5oSP6Ziy5oqk5ZOm77yMXFxu5LiN6KaB5Ya75Lyk6Ieq5bex77yMXFxu5ZCM5pe25LiN6KaB6K6p55eF5q+S5rOE6Zyy5ZOmXCIpO1xyXG4gICAgICAgIHRoaXMudGhhd0J1dHRvbi5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGU9ZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zdGFnZT0xO1xyXG4gICAgICAgIHZhciBkZWxheVRpbWU9MC44O1xyXG4gICAgICAgIHZhciBmYWRlQWN0aW9uPWNjLmZhZGVPdXQoZGVsYXlUaW1lKTtcclxuICAgICAgICB0aGlzLmJlZm9yZVRoYXcucnVuQWN0aW9uKGZhZGVBY3Rpb24pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIHRoaXMuYmVmb3JlVGhhdy5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuYWZ0ZXJUaGF3LmFjdGl2ZT10cnVlO1xyXG4gICAgICAgICAgICB2YXIgc2VxPWNjLnNlcXVlbmNlKGNjLmZhZGVJbigxKSxjYy5tb3ZlQnkoMSwtMTIwLDApKTtcclxuICAgICAgICAgICAgdGhpcy5hZnRlclRoYXcucnVuQWN0aW9uKHNlcSk7XHJcbiAgICAgICAgICAgIHRoaXMueWFuZ3BpbkJveC5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy55YW5ncGluQm94LnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShjYy5mYWRlSW4oMSksY2MubW92ZUJ5KDEsMTMwLDApKSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LmFkZCh0aGlzLnlhbmdwaW5Cb3gsXCLmoLflk4Hmr5LmoKpcIixbdGhpcy5iZWZvcmVUaGF3LHRoaXMuYWZ0ZXJUaGF3XSwwLjUpO1xyXG4gICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2VuZUNvbnRyb2wuY2hhbmdlU3RhZ2UoMSk7XHJcbiAgICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDMuMik7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgLy8gICAgIHRoaXMueWFuZ3BpbkJveC5ydW5BY3Rpb24oY2Muc2NhbGVCeSgxLDAuNSkpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICB0aGlzLml0ZW1MYXlPdXQuYWRkSXRlbSgpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICB0aGlzLnlhbmdwaW5Cb3gucnVuQWN0aW9uKGNjLm1vdmVUbygxLHRoaXMuaXRlbUxheU91dC5nZXRGaW5hbExvYyh0aGlzLm5vZGUpKSk7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zaG93SXRlbSh0aGlzLmFmdGVyVGhhdy5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSk7IFxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICB0aGlzLnlhbmdwaW5Cb3guZGVzdHJveSgpO1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICB9LmJpbmQodGhpcyksMik7XHJcbiAgICAgICAgICAgICAgICAvLyB9LmJpbmQodGhpcyksMSk7XHJcblxyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksMik7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH0uYmluZCh0aGlzKSxkZWxheVRpbWUrMC4wMik7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=