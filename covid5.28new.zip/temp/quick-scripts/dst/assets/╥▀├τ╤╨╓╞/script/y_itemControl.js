
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_itemControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5f628KJkoFO5pEPO18hny5+', 'y_itemControl');
// 疫苗研制/script/y_itemControl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    itemAdd: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  getNode: function getNode(name) {
    return this.node.getChildByName(name);
  },
  addItem: function addItem() {
    var tPrefab = cc.instantiate(this.itemAdd);
    tPrefab.parent = this.node;
  },
  getFinalLoc: function getFinalLoc(node) {
    var loc = node.convertToNodeSpaceAR(this.node.convertToWorldSpaceAR(this.node.getChildren()[this.node.getChildren().length - 1].getPosition()));
    return loc;
  },
  showItem: function showItem(frame, name) {
    this.node.getChildren()[this.node.getChildren().length - 1].getComponent(cc.Sprite).spriteFrame = frame;
    this.node.getChildren()[this.node.getChildren().length - 1].getChildByName("label").getComponent(cc.Label).string = name;
    this.node.getChildren()[this.node.getChildren().length - 1].name = name;
    console.log('this.node.getChildren() ', this.node.getChildren());
  },
  setParent: function setParent(name, sceneNode) {
    console.log(this.node.getChildren());
    console.log(this.node.getChildByName(name), name);
    this.node.getChildByName(name).getComponent("y_item").stageNode = sceneNode;
  },
  setMovable: function setMovable(name) {
    this.node.getChildByName(name).getComponent("y_item").callBindEvent();
  },
  add: function add(itemNode, name, destroyList, scale) {
    this.scheduleOnce(function () {
      itemNode.runAction(cc.scaleBy(1, scale));
      this.addItem();
      itemNode.runAction(cc.moveTo(1, this.getFinalLoc(itemNode.parent)));
      this.scheduleOnce(function () {
        this.showItem(itemNode.getComponent(cc.Sprite).spriteFrame, name);
        itemNode.destroy();

        for (var i = 0; i < destroyList.length; i++) {
          destroyList[i].destroy();
        }
      }.bind(this), 2);
    }.bind(this), 1);
  },
  normalAdd: function normalAdd(spriteFramePic, name) {
    this.addItem();
    this.showItem(spriteFramePic, name);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfaXRlbUNvbnRyb2wuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpdGVtQWRkIiwiUHJlZmFiIiwic3RhcnQiLCJnZXROb2RlIiwibmFtZSIsIm5vZGUiLCJnZXRDaGlsZEJ5TmFtZSIsImFkZEl0ZW0iLCJ0UHJlZmFiIiwiaW5zdGFudGlhdGUiLCJwYXJlbnQiLCJnZXRGaW5hbExvYyIsImxvYyIsImNvbnZlcnRUb05vZGVTcGFjZUFSIiwiY29udmVydFRvV29ybGRTcGFjZUFSIiwiZ2V0Q2hpbGRyZW4iLCJsZW5ndGgiLCJnZXRQb3NpdGlvbiIsInNob3dJdGVtIiwiZnJhbWUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsIkxhYmVsIiwic3RyaW5nIiwiY29uc29sZSIsImxvZyIsInNldFBhcmVudCIsInNjZW5lTm9kZSIsInN0YWdlTm9kZSIsInNldE1vdmFibGUiLCJjYWxsQmluZEV2ZW50IiwiYWRkIiwiaXRlbU5vZGUiLCJkZXN0cm95TGlzdCIsInNjYWxlIiwic2NoZWR1bGVPbmNlIiwicnVuQWN0aW9uIiwic2NhbGVCeSIsIm1vdmVUbyIsImRlc3Ryb3kiLCJpIiwiYmluZCIsIm5vcm1hbEFkZCIsInNwcml0ZUZyYW1lUGljIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsT0FBTyxFQUFDSixFQUFFLENBQUNLO0FBREgsR0FIUDtBQVFMO0FBRUE7QUFFQUMsRUFBQUEsS0FaSyxtQkFZSSxDQUVSLENBZEk7QUFpQkxDLEVBQUFBLE9BakJLLG1CQWlCR0MsSUFqQkgsRUFpQlE7QUFDVCxXQUFPLEtBQUtDLElBQUwsQ0FBVUMsY0FBVixDQUF5QkYsSUFBekIsQ0FBUDtBQUNILEdBbkJJO0FBcUJMRyxFQUFBQSxPQXJCSyxxQkFxQkk7QUFDTCxRQUFJQyxPQUFPLEdBQUdaLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlLEtBQUtULE9BQXBCLENBQWQ7QUFDQVEsSUFBQUEsT0FBTyxDQUFDRSxNQUFSLEdBQWlCLEtBQUtMLElBQXRCO0FBQ0gsR0F4Qkk7QUEwQkxNLEVBQUFBLFdBMUJLLHVCQTBCT04sSUExQlAsRUEwQlk7QUFDYixRQUFJTyxHQUFHLEdBQUNQLElBQUksQ0FBQ1Esb0JBQUwsQ0FBMEIsS0FBS1IsSUFBTCxDQUFVUyxxQkFBVixDQUFnQyxLQUFLVCxJQUFMLENBQVVVLFdBQVYsR0FBd0IsS0FBS1YsSUFBTCxDQUFVVSxXQUFWLEdBQXdCQyxNQUF4QixHQUErQixDQUF2RCxFQUEwREMsV0FBMUQsRUFBaEMsQ0FBMUIsQ0FBUjtBQUNBLFdBQU9MLEdBQVA7QUFDSCxHQTdCSTtBQStCTE0sRUFBQUEsUUEvQkssb0JBK0JJQyxLQS9CSixFQStCVWYsSUEvQlYsRUErQmU7QUFDaEIsU0FBS0MsSUFBTCxDQUFVVSxXQUFWLEdBQXdCLEtBQUtWLElBQUwsQ0FBVVUsV0FBVixHQUF3QkMsTUFBeEIsR0FBK0IsQ0FBdkQsRUFBMERJLFlBQTFELENBQXVFeEIsRUFBRSxDQUFDeUIsTUFBMUUsRUFBa0ZDLFdBQWxGLEdBQThGSCxLQUE5RjtBQUNBLFNBQUtkLElBQUwsQ0FBVVUsV0FBVixHQUF3QixLQUFLVixJQUFMLENBQVVVLFdBQVYsR0FBd0JDLE1BQXhCLEdBQStCLENBQXZELEVBQTBEVixjQUExRCxDQUF5RSxPQUF6RSxFQUFrRmMsWUFBbEYsQ0FBK0Z4QixFQUFFLENBQUMyQixLQUFsRyxFQUF5R0MsTUFBekcsR0FBZ0hwQixJQUFoSDtBQUNBLFNBQUtDLElBQUwsQ0FBVVUsV0FBVixHQUF3QixLQUFLVixJQUFMLENBQVVVLFdBQVYsR0FBd0JDLE1BQXhCLEdBQStCLENBQXZELEVBQTBEWixJQUExRCxHQUErREEsSUFBL0Q7QUFFQXFCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaLEVBQXdDLEtBQUtyQixJQUFMLENBQVVVLFdBQVYsRUFBeEM7QUFDSCxHQXJDSTtBQXVDTFksRUFBQUEsU0F2Q0sscUJBdUNLdkIsSUF2Q0wsRUF1Q1V3QixTQXZDVixFQXVDb0I7QUFDckJILElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQUtyQixJQUFMLENBQVVVLFdBQVYsRUFBWjtBQUNBVSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFLckIsSUFBTCxDQUFVQyxjQUFWLENBQXlCRixJQUF6QixDQUFaLEVBQTJDQSxJQUEzQztBQUNBLFNBQUtDLElBQUwsQ0FBVUMsY0FBVixDQUF5QkYsSUFBekIsRUFBK0JnQixZQUEvQixDQUE0QyxRQUE1QyxFQUFzRFMsU0FBdEQsR0FBZ0VELFNBQWhFO0FBQ0gsR0EzQ0k7QUE0Q0xFLEVBQUFBLFVBNUNLLHNCQTRDTTFCLElBNUNOLEVBNENXO0FBQ1osU0FBS0MsSUFBTCxDQUFVQyxjQUFWLENBQXlCRixJQUF6QixFQUErQmdCLFlBQS9CLENBQTRDLFFBQTVDLEVBQXNEVyxhQUF0RDtBQUNILEdBOUNJO0FBK0NMQyxFQUFBQSxHQS9DSyxlQStDREMsUUEvQ0MsRUErQ1E3QixJQS9DUixFQStDYThCLFdBL0NiLEVBK0N5QkMsS0EvQ3pCLEVBK0MrQjtBQUNoQyxTQUFLQyxZQUFMLENBQWtCLFlBQVU7QUFDeEJILE1BQUFBLFFBQVEsQ0FBQ0ksU0FBVCxDQUFtQnpDLEVBQUUsQ0FBQzBDLE9BQUgsQ0FBVyxDQUFYLEVBQWFILEtBQWIsQ0FBbkI7QUFDQyxXQUFLNUIsT0FBTDtBQUNBMEIsTUFBQUEsUUFBUSxDQUFDSSxTQUFULENBQW1CekMsRUFBRSxDQUFDMkMsTUFBSCxDQUFVLENBQVYsRUFBWSxLQUFLNUIsV0FBTCxDQUFpQnNCLFFBQVEsQ0FBQ3ZCLE1BQTFCLENBQVosQ0FBbkI7QUFDQSxXQUFLMEIsWUFBTCxDQUFrQixZQUFVO0FBQ3pCLGFBQUtsQixRQUFMLENBQWNlLFFBQVEsQ0FBQ2IsWUFBVCxDQUFzQnhCLEVBQUUsQ0FBQ3lCLE1BQXpCLEVBQWlDQyxXQUEvQyxFQUEyRGxCLElBQTNEO0FBQ0E2QixRQUFBQSxRQUFRLENBQUNPLE9BQVQ7O0FBQ0EsYUFBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUNQLFdBQVcsQ0FBQ2xCLE1BQTFCLEVBQWlDeUIsQ0FBQyxFQUFsQyxFQUFxQztBQUNqQ1AsVUFBQUEsV0FBVyxDQUFDTyxDQUFELENBQVgsQ0FBZUQsT0FBZjtBQUNIO0FBQ0gsT0FOaUIsQ0FNaEJFLElBTmdCLENBTVgsSUFOVyxDQUFsQixFQU1hLENBTmI7QUFPSixLQVhpQixDQVdoQkEsSUFYZ0IsQ0FXWCxJQVhXLENBQWxCLEVBV2EsQ0FYYjtBQVlILEdBNURJO0FBOERMQyxFQUFBQSxTQTlESyxxQkE4REtDLGNBOURMLEVBOERvQnhDLElBOURwQixFQThEeUI7QUFDMUIsU0FBS0csT0FBTDtBQUNBLFNBQUtXLFFBQUwsQ0FBYzBCLGNBQWQsRUFBNkJ4QyxJQUE3QjtBQUNILEdBakVJLENBa0VMOztBQWxFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgaXRlbUFkZDpjYy5QcmVmYWIsXHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcblxyXG4gICAgZ2V0Tm9kZShuYW1lKXtcclxuICAgICAgICByZXR1cm4gdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKG5hbWUpO1xyXG4gICAgfSxcclxuXHJcbiAgICBhZGRJdGVtKCl7XHJcbiAgICAgICAgdmFyIHRQcmVmYWIgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLml0ZW1BZGQpOyAgIFxyXG4gICAgICAgIHRQcmVmYWIucGFyZW50ID0gdGhpcy5ub2RlO1xyXG4gICAgfSxcclxuXHJcbiAgICBnZXRGaW5hbExvYyhub2RlKXtcclxuICAgICAgICB2YXIgbG9jPW5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIodGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUih0aGlzLm5vZGUuZ2V0Q2hpbGRyZW4oKVt0aGlzLm5vZGUuZ2V0Q2hpbGRyZW4oKS5sZW5ndGgtMV0uZ2V0UG9zaXRpb24oKSkpXHJcbiAgICAgICAgcmV0dXJuIGxvYztcclxuICAgIH0sXHJcblxyXG4gICAgc2hvd0l0ZW0oZnJhbWUsbmFtZSl7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkcmVuKClbdGhpcy5ub2RlLmdldENoaWxkcmVuKCkubGVuZ3RoLTFdLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lPWZyYW1lO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZHJlbigpW3RoaXMubm9kZS5nZXRDaGlsZHJlbigpLmxlbmd0aC0xXS5nZXRDaGlsZEJ5TmFtZShcImxhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPW5hbWU7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkcmVuKClbdGhpcy5ub2RlLmdldENoaWxkcmVuKCkubGVuZ3RoLTFdLm5hbWU9bmFtZTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zb2xlLmxvZygndGhpcy5ub2RlLmdldENoaWxkcmVuKCkgJywgdGhpcy5ub2RlLmdldENoaWxkcmVuKCkpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzZXRQYXJlbnQobmFtZSxzY2VuZU5vZGUpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHRoaXMubm9kZS5nZXRDaGlsZHJlbigpKTtcclxuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUobmFtZSksbmFtZSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKG5hbWUpLmdldENvbXBvbmVudChcInlfaXRlbVwiKS5zdGFnZU5vZGU9c2NlbmVOb2RlO1xyXG4gICAgfSxcclxuICAgIHNldE1vdmFibGUobmFtZSl7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKG5hbWUpLmdldENvbXBvbmVudChcInlfaXRlbVwiKS5jYWxsQmluZEV2ZW50KCk7XHJcbiAgICB9LFxyXG4gICAgYWRkKGl0ZW1Ob2RlLG5hbWUsZGVzdHJveUxpc3Qsc2NhbGUpe1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGl0ZW1Ob2RlLnJ1bkFjdGlvbihjYy5zY2FsZUJ5KDEsc2NhbGUpKTtcclxuICAgICAgICAgICAgIHRoaXMuYWRkSXRlbSgpO1xyXG4gICAgICAgICAgICAgaXRlbU5vZGUucnVuQWN0aW9uKGNjLm1vdmVUbygxLHRoaXMuZ2V0RmluYWxMb2MoaXRlbU5vZGUucGFyZW50KSkpO1xyXG4gICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0l0ZW0oaXRlbU5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUsbmFtZSk7IFxyXG4gICAgICAgICAgICAgICAgaXRlbU5vZGUuZGVzdHJveSgpO1xyXG4gICAgICAgICAgICAgICAgZm9yKHZhciBpPTA7aTxkZXN0cm95TGlzdC5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgICAgICAgICBkZXN0cm95TGlzdFtpXS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICB9LmJpbmQodGhpcyksMik7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLDEpO1xyXG4gICAgfSxcclxuXHJcbiAgICBub3JtYWxBZGQoc3ByaXRlRnJhbWVQaWMsbmFtZSl7XHJcbiAgICAgICAgdGhpcy5hZGRJdGVtKCk7XHJcbiAgICAgICAgdGhpcy5zaG93SXRlbShzcHJpdGVGcmFtZVBpYyxuYW1lKTsgXHJcbiAgICB9LFxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=