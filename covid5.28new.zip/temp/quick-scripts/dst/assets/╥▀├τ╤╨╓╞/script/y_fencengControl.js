
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_fencengControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6b195wTkSJPsbEK9/l4xbdH', 'y_fencengControl');
// 疫苗研制/script/y_fencengControl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    showStage: cc.Label,
    sceneControl: cc.Node,
    stage: 0,
    successClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.stage = 0;
    this.sceneControl = this.sceneControl.getComponent("y_sceneController");
  },
  moveProcess: function moveProcess(self, other) {
    if (this.stage == 0) {
      if (self.name == "微量移液管" && other.name == "样品" || self.name == "样品" && other.name == "微量移液管") {
        cc.audioEngine.playEffect(this.successClip, false);
        this.showStage.string = "吸取完成";
        this.node.getChildByName("样品").destroy();
        this.stage = 1;
      }
    }

    if (this.stage == 1) {
      if (self.name == "微量移液管" && other.name == "离心管" || self.name == "离心管" && other.name == "微量移液管") {
        cc.audioEngine.playEffect(this.successClip, false);
        this.showStage.string = "注入完成";
        this.node.getChildByName("微量移液管").destroy();
        this.scheduleOnce(function () {
          this.node.getChildByName("离心管").destroy();
          this.scheduleOnce(function () {
            this.sceneControl.changeStage(5);
          }.bind(this), 1);
        }.bind(this), 1);
        this.stage = 2;
      }
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfZmVuY2VuZ0NvbnRyb2wuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzaG93U3RhZ2UiLCJMYWJlbCIsInNjZW5lQ29udHJvbCIsIk5vZGUiLCJzdGFnZSIsInN1Y2Nlc3NDbGlwIiwidHlwZSIsIkF1ZGlvQ2xpcCIsInN0YXJ0IiwiZ2V0Q29tcG9uZW50IiwibW92ZVByb2Nlc3MiLCJzZWxmIiwib3RoZXIiLCJuYW1lIiwiYXVkaW9FbmdpbmUiLCJwbGF5RWZmZWN0Iiwic3RyaW5nIiwibm9kZSIsImdldENoaWxkQnlOYW1lIiwiZGVzdHJveSIsInNjaGVkdWxlT25jZSIsImNoYW5nZVN0YWdlIiwiYmluZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFNBQVMsRUFBQ0osRUFBRSxDQUFDSyxLQURMO0FBRVJDLElBQUFBLFlBQVksRUFBQ04sRUFBRSxDQUFDTyxJQUZSO0FBR1JDLElBQUFBLEtBQUssRUFBQyxDQUhFO0FBSVJDLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUkMsTUFBQUEsSUFBSSxFQUFDVixFQUFFLENBQUNXO0FBRkE7QUFKSixHQUhQO0FBYUw7QUFFQTtBQUVBQyxFQUFBQSxLQWpCSyxtQkFpQkk7QUFDTCxTQUFLSixLQUFMLEdBQVcsQ0FBWDtBQUNBLFNBQUtGLFlBQUwsR0FBa0IsS0FBS0EsWUFBTCxDQUFrQk8sWUFBbEIsQ0FBK0IsbUJBQS9CLENBQWxCO0FBQ0gsR0FwQkk7QUF3QkxDLEVBQUFBLFdBeEJLLHVCQXdCT0MsSUF4QlAsRUF3QllDLEtBeEJaLEVBd0JrQjtBQUNuQixRQUFHLEtBQUtSLEtBQUwsSUFBWSxDQUFmLEVBQWlCO0FBQ2IsVUFBSU8sSUFBSSxDQUFDRSxJQUFMLElBQVcsT0FBWCxJQUFvQkQsS0FBSyxDQUFDQyxJQUFOLElBQVksSUFBakMsSUFBeUNGLElBQUksQ0FBQ0UsSUFBTCxJQUFXLElBQVgsSUFBaUJELEtBQUssQ0FBQ0MsSUFBTixJQUFZLE9BQXpFLEVBQWtGO0FBQzlFakIsUUFBQUEsRUFBRSxDQUFDa0IsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtWLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0EsYUFBS0wsU0FBTCxDQUFlZ0IsTUFBZixHQUFzQixNQUF0QjtBQUNBLGFBQUtDLElBQUwsQ0FBVUMsY0FBVixDQUF5QixJQUF6QixFQUErQkMsT0FBL0I7QUFDQSxhQUFLZixLQUFMLEdBQVcsQ0FBWDtBQUNIO0FBQ0o7O0FBQ0QsUUFBRyxLQUFLQSxLQUFMLElBQVksQ0FBZixFQUFpQjtBQUNiLFVBQUlPLElBQUksQ0FBQ0UsSUFBTCxJQUFXLE9BQVgsSUFBb0JELEtBQUssQ0FBQ0MsSUFBTixJQUFZLEtBQWpDLElBQTBDRixJQUFJLENBQUNFLElBQUwsSUFBVyxLQUFYLElBQWtCRCxLQUFLLENBQUNDLElBQU4sSUFBWSxPQUEzRSxFQUFvRjtBQUNoRmpCLFFBQUFBLEVBQUUsQ0FBQ2tCLFdBQUgsQ0FBZUMsVUFBZixDQUEwQixLQUFLVixXQUEvQixFQUEyQyxLQUEzQztBQUNBLGFBQUtMLFNBQUwsQ0FBZWdCLE1BQWYsR0FBc0IsTUFBdEI7QUFDQSxhQUFLQyxJQUFMLENBQVVDLGNBQVYsQ0FBeUIsT0FBekIsRUFBa0NDLE9BQWxDO0FBQ0EsYUFBS0MsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLGVBQUtILElBQUwsQ0FBVUMsY0FBVixDQUF5QixLQUF6QixFQUFnQ0MsT0FBaEM7QUFDQSxlQUFLQyxZQUFMLENBQWtCLFlBQVU7QUFDeEIsaUJBQUtsQixZQUFMLENBQWtCbUIsV0FBbEIsQ0FBOEIsQ0FBOUI7QUFDSCxXQUZpQixDQUVoQkMsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWEsQ0FGYjtBQUdILFNBTGlCLENBS2hCQSxJQUxnQixDQUtYLElBTFcsQ0FBbEIsRUFLYSxDQUxiO0FBT0EsYUFBS2xCLEtBQUwsR0FBVyxDQUFYO0FBQ0g7QUFDSjtBQUNKLEdBaERJLENBaURMOztBQWpESyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgc2hvd1N0YWdlOmNjLkxhYmVsLFxyXG4gICAgICAgIHNjZW5lQ29udHJvbDpjYy5Ob2RlLFxyXG4gICAgICAgIHN0YWdlOjAsXHJcbiAgICAgICAgc3VjY2Vzc0NsaXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuc3RhZ2U9MDtcclxuICAgICAgICB0aGlzLnNjZW5lQ29udHJvbD10aGlzLnNjZW5lQ29udHJvbC5nZXRDb21wb25lbnQoXCJ5X3NjZW5lQ29udHJvbGxlclwiKTtcclxuICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICBtb3ZlUHJvY2VzcyhzZWxmLG90aGVyKXtcclxuICAgICAgICBpZih0aGlzLnN0YWdlPT0wKXtcclxuICAgICAgICAgICAgaWYoKHNlbGYubmFtZT09XCLlvq7ph4/np7vmtrLnrqFcIiYmb3RoZXIubmFtZT09XCLmoLflk4FcIil8fChzZWxmLm5hbWU9PVwi5qC35ZOBXCImJm90aGVyLm5hbWU9PVwi5b6u6YeP56e75ray566hXCIpKXtcclxuICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5zdWNjZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTdGFnZS5zdHJpbmc9XCLlkLjlj5blrozmiJBcIjtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIuagt+WTgVwiKS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YWdlPTE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5zdGFnZT09MSl7XHJcbiAgICAgICAgICAgIGlmKChzZWxmLm5hbWU9PVwi5b6u6YeP56e75ray566hXCImJm90aGVyLm5hbWU9PVwi56a75b+D566hXCIpfHwoc2VsZi5uYW1lPT1cIuemu+W/g+euoVwiJiZvdGhlci5uYW1lPT1cIuW+rumHj+enu+a2sueuoVwiKSl7XHJcbiAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U3RhZ2Uuc3RyaW5nPVwi5rOo5YWl5a6M5oiQXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCLlvq7ph4/np7vmtrLnrqFcIikuZGVzdHJveSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCLnprvlv4PnrqFcIikuZGVzdHJveSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2NlbmVDb250cm9sLmNoYW5nZVN0YWdlKDUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwxKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwxKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YWdlPTI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==