
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_pcrMachine.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a7229SxE8BBg4w/z4YOC1AT', 'y_pcrMachine');
// 疫苗研制/script/y_pcrMachine.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    showStage: cc.Label,
    sceneControl: cc.Node,
    successClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.sceneControl = this.sceneControl.getComponent("y_sceneController");
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    if (other.node.name == "样品") {
      other.node.destroy();
      this.showStage.string = "处理中，请等待";
      cc.audioEngine.playEffect(this.successClip, false);
      this.scheduleOnce(function () {
        this.showStage.string = "处理完成";
        this.scheduleOnce(function () {
          this.node.runAction(cc.fadeOut(1));
        }.bind(this), 1);
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.sceneControl.changeStage(6);
      }.bind(this), 3.5);
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfcGNyTWFjaGluZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNob3dTdGFnZSIsIkxhYmVsIiwic2NlbmVDb250cm9sIiwiTm9kZSIsInN1Y2Nlc3NDbGlwIiwidHlwZSIsIkF1ZGlvQ2xpcCIsInN0YXJ0IiwiZ2V0Q29tcG9uZW50Iiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsIm5vZGUiLCJuYW1lIiwiZGVzdHJveSIsInN0cmluZyIsImF1ZGlvRW5naW5lIiwicGxheUVmZmVjdCIsInNjaGVkdWxlT25jZSIsInJ1bkFjdGlvbiIsImZhZGVPdXQiLCJiaW5kIiwiY2hhbmdlU3RhZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUNKLEVBQUUsQ0FBQ0ssS0FETDtBQUVSQyxJQUFBQSxZQUFZLEVBQUNOLEVBQUUsQ0FBQ08sSUFGUjtBQUdSQyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUSxJQURBO0FBRVJDLE1BQUFBLElBQUksRUFBQ1QsRUFBRSxDQUFDVTtBQUZBO0FBSEosR0FIUDtBQVlMO0FBRUE7QUFFQUMsRUFBQUEsS0FoQkssbUJBZ0JJO0FBQ0wsU0FBS0wsWUFBTCxHQUFrQixLQUFLQSxZQUFMLENBQWtCTSxZQUFsQixDQUErQixtQkFBL0IsQ0FBbEI7QUFDSCxHQWxCSTtBQXFCTEMsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVVDLEtBQVYsRUFBaUJDLElBQWpCLEVBQXVCO0FBRXJDLFFBQUdELEtBQUssQ0FBQ0UsSUFBTixDQUFXQyxJQUFYLElBQWlCLElBQXBCLEVBQXlCO0FBQ3JCSCxNQUFBQSxLQUFLLENBQUNFLElBQU4sQ0FBV0UsT0FBWDtBQUNBLFdBQUtkLFNBQUwsQ0FBZWUsTUFBZixHQUFzQixTQUF0QjtBQUNBbkIsTUFBQUEsRUFBRSxDQUFDb0IsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtiLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0EsV0FBS2MsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLGFBQUtsQixTQUFMLENBQWVlLE1BQWYsR0FBc0IsTUFBdEI7QUFDQSxhQUFLRyxZQUFMLENBQWtCLFlBQVU7QUFDeEIsZUFBS04sSUFBTCxDQUFVTyxTQUFWLENBQW9CdkIsRUFBRSxDQUFDd0IsT0FBSCxDQUFXLENBQVgsQ0FBcEI7QUFDSCxTQUZpQixDQUVoQkMsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWEsQ0FGYjtBQUdILE9BTGlCLENBS2hCQSxJQUxnQixDQUtYLElBTFcsQ0FBbEIsRUFLYSxDQUxiO0FBT0EsV0FBS0gsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLGFBQUtoQixZQUFMLENBQWtCb0IsV0FBbEIsQ0FBOEIsQ0FBOUI7QUFDSCxPQUZpQixDQUVoQkQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWEsR0FGYjtBQUlIO0FBQ0osR0F2Q0ksQ0F3Q0w7O0FBeENLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzaG93U3RhZ2U6Y2MuTGFiZWwsXHJcbiAgICAgICAgc2NlbmVDb250cm9sOmNjLk5vZGUsXHJcbiAgICAgICAgc3VjY2Vzc0NsaXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuc2NlbmVDb250cm9sPXRoaXMuc2NlbmVDb250cm9sLmdldENvbXBvbmVudChcInlfc2NlbmVDb250cm9sbGVyXCIpO1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgb25Db2xsaXNpb25FbnRlcjogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYob3RoZXIubm9kZS5uYW1lPT1cIuagt+WTgVwiKXtcclxuICAgICAgICAgICAgb3RoZXIubm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1N0YWdlLnN0cmluZz1cIuWkhOeQhuS4re+8jOivt+etieW+hVwiO1xyXG4gICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U3RhZ2Uuc3RyaW5nPVwi5aSE55CG5a6M5oiQXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2MuZmFkZU91dCgxKSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksMSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwyKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjZW5lQ29udHJvbC5jaGFuZ2VTdGFnZSg2KTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDMuNSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==