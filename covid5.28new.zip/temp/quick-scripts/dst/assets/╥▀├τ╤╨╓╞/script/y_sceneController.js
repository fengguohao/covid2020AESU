
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_sceneController.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fe8cbwhxDZF5bEC7UzSckTR', 'y_sceneController');
// 疫苗研制/script/y_sceneController.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    topPrompt: cc.Label,
    sidePrompt: cc.Label,
    thawSceneSecondPart: cc.Node,
    liejieScene: cc.Node,
    zhendangScene: cc.Node,
    fencengScene: cc.Node,
    pcrScene: cc.Node,
    cellTest: cc.Node,
    "finally": cc.Node,
    itemLayOut: cc.Node,
    stage: 0,
    simpleBox: cc.SpriteFrame,
    liejieLiquid: cc.SpriteFrame,
    pipette: cc.SpriteFrame,
    centrifugeTube: cc.SpriteFrame,
    centrifugeTube2: cc.SpriteFrame,
    centrifugeTube3: cc.SpriteFrame,
    successClip: {
      "default": null,
      type: cc.AudioClip
    },
    finalClip: {
      "default": null,
      type: cc.AudioClip
    } //0:解冻

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    cc.director.getCollisionManager().enabled = true;
    this.itemLayOut = this.itemLayOut.getComponent("y_itemControl");
  },
  changeTopPrompt: function changeTopPrompt(str) {
    this.topPrompt.string = str;
  },
  changeSidePrompt: function changeSidePrompt(str) {
    this.sidePrompt.string = str;
  },
  callExit: function callExit() {
    this.scheduleOnce(function () {
      cc.audioEngine.playEffect(this.finalClip, false);
      this["finally"].active = true;
      this["finally"].runAction(cc.moveTo(1, 0, 0));
    }.bind(this), 5);
  },
  changeStage: function changeStage(num) {
    this.stage = num;

    switch (num) {
      case 1:
        console.log("进入解冻箱阶段");
        this.changeTopPrompt("样品解冻");
        this.itemLayOut.setParent("样品毒株", this.thawSceneSecondPart);
        this.itemLayOut.setMovable("样品毒株");
        this.changeSidePrompt("请将样品拖放入\n生物安全柜\n进行解冻");
        this.thawSceneSecondPart.active = true;
        break;

      case 2:
        this.thawSceneSecondPart.active = false;
        this.liejieScene.active = true;
        this.changeTopPrompt("病毒裂解");
        this.itemLayOut.normalAdd(this.simpleBox, "已解冻毒株");
        this.itemLayOut.setParent("已解冻毒株", this.liejieScene);
        this.itemLayOut.setMovable("已解冻毒株");
        this.itemLayOut.normalAdd(this.liejieLiquid, "裂解液");
        this.itemLayOut.setParent("裂解液", this.liejieScene);
        this.itemLayOut.setMovable("裂解液");
        this.itemLayOut.normalAdd(this.pipette, "微量移液管");
        this.itemLayOut.setParent("微量移液管", this.liejieScene);
        this.itemLayOut.setMovable("微量移液管");
        this.itemLayOut.normalAdd(this.centrifugeTube, "离心管");
        this.itemLayOut.setParent("离心管", this.liejieScene);
        this.itemLayOut.setMovable("离心管");
        this.scheduleOnce(function () {
          this.changeSidePrompt('核酸相当于病毒的"身份证",\n在研究前首先要提取核酸。\n请将病毒样品取到微离心管中,\n注入裂解液');
        }.bind(this), 2);
        break;

      case 3:
        this.changeTopPrompt("核酸提取");
        this.liejieScene.active = false;
        this.zhendangScene.active = true;
        this.itemLayOut.setParent("混合试剂", this.zhendangScene);
        this.itemLayOut.setMovable("混合试剂");
        break;

      case 4:
        this.zhendangScene.active = false;
        this.fencengScene.active = true;
        this.itemLayOut.normalAdd(this.pipette, "微量移液管");
        this.itemLayOut.setParent("微量移液管", this.fencengScene);
        this.itemLayOut.setMovable("微量移液管");
        this.itemLayOut.normalAdd(this.centrifugeTube, "离心管");
        this.itemLayOut.setParent("离心管", this.fencengScene);
        this.itemLayOut.setMovable("离心管");
        this.itemLayOut.normalAdd(this.centrifugeTube2, "样品");
        this.itemLayOut.setParent("样品", this.fencengScene);
        this.itemLayOut.setMovable("样品");
        this.changeSidePrompt("病毒的蛋白质外壳已瓦解，\n病毒的核酸流出\n经过震荡离心处理后\n病毒核酸大量\n存在于在下层，\n请将其取出");
        break;

      case 5:
        this.changeTopPrompt("荧光定量PCR检测");
        this.fencengScene.active = false;
        this.pcrScene.active = true;
        this.itemLayOut.normalAdd(this.centrifugeTube3, "样品");
        this.itemLayOut.setParent("样品", this.pcrScene);
        this.itemLayOut.setMovable("样品");
        this.changeSidePrompt("荧光定量PCR检测\n是通过荧光染料或荧光标记\n的特异性的探针，\n对PCR产物进行标记跟踪\n借助这项技术\n我们可以检测当前\n样品是否是所需病毒");
        break;

      case 6:
        this.pcrScene.active = false;
        this.cellTest.active = true;
        this.changeSidePrompt("PCR检测已通过\n确认是所需病毒\n符合疫苗研制要求\n可以进行扩增");
        this.scheduleOnce(function () {
          this.changeTopPrompt("扩增实验");
          cc.audioEngine.playEffect(this.successClip, false);
          this.changeSidePrompt("接下来病毒将被接种到\n'细胞工厂'中进行检测\n左侧的瓶子便是细胞工厂\n我们能够通过检测\n病毒的侵染状况\n进而判断病毒活性");
          this.scheduleOnce(function () {
            //this.cellTest.active=false;
            cc.audioEngine.playEffect(this.successClip, false);
            this.changeTopPrompt("后续步骤");
            this.changeSidePrompt("疫苗研制的过程是非常复杂的\n进行到这一步\n我们仅能获取到可能\n可以进行疫苗制造的毒株\n后面还要进行大量的检测");
            this.scheduleOnce(function () {
              cc.audioEngine.playEffect(this.successClip, false);
              this.changeSidePrompt("包括灭活病毒盲传三代检测\n多期的动物实验、人体实验\n有效性评价安全性评价等等");
              this.scheduleOnce(function () {
                this.changeSidePrompt("科研的过程是艰辛而又复杂的\n让我们向奋战在一线的\n科研工作者致敬");
                this.callExit();
              }.bind(this), 5);
            }.bind(this), 5);
          }.bind(this), 5);
        }.bind(this), 5);
    }
  },
  returnOnClick: function returnOnClick() {
    cc.director.loadScene("衔接场景");
  },
  againCtrl: function againCtrl() {
    cc.director.loadScene("疫苗研制");
  },
  exitCtrl: function exitCtrl() {
    cc.director.loadScene("衔接场景");
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfc2NlbmVDb250cm9sbGVyLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwidG9wUHJvbXB0IiwiTGFiZWwiLCJzaWRlUHJvbXB0IiwidGhhd1NjZW5lU2Vjb25kUGFydCIsIk5vZGUiLCJsaWVqaWVTY2VuZSIsInpoZW5kYW5nU2NlbmUiLCJmZW5jZW5nU2NlbmUiLCJwY3JTY2VuZSIsImNlbGxUZXN0IiwiaXRlbUxheU91dCIsInN0YWdlIiwic2ltcGxlQm94IiwiU3ByaXRlRnJhbWUiLCJsaWVqaWVMaXF1aWQiLCJwaXBldHRlIiwiY2VudHJpZnVnZVR1YmUiLCJjZW50cmlmdWdlVHViZTIiLCJjZW50cmlmdWdlVHViZTMiLCJzdWNjZXNzQ2xpcCIsInR5cGUiLCJBdWRpb0NsaXAiLCJmaW5hbENsaXAiLCJzdGFydCIsImRpcmVjdG9yIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsImVuYWJsZWQiLCJnZXRDb21wb25lbnQiLCJjaGFuZ2VUb3BQcm9tcHQiLCJzdHIiLCJzdHJpbmciLCJjaGFuZ2VTaWRlUHJvbXB0IiwiY2FsbEV4aXQiLCJzY2hlZHVsZU9uY2UiLCJhdWRpb0VuZ2luZSIsInBsYXlFZmZlY3QiLCJhY3RpdmUiLCJydW5BY3Rpb24iLCJtb3ZlVG8iLCJiaW5kIiwiY2hhbmdlU3RhZ2UiLCJudW0iLCJjb25zb2xlIiwibG9nIiwic2V0UGFyZW50Iiwic2V0TW92YWJsZSIsIm5vcm1hbEFkZCIsInJldHVybk9uQ2xpY2siLCJsb2FkU2NlbmUiLCJhZ2FpbkN0cmwiLCJleGl0Q3RybCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFNBQVMsRUFBQ0osRUFBRSxDQUFDSyxLQURMO0FBRVJDLElBQUFBLFVBQVUsRUFBQ04sRUFBRSxDQUFDSyxLQUZOO0FBR1JFLElBQUFBLG1CQUFtQixFQUFDUCxFQUFFLENBQUNRLElBSGY7QUFJUkMsSUFBQUEsV0FBVyxFQUFDVCxFQUFFLENBQUNRLElBSlA7QUFLUkUsSUFBQUEsYUFBYSxFQUFDVixFQUFFLENBQUNRLElBTFQ7QUFNUkcsSUFBQUEsWUFBWSxFQUFDWCxFQUFFLENBQUNRLElBTlI7QUFPUkksSUFBQUEsUUFBUSxFQUFDWixFQUFFLENBQUNRLElBUEo7QUFRUkssSUFBQUEsUUFBUSxFQUFDYixFQUFFLENBQUNRLElBUko7QUFTUixlQUFRUixFQUFFLENBQUNRLElBVEg7QUFVUk0sSUFBQUEsVUFBVSxFQUFDZCxFQUFFLENBQUNRLElBVk47QUFZUk8sSUFBQUEsS0FBSyxFQUFDLENBWkU7QUFhUkMsSUFBQUEsU0FBUyxFQUFDaEIsRUFBRSxDQUFDaUIsV0FiTDtBQWNSQyxJQUFBQSxZQUFZLEVBQUNsQixFQUFFLENBQUNpQixXQWRSO0FBZVJFLElBQUFBLE9BQU8sRUFBQ25CLEVBQUUsQ0FBQ2lCLFdBZkg7QUFnQlJHLElBQUFBLGNBQWMsRUFBQ3BCLEVBQUUsQ0FBQ2lCLFdBaEJWO0FBaUJSSSxJQUFBQSxlQUFlLEVBQUNyQixFQUFFLENBQUNpQixXQWpCWDtBQWtCUkssSUFBQUEsZUFBZSxFQUFDdEIsRUFBRSxDQUFDaUIsV0FsQlg7QUFtQlJNLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUkMsTUFBQUEsSUFBSSxFQUFDeEIsRUFBRSxDQUFDeUI7QUFGQSxLQW5CSjtBQXVCUkMsSUFBQUEsU0FBUyxFQUFDO0FBQ04saUJBQVEsSUFERjtBQUVORixNQUFBQSxJQUFJLEVBQUN4QixFQUFFLENBQUN5QjtBQUZGLEtBdkJGLENBMkJSOztBQTNCUSxHQUhQO0FBaUNMO0FBRUE7QUFFQUUsRUFBQUEsS0FyQ0ssbUJBcUNJO0FBQ0wzQixJQUFBQSxFQUFFLENBQUM0QixRQUFILENBQVlDLG1CQUFaLEdBQWtDQyxPQUFsQyxHQUE0QyxJQUE1QztBQUNBLFNBQUtoQixVQUFMLEdBQWdCLEtBQUtBLFVBQUwsQ0FBZ0JpQixZQUFoQixDQUE2QixlQUE3QixDQUFoQjtBQUNILEdBeENJO0FBeUNMQyxFQUFBQSxlQXpDSywyQkF5Q1dDLEdBekNYLEVBeUNlO0FBQ2hCLFNBQUs3QixTQUFMLENBQWU4QixNQUFmLEdBQXNCRCxHQUF0QjtBQUNILEdBM0NJO0FBNENMRSxFQUFBQSxnQkE1Q0ssNEJBNENZRixHQTVDWixFQTRDZ0I7QUFDakIsU0FBSzNCLFVBQUwsQ0FBZ0I0QixNQUFoQixHQUF1QkQsR0FBdkI7QUFDSCxHQTlDSTtBQWlETEcsRUFBQUEsUUFqREssc0JBaURLO0FBQ04sU0FBS0MsWUFBTCxDQUFrQixZQUFVO0FBQ3hCckMsTUFBQUEsRUFBRSxDQUFDc0MsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtiLFNBQS9CLEVBQXlDLEtBQXpDO0FBQ0Esc0JBQWFjLE1BQWIsR0FBb0IsSUFBcEI7QUFDQSxzQkFBYUMsU0FBYixDQUF1QnpDLEVBQUUsQ0FBQzBDLE1BQUgsQ0FBVSxDQUFWLEVBQVksQ0FBWixFQUFjLENBQWQsQ0FBdkI7QUFDSCxLQUppQixDQUloQkMsSUFKZ0IsQ0FJWCxJQUpXLENBQWxCLEVBSWEsQ0FKYjtBQUtILEdBdkRJO0FBd0RMQyxFQUFBQSxXQXhESyx1QkF3RE9DLEdBeERQLEVBd0RXO0FBQ1osU0FBSzlCLEtBQUwsR0FBVzhCLEdBQVg7O0FBQ0EsWUFBT0EsR0FBUDtBQUNJLFdBQUssQ0FBTDtBQUNJQyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0EsYUFBS2YsZUFBTCxDQUFxQixNQUFyQjtBQUNBLGFBQUtsQixVQUFMLENBQWdCa0MsU0FBaEIsQ0FBMEIsTUFBMUIsRUFBaUMsS0FBS3pDLG1CQUF0QztBQUNBLGFBQUtPLFVBQUwsQ0FBZ0JtQyxVQUFoQixDQUEyQixNQUEzQjtBQUNBLGFBQUtkLGdCQUFMLENBQXNCLHNCQUF0QjtBQUNBLGFBQUs1QixtQkFBTCxDQUF5QmlDLE1BQXpCLEdBQWdDLElBQWhDO0FBQ0E7O0FBQ0osV0FBSyxDQUFMO0FBQ0ksYUFBS2pDLG1CQUFMLENBQXlCaUMsTUFBekIsR0FBZ0MsS0FBaEM7QUFDQSxhQUFLL0IsV0FBTCxDQUFpQitCLE1BQWpCLEdBQXdCLElBQXhCO0FBQ0EsYUFBS1IsZUFBTCxDQUFxQixNQUFyQjtBQUNBLGFBQUtsQixVQUFMLENBQWdCb0MsU0FBaEIsQ0FBMEIsS0FBS2xDLFNBQS9CLEVBQXlDLE9BQXpDO0FBQ0EsYUFBS0YsVUFBTCxDQUFnQmtDLFNBQWhCLENBQTBCLE9BQTFCLEVBQWtDLEtBQUt2QyxXQUF2QztBQUNBLGFBQUtLLFVBQUwsQ0FBZ0JtQyxVQUFoQixDQUEyQixPQUEzQjtBQUNBLGFBQUtuQyxVQUFMLENBQWdCb0MsU0FBaEIsQ0FBMEIsS0FBS2hDLFlBQS9CLEVBQTRDLEtBQTVDO0FBQ0EsYUFBS0osVUFBTCxDQUFnQmtDLFNBQWhCLENBQTBCLEtBQTFCLEVBQWdDLEtBQUt2QyxXQUFyQztBQUNBLGFBQUtLLFVBQUwsQ0FBZ0JtQyxVQUFoQixDQUEyQixLQUEzQjtBQUNBLGFBQUtuQyxVQUFMLENBQWdCb0MsU0FBaEIsQ0FBMEIsS0FBSy9CLE9BQS9CLEVBQXVDLE9BQXZDO0FBQ0EsYUFBS0wsVUFBTCxDQUFnQmtDLFNBQWhCLENBQTBCLE9BQTFCLEVBQWtDLEtBQUt2QyxXQUF2QztBQUNBLGFBQUtLLFVBQUwsQ0FBZ0JtQyxVQUFoQixDQUEyQixPQUEzQjtBQUNBLGFBQUtuQyxVQUFMLENBQWdCb0MsU0FBaEIsQ0FBMEIsS0FBSzlCLGNBQS9CLEVBQThDLEtBQTlDO0FBQ0EsYUFBS04sVUFBTCxDQUFnQmtDLFNBQWhCLENBQTBCLEtBQTFCLEVBQWdDLEtBQUt2QyxXQUFyQztBQUNBLGFBQUtLLFVBQUwsQ0FBZ0JtQyxVQUFoQixDQUEyQixLQUEzQjtBQUNBLGFBQUtaLFlBQUwsQ0FBa0IsWUFBVTtBQUN4QixlQUFLRixnQkFBTCxDQUFzQixxREFBdEI7QUFDSCxTQUZpQixDQUVoQlEsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWEsQ0FGYjtBQUdBOztBQUNKLFdBQUssQ0FBTDtBQUNJLGFBQUtYLGVBQUwsQ0FBcUIsTUFBckI7QUFDQSxhQUFLdkIsV0FBTCxDQUFpQitCLE1BQWpCLEdBQXdCLEtBQXhCO0FBQ0EsYUFBSzlCLGFBQUwsQ0FBbUI4QixNQUFuQixHQUEwQixJQUExQjtBQUNBLGFBQUsxQixVQUFMLENBQWdCa0MsU0FBaEIsQ0FBMEIsTUFBMUIsRUFBaUMsS0FBS3RDLGFBQXRDO0FBQ0EsYUFBS0ksVUFBTCxDQUFnQm1DLFVBQWhCLENBQTJCLE1BQTNCO0FBQ0E7O0FBQ0osV0FBSyxDQUFMO0FBQ0ksYUFBS3ZDLGFBQUwsQ0FBbUI4QixNQUFuQixHQUEwQixLQUExQjtBQUNBLGFBQUs3QixZQUFMLENBQWtCNkIsTUFBbEIsR0FBeUIsSUFBekI7QUFDQSxhQUFLMUIsVUFBTCxDQUFnQm9DLFNBQWhCLENBQTBCLEtBQUsvQixPQUEvQixFQUF1QyxPQUF2QztBQUNBLGFBQUtMLFVBQUwsQ0FBZ0JrQyxTQUFoQixDQUEwQixPQUExQixFQUFrQyxLQUFLckMsWUFBdkM7QUFDQSxhQUFLRyxVQUFMLENBQWdCbUMsVUFBaEIsQ0FBMkIsT0FBM0I7QUFDQSxhQUFLbkMsVUFBTCxDQUFnQm9DLFNBQWhCLENBQTBCLEtBQUs5QixjQUEvQixFQUE4QyxLQUE5QztBQUNBLGFBQUtOLFVBQUwsQ0FBZ0JrQyxTQUFoQixDQUEwQixLQUExQixFQUFnQyxLQUFLckMsWUFBckM7QUFDQSxhQUFLRyxVQUFMLENBQWdCbUMsVUFBaEIsQ0FBMkIsS0FBM0I7QUFDQSxhQUFLbkMsVUFBTCxDQUFnQm9DLFNBQWhCLENBQTBCLEtBQUs3QixlQUEvQixFQUErQyxJQUEvQztBQUNBLGFBQUtQLFVBQUwsQ0FBZ0JrQyxTQUFoQixDQUEwQixJQUExQixFQUErQixLQUFLckMsWUFBcEM7QUFDQSxhQUFLRyxVQUFMLENBQWdCbUMsVUFBaEIsQ0FBMkIsSUFBM0I7QUFDQSxhQUFLZCxnQkFBTCxDQUFzQiwwREFBdEI7QUFDQTs7QUFDSixXQUFLLENBQUw7QUFDSSxhQUFLSCxlQUFMLENBQXFCLFdBQXJCO0FBQ0EsYUFBS3JCLFlBQUwsQ0FBa0I2QixNQUFsQixHQUF5QixLQUF6QjtBQUNBLGFBQUs1QixRQUFMLENBQWM0QixNQUFkLEdBQXFCLElBQXJCO0FBQ0EsYUFBSzFCLFVBQUwsQ0FBZ0JvQyxTQUFoQixDQUEwQixLQUFLNUIsZUFBL0IsRUFBK0MsSUFBL0M7QUFDQSxhQUFLUixVQUFMLENBQWdCa0MsU0FBaEIsQ0FBMEIsSUFBMUIsRUFBK0IsS0FBS3BDLFFBQXBDO0FBQ0EsYUFBS0UsVUFBTCxDQUFnQm1DLFVBQWhCLENBQTJCLElBQTNCO0FBQ0EsYUFBS2QsZ0JBQUwsQ0FBc0IsOEVBQXRCO0FBQ0E7O0FBQ0osV0FBSyxDQUFMO0FBQ0ksYUFBS3ZCLFFBQUwsQ0FBYzRCLE1BQWQsR0FBcUIsS0FBckI7QUFDQSxhQUFLM0IsUUFBTCxDQUFjMkIsTUFBZCxHQUFxQixJQUFyQjtBQUNBLGFBQUtMLGdCQUFMLENBQXNCLHFDQUF0QjtBQUNBLGFBQUtFLFlBQUwsQ0FBa0IsWUFBVTtBQUN4QixlQUFLTCxlQUFMLENBQXFCLE1BQXJCO0FBQ0FoQyxVQUFBQSxFQUFFLENBQUNzQyxXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2hCLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0EsZUFBS1ksZ0JBQUwsQ0FBc0IsbUVBQXRCO0FBQ0EsZUFBS0UsWUFBTCxDQUFrQixZQUFVO0FBQ3hCO0FBQ0FyQyxZQUFBQSxFQUFFLENBQUNzQyxXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2hCLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0EsaUJBQUtTLGVBQUwsQ0FBcUIsTUFBckI7QUFDQSxpQkFBS0csZ0JBQUwsQ0FBc0IsNERBQXRCO0FBQ0EsaUJBQUtFLFlBQUwsQ0FBa0IsWUFBVTtBQUN4QnJDLGNBQUFBLEVBQUUsQ0FBQ3NDLFdBQUgsQ0FBZUMsVUFBZixDQUEwQixLQUFLaEIsV0FBL0IsRUFBMkMsS0FBM0M7QUFDQSxtQkFBS1ksZ0JBQUwsQ0FBc0IsMENBQXRCO0FBQ0EsbUJBQUtFLFlBQUwsQ0FBa0IsWUFBVTtBQUV4QixxQkFBS0YsZ0JBQUwsQ0FBc0Isb0NBQXRCO0FBQ0EscUJBQUtDLFFBQUw7QUFDSCxlQUppQixDQUloQk8sSUFKZ0IsQ0FJWCxJQUpXLENBQWxCLEVBSWEsQ0FKYjtBQUtILGFBUmlCLENBUWhCQSxJQVJnQixDQVFYLElBUlcsQ0FBbEIsRUFRYSxDQVJiO0FBU0gsV0FkaUIsQ0FjaEJBLElBZGdCLENBY1gsSUFkVyxDQUFsQixFQWNhLENBZGI7QUFlSCxTQW5CaUIsQ0FtQmhCQSxJQW5CZ0IsQ0FtQlgsSUFuQlcsQ0FBbEIsRUFtQmEsQ0FuQmI7QUEvRFI7QUFzRkgsR0FoSkk7QUFrSkxRLEVBQUFBLGFBbEpLLDJCQWtKVTtBQUNYbkQsSUFBQUEsRUFBRSxDQUFDNEIsUUFBSCxDQUFZd0IsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBcEpJO0FBc0pMQyxFQUFBQSxTQXRKSyx1QkFzSk07QUFDUHJELElBQUFBLEVBQUUsQ0FBQzRCLFFBQUgsQ0FBWXdCLFNBQVosQ0FBc0IsTUFBdEI7QUFDSCxHQXhKSTtBQTBKTEUsRUFBQUEsUUExSkssc0JBMEpLO0FBQ050RCxJQUFBQSxFQUFFLENBQUM0QixRQUFILENBQVl3QixTQUFaLENBQXNCLE1BQXRCO0FBQ0g7QUE1SkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHRvcFByb21wdDpjYy5MYWJlbCxcclxuICAgICAgICBzaWRlUHJvbXB0OmNjLkxhYmVsLFxyXG4gICAgICAgIHRoYXdTY2VuZVNlY29uZFBhcnQ6Y2MuTm9kZSxcclxuICAgICAgICBsaWVqaWVTY2VuZTpjYy5Ob2RlLFxyXG4gICAgICAgIHpoZW5kYW5nU2NlbmU6Y2MuTm9kZSxcclxuICAgICAgICBmZW5jZW5nU2NlbmU6Y2MuTm9kZSxcclxuICAgICAgICBwY3JTY2VuZTpjYy5Ob2RlLFxyXG4gICAgICAgIGNlbGxUZXN0OmNjLk5vZGUsXHJcbiAgICAgICAgZmluYWxseTpjYy5Ob2RlLFxyXG4gICAgICAgIGl0ZW1MYXlPdXQ6Y2MuTm9kZSxcclxuXHJcbiAgICAgICAgc3RhZ2U6MCxcclxuICAgICAgICBzaW1wbGVCb3g6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgbGllamllTGlxdWlkOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIHBpcGV0dGU6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgY2VudHJpZnVnZVR1YmU6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgY2VudHJpZnVnZVR1YmUyOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGNlbnRyaWZ1Z2VUdWJlMzpjYy5TcHJpdGVGcmFtZSxcclxuICAgICAgICBzdWNjZXNzQ2xpcDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5BdWRpb0NsaXBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZpbmFsQ2xpcDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5BdWRpb0NsaXBcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8wOuino+WGu1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLml0ZW1MYXlPdXQ9dGhpcy5pdGVtTGF5T3V0LmdldENvbXBvbmVudChcInlfaXRlbUNvbnRyb2xcIik7XHJcbiAgICB9LFxyXG4gICAgY2hhbmdlVG9wUHJvbXB0KHN0cil7XHJcbiAgICAgICAgdGhpcy50b3BQcm9tcHQuc3RyaW5nPXN0cjtcclxuICAgIH0sXHJcbiAgICBjaGFuZ2VTaWRlUHJvbXB0KHN0cil7XHJcbiAgICAgICAgdGhpcy5zaWRlUHJvbXB0LnN0cmluZz1zdHI7XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBjYWxsRXhpdCgpe1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5maW5hbENsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLmZpbmFsbHkuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuZmluYWxseS5ydW5BY3Rpb24oY2MubW92ZVRvKDEsMCwwKSk7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLDUpO1xyXG4gICAgfSxcclxuICAgIGNoYW5nZVN0YWdlKG51bSl7XHJcbiAgICAgICAgdGhpcy5zdGFnZT1udW07XHJcbiAgICAgICAgc3dpdGNoKG51bSl7XHJcbiAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6L+b5YWl6Kej5Ya7566x6Zi25q61XCIgKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlVG9wUHJvbXB0KFwi5qC35ZOB6Kej5Ya7XCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LnNldFBhcmVudChcIuagt+WTgeavkuagqlwiLHRoaXMudGhhd1NjZW5lU2Vjb25kUGFydCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuc2V0TW92YWJsZShcIuagt+WTgeavkuagqlwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU2lkZVByb21wdChcIuivt+Wwhuagt+WTgeaLluaUvuWFpVxcbueUn+eJqeWuieWFqOafnFxcbui/m+ihjOino+WGu1wiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMudGhhd1NjZW5lU2Vjb25kUGFydC5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRoYXdTY2VuZVNlY29uZFBhcnQuYWN0aXZlPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5saWVqaWVTY2VuZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlVG9wUHJvbXB0KFwi55eF5q+S6KOC6KejXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0Lm5vcm1hbEFkZCh0aGlzLnNpbXBsZUJveCxcIuW3suino+WGu+avkuagqlwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRQYXJlbnQoXCLlt7Lop6Plhrvmr5LmoKpcIix0aGlzLmxpZWppZVNjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi5bey6Kej5Ya75q+S5qCqXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0Lm5vcm1hbEFkZCh0aGlzLmxpZWppZUxpcXVpZCxcIuijguino+a2slwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRQYXJlbnQoXCLoo4Lop6PmtrJcIix0aGlzLmxpZWppZVNjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi6KOC6Kej5rayXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0Lm5vcm1hbEFkZCh0aGlzLnBpcGV0dGUsXCLlvq7ph4/np7vmtrLnrqFcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuc2V0UGFyZW50KFwi5b6u6YeP56e75ray566hXCIsdGhpcy5saWVqaWVTY2VuZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuc2V0TW92YWJsZShcIuW+rumHj+enu+a2sueuoVwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5ub3JtYWxBZGQodGhpcy5jZW50cmlmdWdlVHViZSxcIuemu+W/g+euoVwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRQYXJlbnQoXCLnprvlv4PnrqFcIix0aGlzLmxpZWppZVNjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi56a75b+D566hXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVNpZGVQcm9tcHQoJ+aguOmFuOebuOW9k+S6jueXheavkueahFwi6Lqr5Lu96K+BXCIsXFxu5Zyo56CU56m25YmN6aaW5YWI6KaB5o+Q5Y+W5qC46YW444CCXFxu6K+35bCG55eF5q+S5qC35ZOB5Y+W5Yiw5b6u56a75b+D566h5LitLFxcbuazqOWFpeijguino+a2sicpO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDIpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlVG9wUHJvbXB0KFwi5qC46YW45o+Q5Y+WXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5saWVqaWVTY2VuZS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnpoZW5kYW5nU2NlbmUuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuc2V0UGFyZW50KFwi5re35ZCI6K+V5YmCXCIsdGhpcy56aGVuZGFuZ1NjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi5re35ZCI6K+V5YmCXCIpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgNDpcclxuICAgICAgICAgICAgICAgIHRoaXMuemhlbmRhbmdTY2VuZS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmZlbmNlbmdTY2VuZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5ub3JtYWxBZGQodGhpcy5waXBldHRlLFwi5b6u6YeP56e75ray566hXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LnNldFBhcmVudChcIuW+rumHj+enu+a2sueuoVwiLHRoaXMuZmVuY2VuZ1NjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi5b6u6YeP56e75ray566hXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0Lm5vcm1hbEFkZCh0aGlzLmNlbnRyaWZ1Z2VUdWJlLFwi56a75b+D566hXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LnNldFBhcmVudChcIuemu+W/g+euoVwiLHRoaXMuZmVuY2VuZ1NjZW5lKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRNb3ZhYmxlKFwi56a75b+D566hXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0Lm5vcm1hbEFkZCh0aGlzLmNlbnRyaWZ1Z2VUdWJlMixcIuagt+WTgVwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXRlbUxheU91dC5zZXRQYXJlbnQoXCLmoLflk4FcIix0aGlzLmZlbmNlbmdTY2VuZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuc2V0TW92YWJsZShcIuagt+WTgVwiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU2lkZVByb21wdChcIueXheavkueahOibi+eZvei0qOWkluWjs+W3sueTpuino++8jFxcbueXheavkueahOaguOmFuOa1geWHulxcbue7j+i/h+mch+iNoeemu+W/g+WkhOeQhuWQjlxcbueXheavkuaguOmFuOWkp+mHj1xcbuWtmOWcqOS6juWcqOS4i+Wxgu+8jFxcbuivt+WwhuWFtuWPluWHulwiKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVRvcFByb21wdChcIuiNp+WFieWumumHj1BDUuajgOa1i1wiKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuZmVuY2VuZ1NjZW5lLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucGNyU2NlbmUuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQubm9ybWFsQWRkKHRoaXMuY2VudHJpZnVnZVR1YmUzLFwi5qC35ZOBXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LnNldFBhcmVudChcIuagt+WTgVwiLHRoaXMucGNyU2NlbmUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pdGVtTGF5T3V0LnNldE1vdmFibGUoXCLmoLflk4FcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVNpZGVQcm9tcHQoXCLojaflhYnlrprph49QQ1Lmo4DmtYtcXG7mmK/pgJrov4fojaflhYnmn5PmlpnmiJbojaflhYnmoIforrBcXG7nmoTnibnlvILmgKfnmoTmjqLpkojvvIxcXG7lr7lQQ1Lkuqfnianov5vooYzmoIforrDot5/ouKpcXG7lgJ/liqnov5npobnmioDmnK9cXG7miJHku6zlj6/ku6Xmo4DmtYvlvZPliY1cXG7moLflk4HmmK/lkKbmmK/miYDpnIDnl4Xmr5JcIik7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSA2OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5wY3JTY2VuZS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNlbGxUZXN0LmFjdGl2ZT10cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTaWRlUHJvbXB0KFwiUENS5qOA5rWL5bey6YCa6L+HXFxu56Gu6K6k5piv5omA6ZyA55eF5q+SXFxu56ym5ZCI55ar6IuX56CU5Yi26KaB5rGCXFxu5Y+v5Lul6L+b6KGM5omp5aKeXCIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVRvcFByb21wdChcIuaJqeWinuWunumqjFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU2lkZVByb21wdChcIuaOpeS4i+adpeeXheavkuWwhuiiq+aOpeenjeWIsFxcbifnu4bog57lt6XljoIn5Lit6L+b6KGM5qOA5rWLXFxu5bem5L6n55qE55O25a2Q5L6/5piv57uG6IOe5bel5Y6CXFxu5oiR5Lus6IO95aSf6YCa6L+H5qOA5rWLXFxu55eF5q+S55qE5L615p+T54q25Ya1XFxu6L+b6ICM5Yik5pat55eF5q+S5rS75oCnXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vdGhpcy5jZWxsVGVzdC5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5zdWNjZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlVG9wUHJvbXB0KFwi5ZCO57ut5q2l6aqkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVNpZGVQcm9tcHQoXCLnlqvoi5fnoJTliLbnmoTov4fnqIvmmK/pnZ7luLjlpI3mnYLnmoRcXG7ov5vooYzliLDov5nkuIDmraVcXG7miJHku6zku4Xog73ojrflj5bliLDlj6/og71cXG7lj6/ku6Xov5vooYznlqvoi5fliLbpgKDnmoTmr5LmoKpcXG7lkI7pnaLov5jopoHov5vooYzlpKfph4/nmoTmo4DmtYtcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTaWRlUHJvbXB0KFwi5YyF5ous54Gt5rS755eF5q+S55uy5Lyg5LiJ5Luj5qOA5rWLXFxu5aSa5pyf55qE5Yqo54mp5a6e6aqM44CB5Lq65L2T5a6e6aqMXFxu5pyJ5pWI5oCn6K+E5Lu35a6J5YWo5oCn6K+E5Lu3562J562JXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTaWRlUHJvbXB0KFwi56eR56CU55qE6L+H56iL5piv6Imw6L6b6ICM5Y+I5aSN5p2C55qEXFxu6K6p5oiR5Lus5ZCR5aWL5oiY5Zyo5LiA57q/55qEXFxu56eR56CU5bel5L2c6ICF6Ie05pWsXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsbEV4aXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSw1KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSw1KTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSw1KTtcclxuXHJcblxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgcmV0dXJuT25DbGljaygpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIuihlOaOpeWcuuaZr1wiKTtcclxuICAgIH0sXHJcblxyXG4gICAgYWdhaW5DdHJsKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi55ar6IuX56CU5Yi2XCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBleGl0Q3RybCgpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIuihlOaOpeWcuuaZr1wiKTtcclxuICAgIH1cclxufSk7XHJcbiJdfQ==