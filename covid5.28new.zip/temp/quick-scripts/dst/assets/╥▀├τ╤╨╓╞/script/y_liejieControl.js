
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/疫苗研制/script/y_liejieControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1d751+O3ylOWJlsqt5ucPmZ', 'y_liejieControl');
// 疫苗研制/script/y_liejieControl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    stage: 0,
    //0:还未进行任何操作
    //1：将病毒从样品中取出
    //2：病毒注入微液管
    //3：取裂解液
    //4：裂解液注入微液管
    processing: 0,
    itemLayOut: cc.Node,
    sceneControl: cc.Node,
    lixinguan1: cc.SpriteFrame,
    lixinguan2: cc.SpriteFrame,
    workButton: cc.Button,
    buttonLabel: cc.Label,
    successClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.workButton.node.active = false;
    this.itemLayOut = this.itemLayOut.getComponent("y_itemControl");
    this.sceneControl = this.sceneControl.getComponent("y_sceneController");
  },
  moveProcess: function moveProcess(self, other) {
    var selfName = self.name;
    var otherName = other.name;

    switch (this.stage) {
      case 0:
        if (selfName == "已解冻毒株" && otherName == "微量移液管" || selfName == "微量移液管" && otherName == "已解冻毒株") {
          this.workButton.node.active = true;
          this.processing = 1;
          this.buttonLabel.string = "将病毒样品取出";
          cc.audioEngine.playEffect(this.successClip, false);
        }

        break;

      case 1:
        if (selfName == "离心管" && otherName == "微量移液管" || selfName == "微量移液管" && otherName == "离心管") {
          this.workButton.node.active = true;
          this.processing = 1;
          this.buttonLabel.string = "将病毒样品\n注入离心管";
          cc.audioEngine.playEffect(this.successClip, false);
        }

        break;

      case 2:
        if (selfName == "裂解液" && otherName == "微量移液管" || selfName == "微量移液管" && otherName == "裂解液") {
          this.workButton.node.active = true;
          this.processing = 1;
          this.buttonLabel.string = "将病毒裂解液取出";
          cc.audioEngine.playEffect(this.successClip, false);
        }

        break;

      case 3:
        if (selfName == "离心管" && otherName == "微量移液管" || selfName == "微量移液管" && otherName == "离心管") {
          this.workButton.node.active = true;
          this.processing = 1;
          this.buttonLabel.string = "将裂解液\n注入离心管";
          cc.audioEngine.playEffect(this.successClip, false);
        }

        break;
    }
  },
  workButtonOnClick: function workButtonOnClick() {
    if (this.processing == 1) {
      switch (this.stage) {
        case 0:
          var node = this.node.getChildByName("已解冻毒株");

          if (node != undefined) {
            console.log('node :>> ', this.itemLayOut.node.getChildren());
            node.runAction(cc.fadeOut(0.5));
            this.scheduleOnce(function () {
              node.destroy();
            }.bind(this), 0.5);
            this.stage = 1;
            this.processing = 0;
            this.workButton.node.active = false;
            cc.audioEngine.playEffect(this.successClip, false);
          }

          break;

        case 1:
          var node = this.node.getChildByName("离心管");

          if (node != undefined) {
            node.getComponent(cc.Sprite).spriteFrame = this.lixinguan1;
            this.stage = 2;
            this.processing = 0;
            this.workButton.node.active = false;
            cc.audioEngine.playEffect(this.successClip, false);
          }

          break;

        case 2:
          var node = this.node.getChildByName("裂解液");

          if (node != undefined) {
            node.runAction(cc.fadeOut(0.5));
            this.scheduleOnce(function () {
              node.destroy();
            }.bind(this), 0.5);
            this.stage = 3;
            this.processing = 0;
            this.workButton.node.active = false;
            cc.audioEngine.playEffect(this.successClip, false);
          }

          break;

        case 3:
          var node1 = this.node.getChildByName("离心管");
          var node2 = this.node.getChildByName("微量移液管");
          cc.audioEngine.playEffect(this.successClip, false);

          if (node1 != undefined && node2 != undefined) {
            node1.getComponent(cc.Sprite).spriteFrame = this.lixinguan2;
            node2.runAction(cc.fadeOut(0.5));
            this.scheduleOnce(function () {
              node2.destroy();
            }.bind(this), 1);
            this.itemLayOut.add(node1, "混合试剂", [], 1);
            this.scheduleOnce(function () {
              this.sceneControl.changeSidePrompt("请将病毒裂解液\n放在涡旋振荡器上\n进行震荡，\n充分混匀");
              this.scheduleOnce(function () {
                this.sceneControl.changeStage(3);
              }.bind(this), 2);
            }.bind(this), 1.5);
            this.stage = 4;
            this.processing = 0;
            this.workButton.node.active = false;
          }

          break;
      }
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc55ar6IuX56CU5Yi2XFxzY3JpcHRcXHlfbGllamllQ29udHJvbC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YWdlIiwicHJvY2Vzc2luZyIsIml0ZW1MYXlPdXQiLCJOb2RlIiwic2NlbmVDb250cm9sIiwibGl4aW5ndWFuMSIsIlNwcml0ZUZyYW1lIiwibGl4aW5ndWFuMiIsIndvcmtCdXR0b24iLCJCdXR0b24iLCJidXR0b25MYWJlbCIsIkxhYmVsIiwic3VjY2Vzc0NsaXAiLCJ0eXBlIiwiQXVkaW9DbGlwIiwic3RhcnQiLCJub2RlIiwiYWN0aXZlIiwiZ2V0Q29tcG9uZW50IiwibW92ZVByb2Nlc3MiLCJzZWxmIiwib3RoZXIiLCJzZWxmTmFtZSIsIm5hbWUiLCJvdGhlck5hbWUiLCJzdHJpbmciLCJhdWRpb0VuZ2luZSIsInBsYXlFZmZlY3QiLCJ3b3JrQnV0dG9uT25DbGljayIsImdldENoaWxkQnlOYW1lIiwidW5kZWZpbmVkIiwiY29uc29sZSIsImxvZyIsImdldENoaWxkcmVuIiwicnVuQWN0aW9uIiwiZmFkZU91dCIsInNjaGVkdWxlT25jZSIsImRlc3Ryb3kiLCJiaW5kIiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJub2RlMSIsIm5vZGUyIiwiYWRkIiwiY2hhbmdlU2lkZVByb21wdCIsImNoYW5nZVN0YWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsS0FBSyxFQUFDLENBREU7QUFFUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLElBQUFBLFVBQVUsRUFBQyxDQVBIO0FBUVJDLElBQUFBLFVBQVUsRUFBQ04sRUFBRSxDQUFDTyxJQVJOO0FBU1JDLElBQUFBLFlBQVksRUFBQ1IsRUFBRSxDQUFDTyxJQVRSO0FBVVJFLElBQUFBLFVBQVUsRUFBQ1QsRUFBRSxDQUFDVSxXQVZOO0FBV1JDLElBQUFBLFVBQVUsRUFBQ1gsRUFBRSxDQUFDVSxXQVhOO0FBWVJFLElBQUFBLFVBQVUsRUFBQ1osRUFBRSxDQUFDYSxNQVpOO0FBYVJDLElBQUFBLFdBQVcsRUFBQ2QsRUFBRSxDQUFDZSxLQWJQO0FBY1JDLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUkMsTUFBQUEsSUFBSSxFQUFDakIsRUFBRSxDQUFDa0I7QUFGQTtBQWRKLEdBSFA7QUF1Qkw7QUFFQTtBQUVBQyxFQUFBQSxLQTNCSyxtQkEyQkk7QUFDTCxTQUFLUCxVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsS0FBNUI7QUFDQSxTQUFLZixVQUFMLEdBQWdCLEtBQUtBLFVBQUwsQ0FBZ0JnQixZQUFoQixDQUE2QixlQUE3QixDQUFoQjtBQUNBLFNBQUtkLFlBQUwsR0FBa0IsS0FBS0EsWUFBTCxDQUFrQmMsWUFBbEIsQ0FBK0IsbUJBQS9CLENBQWxCO0FBQ0gsR0EvQkk7QUFpQ0xDLEVBQUFBLFdBakNLLHVCQWlDT0MsSUFqQ1AsRUFpQ1lDLEtBakNaLEVBaUNrQjtBQUNuQixRQUFJQyxRQUFRLEdBQUNGLElBQUksQ0FBQ0csSUFBbEI7QUFDQSxRQUFJQyxTQUFTLEdBQUNILEtBQUssQ0FBQ0UsSUFBcEI7O0FBQ0EsWUFBTyxLQUFLdkIsS0FBWjtBQUNJLFdBQUssQ0FBTDtBQUNJLFlBQUlzQixRQUFRLElBQUUsT0FBVixJQUFtQkUsU0FBUyxJQUFFLE9BQS9CLElBQTBDRixRQUFRLElBQUUsT0FBVixJQUFtQkUsU0FBUyxJQUFFLE9BQTNFLEVBQW9GO0FBQ2hGLGVBQUtoQixVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsSUFBNUI7QUFDQSxlQUFLaEIsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGVBQUtTLFdBQUwsQ0FBaUJlLE1BQWpCLEdBQXdCLFNBQXhCO0FBQ0E3QixVQUFBQSxFQUFFLENBQUM4QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2YsV0FBL0IsRUFBMkMsS0FBM0M7QUFDSDs7QUFDRDs7QUFDSixXQUFLLENBQUw7QUFDSSxZQUFJVSxRQUFRLElBQUUsS0FBVixJQUFpQkUsU0FBUyxJQUFFLE9BQTdCLElBQXdDRixRQUFRLElBQUUsT0FBVixJQUFtQkUsU0FBUyxJQUFFLEtBQXpFLEVBQWdGO0FBQzVFLGVBQUtoQixVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsSUFBNUI7QUFDQSxlQUFLaEIsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGVBQUtTLFdBQUwsQ0FBaUJlLE1BQWpCLEdBQXdCLGNBQXhCO0FBQ0E3QixVQUFBQSxFQUFFLENBQUM4QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2YsV0FBL0IsRUFBMkMsS0FBM0M7QUFDSDs7QUFDRDs7QUFDSixXQUFLLENBQUw7QUFDSSxZQUFJVSxRQUFRLElBQUUsS0FBVixJQUFpQkUsU0FBUyxJQUFFLE9BQTdCLElBQXdDRixRQUFRLElBQUUsT0FBVixJQUFtQkUsU0FBUyxJQUFFLEtBQXpFLEVBQWdGO0FBQzVFLGVBQUtoQixVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsSUFBNUI7QUFDQSxlQUFLaEIsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGVBQUtTLFdBQUwsQ0FBaUJlLE1BQWpCLEdBQXdCLFVBQXhCO0FBQ0E3QixVQUFBQSxFQUFFLENBQUM4QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2YsV0FBL0IsRUFBMkMsS0FBM0M7QUFDSDs7QUFDRDs7QUFDSixXQUFLLENBQUw7QUFDSSxZQUFJVSxRQUFRLElBQUUsS0FBVixJQUFpQkUsU0FBUyxJQUFFLE9BQTdCLElBQXdDRixRQUFRLElBQUUsT0FBVixJQUFtQkUsU0FBUyxJQUFFLEtBQXpFLEVBQWdGO0FBQzVFLGVBQUtoQixVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsSUFBNUI7QUFDQSxlQUFLaEIsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGVBQUtTLFdBQUwsQ0FBaUJlLE1BQWpCLEdBQXdCLGFBQXhCO0FBQ0E3QixVQUFBQSxFQUFFLENBQUM4QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2YsV0FBL0IsRUFBMkMsS0FBM0M7QUFDSDs7QUFDRDtBQWhDUjtBQWtDSCxHQXRFSTtBQXlFTGdCLEVBQUFBLGlCQXpFSywrQkF5RWM7QUFDZixRQUFHLEtBQUszQixVQUFMLElBQWlCLENBQXBCLEVBQXNCO0FBQ2xCLGNBQU8sS0FBS0QsS0FBWjtBQUNJLGFBQUssQ0FBTDtBQUNJLGNBQUlnQixJQUFJLEdBQUMsS0FBS0EsSUFBTCxDQUFVYSxjQUFWLENBQXlCLE9BQXpCLENBQVQ7O0FBQ0EsY0FBR2IsSUFBSSxJQUFFYyxTQUFULEVBQW1CO0FBQ2ZDLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBeUIsS0FBSzlCLFVBQUwsQ0FBZ0JjLElBQWhCLENBQXFCaUIsV0FBckIsRUFBekI7QUFDQWpCLFlBQUFBLElBQUksQ0FBQ2tCLFNBQUwsQ0FBZXRDLEVBQUUsQ0FBQ3VDLE9BQUgsQ0FBVyxHQUFYLENBQWY7QUFDQSxpQkFBS0MsWUFBTCxDQUFrQixZQUFVO0FBQUNwQixjQUFBQSxJQUFJLENBQUNxQixPQUFMO0FBQWdCLGFBQTNCLENBQTRCQyxJQUE1QixDQUFpQyxJQUFqQyxDQUFsQixFQUF5RCxHQUF6RDtBQUNBLGlCQUFLdEMsS0FBTCxHQUFXLENBQVg7QUFDQSxpQkFBS0MsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGlCQUFLTyxVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsS0FBNUI7QUFDQXJCLFlBQUFBLEVBQUUsQ0FBQzhCLFdBQUgsQ0FBZUMsVUFBZixDQUEwQixLQUFLZixXQUEvQixFQUEyQyxLQUEzQztBQUNIOztBQUVEOztBQUNKLGFBQUssQ0FBTDtBQUNJLGNBQUlJLElBQUksR0FBQyxLQUFLQSxJQUFMLENBQVVhLGNBQVYsQ0FBeUIsS0FBekIsQ0FBVDs7QUFDQSxjQUFHYixJQUFJLElBQUVjLFNBQVQsRUFBbUI7QUFDZmQsWUFBQUEsSUFBSSxDQUFDRSxZQUFMLENBQWtCdEIsRUFBRSxDQUFDMkMsTUFBckIsRUFBNkJDLFdBQTdCLEdBQXlDLEtBQUtuQyxVQUE5QztBQUNBLGlCQUFLTCxLQUFMLEdBQVcsQ0FBWDtBQUNBLGlCQUFLQyxVQUFMLEdBQWdCLENBQWhCO0FBQ0EsaUJBQUtPLFVBQUwsQ0FBZ0JRLElBQWhCLENBQXFCQyxNQUFyQixHQUE0QixLQUE1QjtBQUNBckIsWUFBQUEsRUFBRSxDQUFDOEIsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtmLFdBQS9CLEVBQTJDLEtBQTNDO0FBQ0g7O0FBQ0Q7O0FBQ0osYUFBSyxDQUFMO0FBQ0ksY0FBSUksSUFBSSxHQUFDLEtBQUtBLElBQUwsQ0FBVWEsY0FBVixDQUF5QixLQUF6QixDQUFUOztBQUNBLGNBQUdiLElBQUksSUFBRWMsU0FBVCxFQUFtQjtBQUNmZCxZQUFBQSxJQUFJLENBQUNrQixTQUFMLENBQWV0QyxFQUFFLENBQUN1QyxPQUFILENBQVcsR0FBWCxDQUFmO0FBQ0EsaUJBQUtDLFlBQUwsQ0FBa0IsWUFBVTtBQUFDcEIsY0FBQUEsSUFBSSxDQUFDcUIsT0FBTDtBQUFnQixhQUEzQixDQUE0QkMsSUFBNUIsQ0FBaUMsSUFBakMsQ0FBbEIsRUFBeUQsR0FBekQ7QUFDQSxpQkFBS3RDLEtBQUwsR0FBVyxDQUFYO0FBQ0EsaUJBQUtDLFVBQUwsR0FBZ0IsQ0FBaEI7QUFDQSxpQkFBS08sVUFBTCxDQUFnQlEsSUFBaEIsQ0FBcUJDLE1BQXJCLEdBQTRCLEtBQTVCO0FBQ0FyQixZQUFBQSxFQUFFLENBQUM4QixXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS2YsV0FBL0IsRUFBMkMsS0FBM0M7QUFDSDs7QUFDRDs7QUFDSixhQUFLLENBQUw7QUFDSSxjQUFJNkIsS0FBSyxHQUFDLEtBQUt6QixJQUFMLENBQVVhLGNBQVYsQ0FBeUIsS0FBekIsQ0FBVjtBQUNBLGNBQUlhLEtBQUssR0FBQyxLQUFLMUIsSUFBTCxDQUFVYSxjQUFWLENBQXlCLE9BQXpCLENBQVY7QUFDQWpDLFVBQUFBLEVBQUUsQ0FBQzhCLFdBQUgsQ0FBZUMsVUFBZixDQUEwQixLQUFLZixXQUEvQixFQUEyQyxLQUEzQzs7QUFDQSxjQUFHNkIsS0FBSyxJQUFFWCxTQUFQLElBQWtCWSxLQUFLLElBQUVaLFNBQTVCLEVBQXNDO0FBQ2xDVyxZQUFBQSxLQUFLLENBQUN2QixZQUFOLENBQW1CdEIsRUFBRSxDQUFDMkMsTUFBdEIsRUFBOEJDLFdBQTlCLEdBQTBDLEtBQUtqQyxVQUEvQztBQUNBbUMsWUFBQUEsS0FBSyxDQUFDUixTQUFOLENBQWdCdEMsRUFBRSxDQUFDdUMsT0FBSCxDQUFXLEdBQVgsQ0FBaEI7QUFDQSxpQkFBS0MsWUFBTCxDQUFrQixZQUFVO0FBQUNNLGNBQUFBLEtBQUssQ0FBQ0wsT0FBTjtBQUFpQixhQUE1QixDQUE2QkMsSUFBN0IsQ0FBa0MsSUFBbEMsQ0FBbEIsRUFBMEQsQ0FBMUQ7QUFDQSxpQkFBS3BDLFVBQUwsQ0FBZ0J5QyxHQUFoQixDQUFvQkYsS0FBcEIsRUFBMEIsTUFBMUIsRUFBaUMsRUFBakMsRUFBb0MsQ0FBcEM7QUFDQSxpQkFBS0wsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLG1CQUFLaEMsWUFBTCxDQUFrQndDLGdCQUFsQixDQUFtQyxnQ0FBbkM7QUFDQSxtQkFBS1IsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLHFCQUFLaEMsWUFBTCxDQUFrQnlDLFdBQWxCLENBQThCLENBQTlCO0FBQ0gsZUFGaUIsQ0FFaEJQLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVhLENBRmI7QUFJSCxhQU5pQixDQU1oQkEsSUFOZ0IsQ0FNWCxJQU5XLENBQWxCLEVBTWEsR0FOYjtBQU9BLGlCQUFLdEMsS0FBTCxHQUFXLENBQVg7QUFDQSxpQkFBS0MsVUFBTCxHQUFnQixDQUFoQjtBQUNBLGlCQUFLTyxVQUFMLENBQWdCUSxJQUFoQixDQUFxQkMsTUFBckIsR0FBNEIsS0FBNUI7QUFDSDs7QUFFRDtBQXhEUjtBQTBESDtBQUVKLEdBdklJLENBd0lMOztBQXhJSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgc3RhZ2U6MCxcclxuICAgICAgICAvLzA66L+Y5pyq6L+b6KGM5Lu75L2V5pON5L2cXHJcbiAgICAgICAgLy8x77ya5bCG55eF5q+S5LuO5qC35ZOB5Lit5Y+W5Ye6XHJcbiAgICAgICAgLy8y77ya55eF5q+S5rOo5YWl5b6u5ray566hXHJcbiAgICAgICAgLy8z77ya5Y+W6KOC6Kej5rayXHJcbiAgICAgICAgLy8077ya6KOC6Kej5ray5rOo5YWl5b6u5ray566hXHJcbiAgICAgICAgcHJvY2Vzc2luZzowLFxyXG4gICAgICAgIGl0ZW1MYXlPdXQ6Y2MuTm9kZSxcclxuICAgICAgICBzY2VuZUNvbnRyb2w6Y2MuTm9kZSxcclxuICAgICAgICBsaXhpbmd1YW4xOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGxpeGluZ3VhbjI6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgd29ya0J1dHRvbjpjYy5CdXR0b24sXHJcbiAgICAgICAgYnV0dG9uTGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgc3VjY2Vzc0NsaXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMud29ya0J1dHRvbi5ub2RlLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICB0aGlzLml0ZW1MYXlPdXQ9dGhpcy5pdGVtTGF5T3V0LmdldENvbXBvbmVudChcInlfaXRlbUNvbnRyb2xcIik7XHJcbiAgICAgICAgdGhpcy5zY2VuZUNvbnRyb2w9dGhpcy5zY2VuZUNvbnRyb2wuZ2V0Q29tcG9uZW50KFwieV9zY2VuZUNvbnRyb2xsZXJcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIG1vdmVQcm9jZXNzKHNlbGYsb3RoZXIpe1xyXG4gICAgICAgIHZhciBzZWxmTmFtZT1zZWxmLm5hbWU7XHJcbiAgICAgICAgdmFyIG90aGVyTmFtZT1vdGhlci5uYW1lO1xyXG4gICAgICAgIHN3aXRjaCh0aGlzLnN0YWdlKXtcclxuICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgaWYoKHNlbGZOYW1lPT1cIuW3suino+WGu+avkuagqlwiJiZvdGhlck5hbWU9PVwi5b6u6YeP56e75ray566hXCIpfHwoc2VsZk5hbWU9PVwi5b6u6YeP56e75ray566hXCImJm90aGVyTmFtZT09XCLlt7Lop6Plhrvmr5LmoKpcIikpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMud29ya0J1dHRvbi5ub2RlLmFjdGl2ZT10cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucHJvY2Vzc2luZz0xO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYnV0dG9uTGFiZWwuc3RyaW5nPVwi5bCG55eF5q+S5qC35ZOB5Y+W5Ye6XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnN1Y2Nlc3NDbGlwLGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICBpZigoc2VsZk5hbWU9PVwi56a75b+D566hXCImJm90aGVyTmFtZT09XCLlvq7ph4/np7vmtrLnrqFcIil8fChzZWxmTmFtZT09XCLlvq7ph4/np7vmtrLnrqFcIiYmb3RoZXJOYW1lPT1cIuemu+W/g+euoVwiKSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy53b3JrQnV0dG9uLm5vZGUuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wcm9jZXNzaW5nPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5idXR0b25MYWJlbC5zdHJpbmc9XCLlsIbnl4Xmr5LmoLflk4FcXG7ms6jlhaXnprvlv4PnrqFcIjtcclxuICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgIGlmKChzZWxmTmFtZT09XCLoo4Lop6PmtrJcIiYmb3RoZXJOYW1lPT1cIuW+rumHj+enu+a2sueuoVwiKXx8KHNlbGZOYW1lPT1cIuW+rumHj+enu+a2sueuoVwiJiZvdGhlck5hbWU9PVwi6KOC6Kej5rayXCIpKXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLndvcmtCdXR0b24ubm9kZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3Npbmc9MTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmJ1dHRvbkxhYmVsLnN0cmluZz1cIuWwhueXheavkuijguino+a2suWPluWHulwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5zdWNjZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgaWYoKHNlbGZOYW1lPT1cIuemu+W/g+euoVwiJiZvdGhlck5hbWU9PVwi5b6u6YeP56e75ray566hXCIpfHwoc2VsZk5hbWU9PVwi5b6u6YeP56e75ray566hXCImJm90aGVyTmFtZT09XCLnprvlv4PnrqFcIikpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMud29ya0J1dHRvbi5ub2RlLmFjdGl2ZT10cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucHJvY2Vzc2luZz0xO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYnV0dG9uTGFiZWwuc3RyaW5nPVwi5bCG6KOC6Kej5rayXFxu5rOo5YWl56a75b+D566hXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnN1Y2Nlc3NDbGlwLGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxuXHJcbiAgICB3b3JrQnV0dG9uT25DbGljaygpe1xyXG4gICAgICAgIGlmKHRoaXMucHJvY2Vzc2luZz09MSl7XHJcbiAgICAgICAgICAgIHN3aXRjaCh0aGlzLnN0YWdlKXtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbm9kZT10aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCLlt7Lop6Plhrvmr5LmoKpcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYobm9kZSE9dW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vZGUgOj4+ICcsIHRoaXMuaXRlbUxheU91dC5ub2RlLmdldENoaWxkcmVuKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBub2RlLnJ1bkFjdGlvbihjYy5mYWRlT3V0KDAuNSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe25vZGUuZGVzdHJveSgpO30uYmluZCh0aGlzKSwwLjUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YWdlPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucHJvY2Vzc2luZz0wO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndvcmtCdXR0b24ubm9kZS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5zdWNjZXNzQ2xpcCxmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIHZhciBub2RlPXRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIuemu+W/g+euoVwiKTtcclxuICAgICAgICAgICAgICAgICAgICBpZihub2RlIT11bmRlZmluZWQpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBub2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lPXRoaXMubGl4aW5ndWFuMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGFnZT0yO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3Npbmc9MDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53b3JrQnV0dG9uLm5vZGUuYWN0aXZlPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbm9kZT10aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCLoo4Lop6PmtrJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYobm9kZSE9dW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5ydW5BY3Rpb24oY2MuZmFkZU91dCgwLjUpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtub2RlLmRlc3Ryb3koKTt9LmJpbmQodGhpcyksMC41KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGFnZT0zO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3Npbmc9MDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53b3JrQnV0dG9uLm5vZGUuYWN0aXZlPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuc3VjY2Vzc0NsaXAsZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICB2YXIgbm9kZTE9dGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwi56a75b+D566hXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBub2RlMj10aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCLlvq7ph4/np7vmtrLnrqFcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLnN1Y2Nlc3NDbGlwLGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZihub2RlMSE9dW5kZWZpbmVkJiZub2RlMiE9dW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZTEuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9dGhpcy5saXhpbmd1YW4yO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBub2RlMi5ydW5BY3Rpb24oY2MuZmFkZU91dCgwLjUpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtub2RlMi5kZXN0cm95KCk7fS5iaW5kKHRoaXMpLDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLml0ZW1MYXlPdXQuYWRkKG5vZGUxLFwi5re35ZCI6K+V5YmCXCIsW10sMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNjZW5lQ29udHJvbC5jaGFuZ2VTaWRlUHJvbXB0KFwi6K+35bCG55eF5q+S6KOC6Kej5rayXFxu5pS+5Zyo5rah5peL5oyv6I2h5Zmo5LiKXFxu6L+b6KGM6ZyH6I2h77yMXFxu5YWF5YiG5re35YyAXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNjZW5lQ29udHJvbC5jaGFuZ2VTdGFnZSgzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksMS41KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGFnZT00O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3Npbmc9MDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53b3JrQnV0dG9uLm5vZGUuYWN0aXZlPWZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19