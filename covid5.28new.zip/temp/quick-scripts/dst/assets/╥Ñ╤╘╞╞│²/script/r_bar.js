
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/谣言破除/script/r_bar.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '85383rAv1BNZbm8xYtPezsR', 'r_bar');
// 谣言破除/script/r_bar.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    stage: 100,
    time: 10,
    processing: true,
    showLabel: cc.Label,
    globalStage: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    // this.schedule(function(){
    //     this.reset(10);
    // }.bind(this),10);
    this.globalStage = this.globalStage.getComponent("r_globalStage");
  },
  reset: function reset(time) {
    this.node.getComponent(cc.ProgressBar).progress = 1;
    this.time = time;
    this.stage = parseInt(this.node.getComponent(cc.ProgressBar).progress * this.time * 10) / 10;
    console.log("from bar" + this.stage);
  },
  update: function update(dt) {
    if (this.processing) {
      this.stage = parseInt(this.node.getComponent(cc.ProgressBar).progress * this.time * 10) / 10;

      if (this.stage < 0) {
        this.stage = 0;
      }

      if (this.stage == 0 && this.globalStage.nowStage == 0) {
        this.globalStage.exceedTime();
        this.globalStage.nowStage = 2;
      }

      this.showLabel.string = this.stage;
      this.node.getComponent(cc.ProgressBar).progress -= dt / this.time;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc6LCj6KiA56C06ZmkXFxzY3JpcHRcXHJfYmFyLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhZ2UiLCJ0aW1lIiwicHJvY2Vzc2luZyIsInNob3dMYWJlbCIsIkxhYmVsIiwiZ2xvYmFsU3RhZ2UiLCJOb2RlIiwic3RhcnQiLCJnZXRDb21wb25lbnQiLCJyZXNldCIsIm5vZGUiLCJQcm9ncmVzc0JhciIsInByb2dyZXNzIiwicGFyc2VJbnQiLCJjb25zb2xlIiwibG9nIiwidXBkYXRlIiwiZHQiLCJub3dTdGFnZSIsImV4Y2VlZFRpbWUiLCJzdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUMsR0FERTtBQUVSQyxJQUFBQSxJQUFJLEVBQUMsRUFGRztBQUdSQyxJQUFBQSxVQUFVLEVBQUMsSUFISDtBQUlSQyxJQUFBQSxTQUFTLEVBQUNQLEVBQUUsQ0FBQ1EsS0FKTDtBQUtSQyxJQUFBQSxXQUFXLEVBQUNULEVBQUUsQ0FBQ1U7QUFMUCxHQUhQO0FBWUw7QUFFQTtBQUVBQyxFQUFBQSxLQWhCSyxtQkFnQkk7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFLRixXQUFMLEdBQWlCLEtBQUtBLFdBQUwsQ0FBaUJHLFlBQWpCLENBQThCLGVBQTlCLENBQWpCO0FBQ0gsR0FyQkk7QUF1QkxDLEVBQUFBLEtBdkJLLGlCQXVCQ1IsSUF2QkQsRUF1Qk07QUFDUCxTQUFLUyxJQUFMLENBQVVGLFlBQVYsQ0FBdUJaLEVBQUUsQ0FBQ2UsV0FBMUIsRUFBdUNDLFFBQXZDLEdBQWdELENBQWhEO0FBQ0EsU0FBS1gsSUFBTCxHQUFVQSxJQUFWO0FBQ0EsU0FBS0QsS0FBTCxHQUFXYSxRQUFRLENBQUMsS0FBS0gsSUFBTCxDQUFVRixZQUFWLENBQXVCWixFQUFFLENBQUNlLFdBQTFCLEVBQXVDQyxRQUF2QyxHQUFnRCxLQUFLWCxJQUFyRCxHQUEwRCxFQUEzRCxDQUFSLEdBQXVFLEVBQWxGO0FBQ0FhLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVcsS0FBS2YsS0FBNUI7QUFDSCxHQTVCSTtBQThCTGdCLEVBQUFBLE1BOUJLLGtCQThCR0MsRUE5QkgsRUE4Qk87QUFDUixRQUFHLEtBQUtmLFVBQVIsRUFBbUI7QUFDZixXQUFLRixLQUFMLEdBQVdhLFFBQVEsQ0FBQyxLQUFLSCxJQUFMLENBQVVGLFlBQVYsQ0FBdUJaLEVBQUUsQ0FBQ2UsV0FBMUIsRUFBdUNDLFFBQXZDLEdBQWdELEtBQUtYLElBQXJELEdBQTBELEVBQTNELENBQVIsR0FBdUUsRUFBbEY7O0FBQ0EsVUFBRyxLQUFLRCxLQUFMLEdBQVcsQ0FBZCxFQUFnQjtBQUFDLGFBQUtBLEtBQUwsR0FBVyxDQUFYO0FBQWE7O0FBQzlCLFVBQUcsS0FBS0EsS0FBTCxJQUFZLENBQVosSUFBZSxLQUFLSyxXQUFMLENBQWlCYSxRQUFqQixJQUEyQixDQUE3QyxFQUErQztBQUFDLGFBQUtiLFdBQUwsQ0FBaUJjLFVBQWpCO0FBQThCLGFBQUtkLFdBQUwsQ0FBaUJhLFFBQWpCLEdBQTBCLENBQTFCO0FBQTZCOztBQUMzRyxXQUFLZixTQUFMLENBQWVpQixNQUFmLEdBQXNCLEtBQUtwQixLQUEzQjtBQUNBLFdBQUtVLElBQUwsQ0FBVUYsWUFBVixDQUF1QlosRUFBRSxDQUFDZSxXQUExQixFQUF1Q0MsUUFBdkMsSUFBa0RLLEVBQUUsR0FBQyxLQUFLaEIsSUFBMUQ7QUFDSDtBQUVKO0FBdkNJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzdGFnZToxMDAsXHJcbiAgICAgICAgdGltZToxMCxcclxuICAgICAgICBwcm9jZXNzaW5nOnRydWUsXHJcbiAgICAgICAgc2hvd0xhYmVsOmNjLkxhYmVsLFxyXG4gICAgICAgIGdsb2JhbFN0YWdlOmNjLk5vZGVcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICAvLyB0aGlzLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgLy8gICAgIHRoaXMucmVzZXQoMTApO1xyXG4gICAgICAgIC8vIH0uYmluZCh0aGlzKSwxMCk7XHJcbiAgICAgICAgdGhpcy5nbG9iYWxTdGFnZT10aGlzLmdsb2JhbFN0YWdlLmdldENvbXBvbmVudChcInJfZ2xvYmFsU3RhZ2VcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIHJlc2V0KHRpbWUpe1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuUHJvZ3Jlc3NCYXIpLnByb2dyZXNzPTE7XHJcbiAgICAgICAgdGhpcy50aW1lPXRpbWU7XHJcbiAgICAgICAgdGhpcy5zdGFnZT1wYXJzZUludCh0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKS5wcm9ncmVzcyp0aGlzLnRpbWUqMTApLzEwO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZnJvbSBiYXJcIit0aGlzLnN0YWdlKTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGlmKHRoaXMucHJvY2Vzc2luZyl7XHJcbiAgICAgICAgICAgIHRoaXMuc3RhZ2U9cGFyc2VJbnQodGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5Qcm9ncmVzc0JhcikucHJvZ3Jlc3MqdGhpcy50aW1lKjEwKS8xMDtcclxuICAgICAgICAgICAgaWYodGhpcy5zdGFnZTwwKXt0aGlzLnN0YWdlPTB9XHJcbiAgICAgICAgICAgIGlmKHRoaXMuc3RhZ2U9PTAmJnRoaXMuZ2xvYmFsU3RhZ2Uubm93U3RhZ2U9PTApe3RoaXMuZ2xvYmFsU3RhZ2UuZXhjZWVkVGltZSgpO3RoaXMuZ2xvYmFsU3RhZ2Uubm93U3RhZ2U9Mjt9XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd0xhYmVsLnN0cmluZz10aGlzLnN0YWdlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlByb2dyZXNzQmFyKS5wcm9ncmVzcy09KGR0L3RoaXMudGltZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==