
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/谣言破除/script/r_contentCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '07e55Wkb1hCCIKgguOHTSYZ', 'r_contentCtrl');
// 谣言破除/script/r_contentCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    content: cc.Label,
    trueButton: cc.Button,
    falseButton: cc.Button,
    ansStage: cc.Label,
    promotion: cc.Label,
    mContent: {
      "default": null,
      type: cc.JsonAsset
    },
    rumorContent: null,
    trueAnsFrame: cc.SpriteFrame,
    falseAnsFrame: cc.SpriteFrame,
    nowAns: 0,
    nowTag: 0,
    globalStage: cc.Node,
    count: 0,
    trueAudio: {
      "default": null,
      type: cc.AudioClip
    },
    falseAudio: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.rumorContent = this.mContent.json.content;
    console.log('this.rumorContent :>> ', this.rumorContent);
    this.globalStage = this.globalStage.getComponent("r_globalStage");
    this.nextContent();
  },
  nextContent: function nextContent() {
    this.count += 1;
    this.ansStage.node.active = false;
    this.promotion.node.active = false;
    this.trueButton.interactable = true;
    this.falseButton.interactable = true;
    this.nowTag = parseInt(Math.random() * this.rumorContent.length);
    this.content.string = "第" + this.count + "题 " + this.rumorContent[this.nowTag].message;
    this.nowAns = this.rumorContent[this.nowTag].ans;
    this.promotion.string = this.rumorContent[this.nowTag].promotion;
  },
  chooseAns: function chooseAns(event) {
    var temp = 0;
    this.ansStage.node.active = true;

    if (event.target.name == "yes") {
      temp = 1;
    }

    if (event.target.name == "no") {
      temp = 0;
    }

    if (temp == this.nowAns) {
      console.log("答对了");
      cc.audioEngine.playEffect(this.trueAudio, false);
      this.ansStage.string = "答对了√";
      this.ansStage.node.color = new cc.Color(0, 204, 0);
      this.globalStage.callNext();
      this.scheduleOnce(function () {
        this.nextContent();
      }.bind(this), 3);
    } else {
      console.log("答错了");
      cc.audioEngine.playEffect(this.falseAudio, false);
      this.ansStage.string = "答错了×";
      this.ansStage.node.color = new cc.Color(255, 0, 0);
      this.globalStage.failure();
      this.globalStage.callTimeShow();
    }

    this.promotion.node.active = true;
    this.trueButton.interactable = false;
    this.falseButton.interactable = false;
  },
  exceedTimeChange: function exceedTimeChange() {
    this.ansStage.node.active = true;
    console.log("时间耗尽了");
    cc.audioEngine.playEffect(this.falseAudio, false);
    this.ansStage.string = "时间耗尽了";
    this.ansStage.node.color = new cc.Color(255, 0, 0);
    this.promotion.node.active = true;
    this.trueButton.interactable = false;
    this.falseButton.interactable = false;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc6LCj6KiA56C06ZmkXFxzY3JpcHRcXHJfY29udGVudEN0cmwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjb250ZW50IiwiTGFiZWwiLCJ0cnVlQnV0dG9uIiwiQnV0dG9uIiwiZmFsc2VCdXR0b24iLCJhbnNTdGFnZSIsInByb21vdGlvbiIsIm1Db250ZW50IiwidHlwZSIsIkpzb25Bc3NldCIsInJ1bW9yQ29udGVudCIsInRydWVBbnNGcmFtZSIsIlNwcml0ZUZyYW1lIiwiZmFsc2VBbnNGcmFtZSIsIm5vd0FucyIsIm5vd1RhZyIsImdsb2JhbFN0YWdlIiwiTm9kZSIsImNvdW50IiwidHJ1ZUF1ZGlvIiwiQXVkaW9DbGlwIiwiZmFsc2VBdWRpbyIsInN0YXJ0IiwianNvbiIsImNvbnNvbGUiLCJsb2ciLCJnZXRDb21wb25lbnQiLCJuZXh0Q29udGVudCIsIm5vZGUiLCJhY3RpdmUiLCJpbnRlcmFjdGFibGUiLCJwYXJzZUludCIsIk1hdGgiLCJyYW5kb20iLCJsZW5ndGgiLCJzdHJpbmciLCJtZXNzYWdlIiwiYW5zIiwiY2hvb3NlQW5zIiwiZXZlbnQiLCJ0ZW1wIiwidGFyZ2V0IiwibmFtZSIsImF1ZGlvRW5naW5lIiwicGxheUVmZmVjdCIsImNvbG9yIiwiQ29sb3IiLCJjYWxsTmV4dCIsInNjaGVkdWxlT25jZSIsImJpbmQiLCJmYWlsdXJlIiwiY2FsbFRpbWVTaG93IiwiZXhjZWVkVGltZUNoYW5nZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLE9BQU8sRUFBQ0osRUFBRSxDQUFDSyxLQURIO0FBRVJDLElBQUFBLFVBQVUsRUFBQ04sRUFBRSxDQUFDTyxNQUZOO0FBR1JDLElBQUFBLFdBQVcsRUFBQ1IsRUFBRSxDQUFDTyxNQUhQO0FBSVJFLElBQUFBLFFBQVEsRUFBQ1QsRUFBRSxDQUFDSyxLQUpKO0FBS1JLLElBQUFBLFNBQVMsRUFBQ1YsRUFBRSxDQUFDSyxLQUxMO0FBTVJNLElBQUFBLFFBQVEsRUFBQztBQUNMLGlCQUFRLElBREg7QUFFTEMsTUFBQUEsSUFBSSxFQUFDWixFQUFFLENBQUNhO0FBRkgsS0FORDtBQVVSQyxJQUFBQSxZQUFZLEVBQUMsSUFWTDtBQVdSQyxJQUFBQSxZQUFZLEVBQUNmLEVBQUUsQ0FBQ2dCLFdBWFI7QUFZUkMsSUFBQUEsYUFBYSxFQUFDakIsRUFBRSxDQUFDZ0IsV0FaVDtBQWFSRSxJQUFBQSxNQUFNLEVBQUMsQ0FiQztBQWNSQyxJQUFBQSxNQUFNLEVBQUMsQ0FkQztBQWVSQyxJQUFBQSxXQUFXLEVBQUNwQixFQUFFLENBQUNxQixJQWZQO0FBZ0JSQyxJQUFBQSxLQUFLLEVBQUMsQ0FoQkU7QUFpQlJDLElBQUFBLFNBQVMsRUFBQztBQUNOLGlCQUFRLElBREY7QUFFTlgsTUFBQUEsSUFBSSxFQUFDWixFQUFFLENBQUN3QjtBQUZGLEtBakJGO0FBcUJSQyxJQUFBQSxVQUFVLEVBQUM7QUFDUCxpQkFBUSxJQUREO0FBRVBiLE1BQUFBLElBQUksRUFBQ1osRUFBRSxDQUFDd0I7QUFGRDtBQXJCSCxHQUhQO0FBOEJMO0FBRUE7QUFFQUUsRUFBQUEsS0FsQ0ssbUJBa0NJO0FBR0wsU0FBS1osWUFBTCxHQUFvQixLQUFLSCxRQUFMLENBQWNnQixJQUFkLENBQW1CdkIsT0FBdkM7QUFDQXdCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFaLEVBQXNDLEtBQUtmLFlBQTNDO0FBQ0EsU0FBS00sV0FBTCxHQUFpQixLQUFLQSxXQUFMLENBQWlCVSxZQUFqQixDQUE4QixlQUE5QixDQUFqQjtBQUNBLFNBQUtDLFdBQUw7QUFHSCxHQTNDSTtBQTZDTEEsRUFBQUEsV0E3Q0sseUJBNkNRO0FBQ1QsU0FBS1QsS0FBTCxJQUFZLENBQVo7QUFDQSxTQUFLYixRQUFMLENBQWN1QixJQUFkLENBQW1CQyxNQUFuQixHQUEwQixLQUExQjtBQUNBLFNBQUt2QixTQUFMLENBQWVzQixJQUFmLENBQW9CQyxNQUFwQixHQUEyQixLQUEzQjtBQUNBLFNBQUszQixVQUFMLENBQWdCNEIsWUFBaEIsR0FBNkIsSUFBN0I7QUFDQSxTQUFLMUIsV0FBTCxDQUFpQjBCLFlBQWpCLEdBQThCLElBQTlCO0FBQ0EsU0FBS2YsTUFBTCxHQUFZZ0IsUUFBUSxDQUFDQyxJQUFJLENBQUNDLE1BQUwsS0FBYyxLQUFLdkIsWUFBTCxDQUFrQndCLE1BQWpDLENBQXBCO0FBQ0EsU0FBS2xDLE9BQUwsQ0FBYW1DLE1BQWIsR0FBb0IsTUFBSSxLQUFLakIsS0FBVCxHQUFlLElBQWYsR0FBb0IsS0FBS1IsWUFBTCxDQUFrQixLQUFLSyxNQUF2QixFQUErQnFCLE9BQXZFO0FBQ0EsU0FBS3RCLE1BQUwsR0FBWSxLQUFLSixZQUFMLENBQWtCLEtBQUtLLE1BQXZCLEVBQStCc0IsR0FBM0M7QUFDQSxTQUFLL0IsU0FBTCxDQUFlNkIsTUFBZixHQUFzQixLQUFLekIsWUFBTCxDQUFrQixLQUFLSyxNQUF2QixFQUErQlQsU0FBckQ7QUFDSCxHQXZESTtBQXlETGdDLEVBQUFBLFNBekRLLHFCQXlES0MsS0F6REwsRUF5RFc7QUFDWixRQUFJQyxJQUFJLEdBQUMsQ0FBVDtBQUNBLFNBQUtuQyxRQUFMLENBQWN1QixJQUFkLENBQW1CQyxNQUFuQixHQUEwQixJQUExQjs7QUFDQSxRQUFHVSxLQUFLLENBQUNFLE1BQU4sQ0FBYUMsSUFBYixJQUFtQixLQUF0QixFQUE0QjtBQUFDRixNQUFBQSxJQUFJLEdBQUMsQ0FBTDtBQUFROztBQUNyQyxRQUFHRCxLQUFLLENBQUNFLE1BQU4sQ0FBYUMsSUFBYixJQUFtQixJQUF0QixFQUEyQjtBQUFDRixNQUFBQSxJQUFJLEdBQUMsQ0FBTDtBQUFROztBQUNwQyxRQUFHQSxJQUFJLElBQUUsS0FBSzFCLE1BQWQsRUFBcUI7QUFDakJVLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFDQTdCLE1BQUFBLEVBQUUsQ0FBQytDLFdBQUgsQ0FBZUMsVUFBZixDQUEwQixLQUFLekIsU0FBL0IsRUFBeUMsS0FBekM7QUFDQSxXQUFLZCxRQUFMLENBQWM4QixNQUFkLEdBQXFCLE1BQXJCO0FBQ0EsV0FBSzlCLFFBQUwsQ0FBY3VCLElBQWQsQ0FBbUJpQixLQUFuQixHQUF5QixJQUFJakQsRUFBRSxDQUFDa0QsS0FBUCxDQUFhLENBQWIsRUFBZ0IsR0FBaEIsRUFBcUIsQ0FBckIsQ0FBekI7QUFDQSxXQUFLOUIsV0FBTCxDQUFpQitCLFFBQWpCO0FBQ0EsV0FBS0MsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLGFBQUtyQixXQUFMO0FBQ0gsT0FGaUIsQ0FFaEJzQixJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYSxDQUZiO0FBR0gsS0FURCxNQVVJO0FBQ0F6QixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaO0FBQ0E3QixNQUFBQSxFQUFFLENBQUMrQyxXQUFILENBQWVDLFVBQWYsQ0FBMEIsS0FBS3ZCLFVBQS9CLEVBQTBDLEtBQTFDO0FBQ0EsV0FBS2hCLFFBQUwsQ0FBYzhCLE1BQWQsR0FBcUIsTUFBckI7QUFDQSxXQUFLOUIsUUFBTCxDQUFjdUIsSUFBZCxDQUFtQmlCLEtBQW5CLEdBQXlCLElBQUlqRCxFQUFFLENBQUNrRCxLQUFQLENBQWEsR0FBYixFQUFrQixDQUFsQixFQUFxQixDQUFyQixDQUF6QjtBQUNBLFdBQUs5QixXQUFMLENBQWlCa0MsT0FBakI7QUFDQSxXQUFLbEMsV0FBTCxDQUFpQm1DLFlBQWpCO0FBQ0g7O0FBQ0QsU0FBSzdDLFNBQUwsQ0FBZXNCLElBQWYsQ0FBb0JDLE1BQXBCLEdBQTJCLElBQTNCO0FBQ0EsU0FBSzNCLFVBQUwsQ0FBZ0I0QixZQUFoQixHQUE2QixLQUE3QjtBQUNBLFNBQUsxQixXQUFMLENBQWlCMEIsWUFBakIsR0FBOEIsS0FBOUI7QUFHSCxHQXJGSTtBQXVGTHNCLEVBQUFBLGdCQXZGSyw4QkF1RmE7QUFDZCxTQUFLL0MsUUFBTCxDQUFjdUIsSUFBZCxDQUFtQkMsTUFBbkIsR0FBMEIsSUFBMUI7QUFDQUwsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBN0IsSUFBQUEsRUFBRSxDQUFDK0MsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUt2QixVQUEvQixFQUEwQyxLQUExQztBQUNBLFNBQUtoQixRQUFMLENBQWM4QixNQUFkLEdBQXFCLE9BQXJCO0FBQ0EsU0FBSzlCLFFBQUwsQ0FBY3VCLElBQWQsQ0FBbUJpQixLQUFuQixHQUF5QixJQUFJakQsRUFBRSxDQUFDa0QsS0FBUCxDQUFhLEdBQWIsRUFBa0IsQ0FBbEIsRUFBcUIsQ0FBckIsQ0FBekI7QUFDQSxTQUFLeEMsU0FBTCxDQUFlc0IsSUFBZixDQUFvQkMsTUFBcEIsR0FBMkIsSUFBM0I7QUFDQSxTQUFLM0IsVUFBTCxDQUFnQjRCLFlBQWhCLEdBQTZCLEtBQTdCO0FBQ0EsU0FBSzFCLFdBQUwsQ0FBaUIwQixZQUFqQixHQUE4QixLQUE5QjtBQUNILEdBaEdJLENBaUdMOztBQWpHSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY29udGVudDpjYy5MYWJlbCxcclxuICAgICAgICB0cnVlQnV0dG9uOmNjLkJ1dHRvbixcclxuICAgICAgICBmYWxzZUJ1dHRvbjpjYy5CdXR0b24sXHJcbiAgICAgICAgYW5zU3RhZ2U6Y2MuTGFiZWwsXHJcbiAgICAgICAgcHJvbW90aW9uOmNjLkxhYmVsLFxyXG4gICAgICAgIG1Db250ZW50OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkpzb25Bc3NldFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcnVtb3JDb250ZW50Om51bGwsXHJcbiAgICAgICAgdHJ1ZUFuc0ZyYW1lOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGZhbHNlQW5zRnJhbWU6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgbm93QW5zOjAsXHJcbiAgICAgICAgbm93VGFnOjAsXHJcbiAgICAgICAgZ2xvYmFsU3RhZ2U6Y2MuTm9kZSxcclxuICAgICAgICBjb3VudDowLFxyXG4gICAgICAgIHRydWVBdWRpbzp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5BdWRpb0NsaXBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZhbHNlQXVkaW86e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMucnVtb3JDb250ZW50ID0gdGhpcy5tQ29udGVudC5qc29uLmNvbnRlbnQ7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RoaXMucnVtb3JDb250ZW50IDo+PiAnLCB0aGlzLnJ1bW9yQ29udGVudCk7XHJcbiAgICAgICAgdGhpcy5nbG9iYWxTdGFnZT10aGlzLmdsb2JhbFN0YWdlLmdldENvbXBvbmVudChcInJfZ2xvYmFsU3RhZ2VcIik7XHJcbiAgICAgICAgdGhpcy5uZXh0Q29udGVudCgpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICBuZXh0Q29udGVudCgpe1xyXG4gICAgICAgIHRoaXMuY291bnQrPTE7XHJcbiAgICAgICAgdGhpcy5hbnNTdGFnZS5ub2RlLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICB0aGlzLnByb21vdGlvbi5ub2RlLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICB0aGlzLnRydWVCdXR0b24uaW50ZXJhY3RhYmxlPXRydWU7XHJcbiAgICAgICAgdGhpcy5mYWxzZUJ1dHRvbi5pbnRlcmFjdGFibGU9dHJ1ZTtcclxuICAgICAgICB0aGlzLm5vd1RhZz1wYXJzZUludChNYXRoLnJhbmRvbSgpKnRoaXMucnVtb3JDb250ZW50Lmxlbmd0aCk7XHJcbiAgICAgICAgdGhpcy5jb250ZW50LnN0cmluZz1cIuesrFwiK3RoaXMuY291bnQrXCLpopggXCIrdGhpcy5ydW1vckNvbnRlbnRbdGhpcy5ub3dUYWddLm1lc3NhZ2U7XHJcbiAgICAgICAgdGhpcy5ub3dBbnM9dGhpcy5ydW1vckNvbnRlbnRbdGhpcy5ub3dUYWddLmFucztcclxuICAgICAgICB0aGlzLnByb21vdGlvbi5zdHJpbmc9dGhpcy5ydW1vckNvbnRlbnRbdGhpcy5ub3dUYWddLnByb21vdGlvbjtcclxuICAgIH0sXHJcblxyXG4gICAgY2hvb3NlQW5zKGV2ZW50KXtcclxuICAgICAgICB2YXIgdGVtcD0wO1xyXG4gICAgICAgIHRoaXMuYW5zU3RhZ2Uubm9kZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICBpZihldmVudC50YXJnZXQubmFtZT09XCJ5ZXNcIil7dGVtcD0xO31cclxuICAgICAgICBpZihldmVudC50YXJnZXQubmFtZT09XCJub1wiKXt0ZW1wPTA7fVxyXG4gICAgICAgIGlmKHRlbXA9PXRoaXMubm93QW5zKXtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLnrZTlr7nkuoZcIik7XHJcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy50cnVlQXVkaW8sZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLmFuc1N0YWdlLnN0cmluZz1cIuetlOWvueS6huKImlwiO1xyXG4gICAgICAgICAgICB0aGlzLmFuc1N0YWdlLm5vZGUuY29sb3I9bmV3IGNjLkNvbG9yKDAsIDIwNCwgMCk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2xvYmFsU3RhZ2UuY2FsbE5leHQoKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubmV4dENvbnRlbnQoKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDMpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuetlOmUmeS6hlwiKTtcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmZhbHNlQXVkaW8sZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLmFuc1N0YWdlLnN0cmluZz1cIuetlOmUmeS6hsOXXCI7XHJcbiAgICAgICAgICAgIHRoaXMuYW5zU3RhZ2Uubm9kZS5jb2xvcj1uZXcgY2MuQ29sb3IoMjU1LCAwLCAwKTtcclxuICAgICAgICAgICAgdGhpcy5nbG9iYWxTdGFnZS5mYWlsdXJlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2xvYmFsU3RhZ2UuY2FsbFRpbWVTaG93KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucHJvbW90aW9uLm5vZGUuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgdGhpcy50cnVlQnV0dG9uLmludGVyYWN0YWJsZT1mYWxzZTtcclxuICAgICAgICB0aGlzLmZhbHNlQnV0dG9uLmludGVyYWN0YWJsZT1mYWxzZTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgZXhjZWVkVGltZUNoYW5nZSgpe1xyXG4gICAgICAgIHRoaXMuYW5zU3RhZ2Uubm9kZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuaXtumXtOiAl+WwveS6hlwiKTtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuZmFsc2VBdWRpbyxmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5hbnNTdGFnZS5zdHJpbmc9XCLml7bpl7TogJflsL3kuoZcIjtcclxuICAgICAgICB0aGlzLmFuc1N0YWdlLm5vZGUuY29sb3I9bmV3IGNjLkNvbG9yKDI1NSwgMCwgMCk7XHJcbiAgICAgICAgdGhpcy5wcm9tb3Rpb24ubm9kZS5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICB0aGlzLnRydWVCdXR0b24uaW50ZXJhY3RhYmxlPWZhbHNlO1xyXG4gICAgICAgIHRoaXMuZmFsc2VCdXR0b24uaW50ZXJhY3RhYmxlPWZhbHNlO1xyXG4gICAgfVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=