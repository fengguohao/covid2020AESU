
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/antiviral.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41ea3eLOulKzJHljnmMH3o3', 'antiviral');
// 人体免疫/scripts/antiviral.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    clip1: {
      "default": null,
      type: cc.AudioClip
    },
    clip2: {
      "default": null,
      type: cc.AudioClip
    },
    clip3: {
      "default": null,
      type: cc.AudioClip
    },
    jiangshi: cc.Node,
    caodi: cc.Node,
    sunnum: cc.Node,
    num1: 0,
    num2: 0,
    isSleeping1: false,
    isSleeping2: false,
    cooling1: 0,
    cooling2: 0
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  start: function start() {},
  kill: function kill() {
    if (this.num1 < 3 && this.isSleeping1 === false) {
      for (var j = 0; j < this.jiangshi.getComponent('jingong').num; j++) {
        this.jiangshi.getComponent('jingong').jiangshi[j].active = false;
      }

      for (var j = 0; j < this.jiangshi.getComponent('piao').num; j++) {
        this.jiangshi.getComponent('piao').infectedCell[j].active = false;
      }

      for (var j = 0; j < this.jiangshi.getComponent('zou').num; j++) {
        this.jiangshi.getComponent('zou').normalCell[j].active = false;
      }

      this.num1 += 1;
      cc.audioEngine.play(this.clip1, false, 1);
      this.cooling1 = 60;
      this.isSleeping1 = true;
      var start = cc.callFunc(function () {
        this.cooling1--;
      }.bind(this));
      var remain = cc.fadeTo(1, 255);
      var stop = cc.callFunc(function () {
        if (this.cooling1 === 0) {
          this.isSleeping1 = false;
          this.node.color = new cc.Color(255, 255, 255);
          this.node.stopAllActions();
        }
      }.bind(this));
      this.node.getChildByName('antiviral').getChildByName('Background').color = new cc.Color(127, 127, 127);
      this.node.getChildByName('antiviral').getChildByName('Background').runAction(cc.sequence([remain, start, stop])).repeatForever();
    } else {
      cc.audioEngine.play(this.clip3, false, 1);
    }
  },
  use: function use() {
    if (this.num2 < 3 && this.isSleeping2 === false) {
      if (this.sunnum.getComponent('sun').total >= 200) {
        this.sunnum.getComponent('sun').total -= 200;
      } else {
        this.sunnum.getComponent('sun').total = 0;
      }

      this.num2 += 1;
      cc.audioEngine.play(this.clip2, false, 1);
      this.cooling2 = 45;
      this.isSleeping2 = true;
      var start = cc.callFunc(function () {
        this.cooling2--;
      }.bind(this));
      var remain = cc.fadeTo(1, 255);
      var stop = cc.callFunc(function () {
        if (this.cooling2 === 0) {
          this.isSleeping2 = false;
          this.node.color = new cc.Color(255, 255, 255);
          this.node.stopAllActions();
        }
      }.bind(this));
      this.node.getChildByName('antiCK').getChildByName('Background').color = new cc.Color(127, 127, 127);
      this.node.getChildByName('antiCK').getChildByName('Background').runAction(cc.sequence([remain, start, stop])).repeatForever();
    } else {
      cc.audioEngine.play(this.clip3, false, 1);
    }
  } //update (dt) {
  //},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxhbnRpdmlyYWwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjbGlwMSIsInR5cGUiLCJBdWRpb0NsaXAiLCJjbGlwMiIsImNsaXAzIiwiamlhbmdzaGkiLCJOb2RlIiwiY2FvZGkiLCJzdW5udW0iLCJudW0xIiwibnVtMiIsImlzU2xlZXBpbmcxIiwiaXNTbGVlcGluZzIiLCJjb29saW5nMSIsImNvb2xpbmcyIiwib25Mb2FkIiwic3RhcnQiLCJraWxsIiwiaiIsImdldENvbXBvbmVudCIsIm51bSIsImFjdGl2ZSIsImluZmVjdGVkQ2VsbCIsIm5vcm1hbENlbGwiLCJhdWRpb0VuZ2luZSIsInBsYXkiLCJjYWxsRnVuYyIsImJpbmQiLCJyZW1haW4iLCJmYWRlVG8iLCJzdG9wIiwibm9kZSIsImNvbG9yIiwiQ29sb3IiLCJzdG9wQWxsQWN0aW9ucyIsImdldENoaWxkQnlOYW1lIiwicnVuQWN0aW9uIiwic2VxdWVuY2UiLCJyZXBlYXRGb3JldmVyIiwidXNlIiwidG90YWwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUU7QUFDSCxpQkFBUyxJQUROO0FBRUhDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZOLEtBREM7QUFLUkMsSUFBQUEsS0FBSyxFQUFDO0FBQ0YsaUJBQVMsSUFEUDtBQUVGRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGUCxLQUxFO0FBU1JFLElBQUFBLEtBQUssRUFBQztBQUNGLGlCQUFTLElBRFA7QUFFRkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlAsS0FURTtBQWFSRyxJQUFBQSxRQUFRLEVBQUNULEVBQUUsQ0FBQ1UsSUFiSjtBQWNSQyxJQUFBQSxLQUFLLEVBQUNYLEVBQUUsQ0FBQ1UsSUFkRDtBQWVSRSxJQUFBQSxNQUFNLEVBQUNaLEVBQUUsQ0FBQ1UsSUFmRjtBQWdCUkcsSUFBQUEsSUFBSSxFQUFDLENBaEJHO0FBaUJSQyxJQUFBQSxJQUFJLEVBQUMsQ0FqQkc7QUFrQlJDLElBQUFBLFdBQVcsRUFBRSxLQWxCTDtBQW1CUkMsSUFBQUEsV0FBVyxFQUFFLEtBbkJMO0FBb0JSQyxJQUFBQSxRQUFRLEVBQUUsQ0FwQkY7QUFxQlJDLElBQUFBLFFBQVEsRUFBRTtBQXJCRixHQUhQO0FBMkJMO0FBRUFDLEVBQUFBLE1BN0JLLG9CQTZCSyxDQUVULENBL0JJO0FBaUNMQyxFQUFBQSxLQWpDSyxtQkFpQ0ksQ0FFUixDQW5DSTtBQXFDTEMsRUFBQUEsSUFBSSxFQUFDLGdCQUFVO0FBQ1gsUUFBRyxLQUFLUixJQUFMLEdBQVUsQ0FBVixJQUFlLEtBQUtFLFdBQUwsS0FBcUIsS0FBdkMsRUFBNkM7QUFDekMsV0FBSSxJQUFJTyxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsS0FBS2IsUUFBTCxDQUFjYyxZQUFkLENBQTJCLFNBQTNCLEVBQXNDQyxHQUF6RCxFQUE4REYsQ0FBQyxFQUEvRCxFQUFrRTtBQUM5RCxhQUFLYixRQUFMLENBQWNjLFlBQWQsQ0FBMkIsU0FBM0IsRUFBc0NkLFFBQXRDLENBQStDYSxDQUEvQyxFQUFrREcsTUFBbEQsR0FBMkQsS0FBM0Q7QUFDSDs7QUFDRCxXQUFJLElBQUlILENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxLQUFLYixRQUFMLENBQWNjLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNDLEdBQXRELEVBQTJERixDQUFDLEVBQTVELEVBQStEO0FBQzNELGFBQUtiLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ0csWUFBbkMsQ0FBZ0RKLENBQWhELEVBQW1ERyxNQUFuRCxHQUE0RCxLQUE1RDtBQUNIOztBQUNELFdBQUksSUFBSUgsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtiLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixLQUEzQixFQUFrQ0MsR0FBckQsRUFBMERGLENBQUMsRUFBM0QsRUFBOEQ7QUFDMUQsYUFBS2IsUUFBTCxDQUFjYyxZQUFkLENBQTJCLEtBQTNCLEVBQWtDSSxVQUFsQyxDQUE2Q0wsQ0FBN0MsRUFBZ0RHLE1BQWhELEdBQXlELEtBQXpEO0FBQ0g7O0FBQ0QsV0FBS1osSUFBTCxJQUFXLENBQVg7QUFDQWIsTUFBQUEsRUFBRSxDQUFDNEIsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUt6QixLQUF6QixFQUFnQyxLQUFoQyxFQUF1QyxDQUF2QztBQUVBLFdBQUthLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQSxXQUFLRixXQUFMLEdBQW1CLElBQW5CO0FBQ0EsVUFBSUssS0FBSyxHQUFHcEIsRUFBRSxDQUFDOEIsUUFBSCxDQUFZLFlBQVc7QUFDL0IsYUFBS2IsUUFBTDtBQUNILE9BRnVCLENBRXRCYyxJQUZzQixDQUVqQixJQUZpQixDQUFaLENBQVo7QUFHQSxVQUFJQyxNQUFNLEdBQUdoQyxFQUFFLENBQUNpQyxNQUFILENBQVUsQ0FBVixFQUFhLEdBQWIsQ0FBYjtBQUNBLFVBQUlDLElBQUksR0FBR2xDLEVBQUUsQ0FBQzhCLFFBQUgsQ0FBWSxZQUFXO0FBQzlCLFlBQUcsS0FBS2IsUUFBTCxLQUFrQixDQUFyQixFQUF3QjtBQUNwQixlQUFLRixXQUFMLEdBQW1CLEtBQW5CO0FBQ0EsZUFBS29CLElBQUwsQ0FBVUMsS0FBVixHQUFrQixJQUFJcEMsRUFBRSxDQUFDcUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBbEI7QUFDQSxlQUFLRixJQUFMLENBQVVHLGNBQVY7QUFDSDtBQUNKLE9BTnNCLENBTXJCUCxJQU5xQixDQU1oQixJQU5nQixDQUFaLENBQVg7QUFPQSxXQUFLSSxJQUFMLENBQVVJLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NBLGNBQXRDLENBQXFELFlBQXJELEVBQW1FSCxLQUFuRSxHQUEyRSxJQUFJcEMsRUFBRSxDQUFDcUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBM0U7QUFDQSxXQUFLRixJQUFMLENBQVVJLGNBQVYsQ0FBeUIsV0FBekIsRUFBc0NBLGNBQXRDLENBQXFELFlBQXJELEVBQW1FQyxTQUFuRSxDQUE2RXhDLEVBQUUsQ0FBQ3lDLFFBQUgsQ0FBWSxDQUFDVCxNQUFELEVBQVNaLEtBQVQsRUFBZ0JjLElBQWhCLENBQVosQ0FBN0UsRUFBaUhRLGFBQWpIO0FBQ0gsS0E1QkQsTUE2Qkk7QUFDQTFDLE1BQUFBLEVBQUUsQ0FBQzRCLFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckIsS0FBekIsRUFBZ0MsS0FBaEMsRUFBdUMsQ0FBdkM7QUFDSDtBQUNKLEdBdEVJO0FBd0VMbUMsRUFBQUEsR0FBRyxFQUFDLGVBQVU7QUFDVixRQUFHLEtBQUs3QixJQUFMLEdBQVUsQ0FBVixJQUFlLEtBQUtFLFdBQUwsS0FBcUIsS0FBdkMsRUFBNkM7QUFDekMsVUFBRyxLQUFLSixNQUFMLENBQVlXLFlBQVosQ0FBeUIsS0FBekIsRUFBZ0NxQixLQUFoQyxJQUF1QyxHQUExQyxFQUE4QztBQUMxQyxhQUFLaEMsTUFBTCxDQUFZVyxZQUFaLENBQXlCLEtBQXpCLEVBQWdDcUIsS0FBaEMsSUFBdUMsR0FBdkM7QUFDSCxPQUZELE1BR0k7QUFDQSxhQUFLaEMsTUFBTCxDQUFZVyxZQUFaLENBQXlCLEtBQXpCLEVBQWdDcUIsS0FBaEMsR0FBc0MsQ0FBdEM7QUFDSDs7QUFDRCxXQUFLOUIsSUFBTCxJQUFXLENBQVg7QUFDQWQsTUFBQUEsRUFBRSxDQUFDNEIsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUt0QixLQUF6QixFQUFnQyxLQUFoQyxFQUF1QyxDQUF2QztBQUVBLFdBQUtXLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQSxXQUFLRixXQUFMLEdBQW1CLElBQW5CO0FBQ0EsVUFBSUksS0FBSyxHQUFHcEIsRUFBRSxDQUFDOEIsUUFBSCxDQUFZLFlBQVc7QUFDL0IsYUFBS1osUUFBTDtBQUNILE9BRnVCLENBRXRCYSxJQUZzQixDQUVqQixJQUZpQixDQUFaLENBQVo7QUFHQSxVQUFJQyxNQUFNLEdBQUdoQyxFQUFFLENBQUNpQyxNQUFILENBQVUsQ0FBVixFQUFhLEdBQWIsQ0FBYjtBQUNBLFVBQUlDLElBQUksR0FBR2xDLEVBQUUsQ0FBQzhCLFFBQUgsQ0FBWSxZQUFXO0FBQzlCLFlBQUcsS0FBS1osUUFBTCxLQUFrQixDQUFyQixFQUF3QjtBQUNwQixlQUFLRixXQUFMLEdBQW1CLEtBQW5CO0FBQ0EsZUFBS21CLElBQUwsQ0FBVUMsS0FBVixHQUFrQixJQUFJcEMsRUFBRSxDQUFDcUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBbEI7QUFDQSxlQUFLRixJQUFMLENBQVVHLGNBQVY7QUFDSDtBQUNKLE9BTnNCLENBTXJCUCxJQU5xQixDQU1oQixJQU5nQixDQUFaLENBQVg7QUFPQSxXQUFLSSxJQUFMLENBQVVJLGNBQVYsQ0FBeUIsUUFBekIsRUFBbUNBLGNBQW5DLENBQWtELFlBQWxELEVBQWdFSCxLQUFoRSxHQUF3RSxJQUFJcEMsRUFBRSxDQUFDcUMsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBeEU7QUFDQSxXQUFLRixJQUFMLENBQVVJLGNBQVYsQ0FBeUIsUUFBekIsRUFBbUNBLGNBQW5DLENBQWtELFlBQWxELEVBQWdFQyxTQUFoRSxDQUEwRXhDLEVBQUUsQ0FBQ3lDLFFBQUgsQ0FBWSxDQUFDVCxNQUFELEVBQVNaLEtBQVQsRUFBZ0JjLElBQWhCLENBQVosQ0FBMUUsRUFBOEdRLGFBQTlHO0FBQ0gsS0F6QkQsTUEwQkk7QUFDQTFDLE1BQUFBLEVBQUUsQ0FBQzRCLFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLckIsS0FBekIsRUFBZ0MsS0FBaEMsRUFBdUMsQ0FBdkM7QUFDSDtBQUNKLEdBdEdJLENBd0dMO0FBQ0E7O0FBekdLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBjbGlwMToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjbGlwMjp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNsaXAzOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuQXVkaW9DbGlwLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgamlhbmdzaGk6Y2MuTm9kZSxcclxuICAgICAgICBjYW9kaTpjYy5Ob2RlLFxyXG4gICAgICAgIHN1bm51bTpjYy5Ob2RlLFxyXG4gICAgICAgIG51bTE6MCxcclxuICAgICAgICBudW0yOjAsXHJcbiAgICAgICAgaXNTbGVlcGluZzE6IGZhbHNlLFxyXG4gICAgICAgIGlzU2xlZXBpbmcyOiBmYWxzZSxcclxuICAgICAgICBjb29saW5nMTogMCxcclxuICAgICAgICBjb29saW5nMjogMCxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGtpbGw6ZnVuY3Rpb24oKXtcclxuICAgICAgICBpZih0aGlzLm51bTE8MyAmJiB0aGlzLmlzU2xlZXBpbmcxID09PSBmYWxzZSl7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaiA9IDA7IGogPCB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnamluZ29uZycpLm51bTsgaisrKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdqaW5nb25nJykuamlhbmdzaGlbal0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yKHZhciBqID0gMDsgaiA8IHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtOyBqKyspe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yKHZhciBqID0gMDsgaiA8IHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCd6b3UnKS5udW07IGorKyl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnem91Jykubm9ybWFsQ2VsbFtqXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm51bTErPTE7XHJcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5jbGlwMSwgZmFsc2UsIDEpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5jb29saW5nMSA9IDYwO1xyXG4gICAgICAgICAgICB0aGlzLmlzU2xlZXBpbmcxID0gdHJ1ZTtcclxuICAgICAgICAgICAgdmFyIHN0YXJ0ID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvb2xpbmcxLS07XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSlcclxuICAgICAgICAgICAgdmFyIHJlbWFpbiA9IGNjLmZhZGVUbygxLCAyNTUpO1xyXG4gICAgICAgICAgICB2YXIgc3RvcCA9IGNjLmNhbGxGdW5jKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5jb29saW5nMSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNTbGVlcGluZzEgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuY29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnYW50aXZpcmFsJykuZ2V0Q2hpbGRCeU5hbWUoJ0JhY2tncm91bmQnKS5jb2xvciA9IG5ldyBjYy5Db2xvcigxMjcsIDEyNywgMTI3KTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdhbnRpdmlyYWwnKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShbcmVtYWluLCBzdGFydCwgc3RvcF0pKS5yZXBlYXRGb3JldmVyKCk7ICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5jbGlwMywgZmFsc2UsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBcclxuICAgIHVzZTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGlmKHRoaXMubnVtMjwzICYmIHRoaXMuaXNTbGVlcGluZzIgPT09IGZhbHNlKXtcclxuICAgICAgICAgICAgaWYodGhpcy5zdW5udW0uZ2V0Q29tcG9uZW50KCdzdW4nKS50b3RhbD49MjAwKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3VubnVtLmdldENvbXBvbmVudCgnc3VuJykudG90YWwtPTIwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zdW5udW0uZ2V0Q29tcG9uZW50KCdzdW4nKS50b3RhbD0wO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMubnVtMis9MTtcclxuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmNsaXAyLCBmYWxzZSwgMSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLmNvb2xpbmcyID0gNDU7XHJcbiAgICAgICAgICAgIHRoaXMuaXNTbGVlcGluZzIgPSB0cnVlO1xyXG4gICAgICAgICAgICB2YXIgc3RhcnQgPSBjYy5jYWxsRnVuYyhmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29vbGluZzItLTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKVxyXG4gICAgICAgICAgICB2YXIgcmVtYWluID0gY2MuZmFkZVRvKDEsIDI1NSk7XHJcbiAgICAgICAgICAgIHZhciBzdG9wID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmNvb2xpbmcyID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc1NsZWVwaW5nMiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5jb2xvciA9IG5ldyBjYy5Db2xvcigyNTUsIDI1NSwgMjU1KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdhbnRpQ0snKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmNvbG9yID0gbmV3IGNjLkNvbG9yKDEyNywgMTI3LCAxMjcpO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2FudGlDSycpLmdldENoaWxkQnlOYW1lKCdCYWNrZ3JvdW5kJykucnVuQWN0aW9uKGNjLnNlcXVlbmNlKFtyZW1haW4sIHN0YXJ0LCBzdG9wXSkpLnJlcGVhdEZvcmV2ZXIoKTsgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5jbGlwMywgZmFsc2UsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy91cGRhdGUgKGR0KSB7XHJcbiAgICAvL30sXHJcbn0pO1xyXG4iXX0=