
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/biaoji.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'be2558z9q9KaYDhQKmj17ZY', 'biaoji');
// 人体免疫/scripts/biaoji.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    caodi: cc.Node,
    hasFlag: [],
    flagRow: [],
    flagCol: []
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    var rect = this.caodi.getComponent('juxing').rect;

    for (var i = 0; i < 5; i++) {
      for (var j = 0; j < 9; j++) {
        for (var k = 0; k < this.node.getComponent('bozhong').num; k++) {
          var worldSpace = this.node.getComponent('bozhong').sunFlower[k].convertToWorldSpaceAR(cc.v2(0, 0));

          if (rect[i][j].contains(worldSpace)) {
            this.hasFlag[k] = true;
            this.flagRow[k] = i;
            this.flagCol[k] = j;
          }
        }
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxiaWFvamkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjYW9kaSIsIk5vZGUiLCJoYXNGbGFnIiwiZmxhZ1JvdyIsImZsYWdDb2wiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwicmVjdCIsImdldENvbXBvbmVudCIsImkiLCJqIiwiayIsIm5vZGUiLCJudW0iLCJ3b3JsZFNwYWNlIiwic3VuRmxvd2VyIiwiY29udmVydFRvV29ybGRTcGFjZUFSIiwidjIiLCJjb250YWlucyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBRUosRUFBRSxDQUFDSyxJQURGO0FBRVJDLElBQUFBLE9BQU8sRUFBRSxFQUZEO0FBR1JDLElBQUFBLE9BQU8sRUFBRSxFQUhEO0FBSVJDLElBQUFBLE9BQU8sRUFBRTtBQUpELEdBSFA7QUFVTDtBQUVBO0FBRUFDLEVBQUFBLEtBZEssbUJBY0ksQ0FFUixDQWhCSTtBQWtCTEMsRUFBQUEsTUFsQkssa0JBa0JHQyxFQWxCSCxFQWtCTztBQUNSLFFBQUlDLElBQUksR0FBRyxLQUFLUixLQUFMLENBQVdTLFlBQVgsQ0FBd0IsUUFBeEIsRUFBa0NELElBQTdDOztBQUNBLFNBQUksSUFBSUUsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLENBQW5CLEVBQXNCQSxDQUFDLEVBQXZCLEVBQTJCO0FBQ3ZCLFdBQUksSUFBSUMsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLENBQW5CLEVBQXNCQSxDQUFDLEVBQXZCLEVBQTJCO0FBQ3ZCLGFBQUksSUFBSUMsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtDLElBQUwsQ0FBVUosWUFBVixDQUF1QixTQUF2QixFQUFrQ0ssR0FBckQsRUFBMERGLENBQUMsRUFBM0QsRUFBK0Q7QUFDM0QsY0FBSUcsVUFBVSxHQUFHLEtBQUtGLElBQUwsQ0FBVUosWUFBVixDQUF1QixTQUF2QixFQUFrQ08sU0FBbEMsQ0FBNENKLENBQTVDLEVBQStDSyxxQkFBL0MsQ0FBcUVyQixFQUFFLENBQUNzQixFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBckUsQ0FBakI7O0FBQ0EsY0FBR1YsSUFBSSxDQUFDRSxDQUFELENBQUosQ0FBUUMsQ0FBUixFQUFXUSxRQUFYLENBQW9CSixVQUFwQixDQUFILEVBQW9DO0FBQ2hDLGlCQUFLYixPQUFMLENBQWFVLENBQWIsSUFBa0IsSUFBbEI7QUFDQSxpQkFBS1QsT0FBTCxDQUFhUyxDQUFiLElBQWtCRixDQUFsQjtBQUNBLGlCQUFLTixPQUFMLENBQWFRLENBQWIsSUFBa0JELENBQWxCO0FBQ0g7QUFDSjtBQUVKO0FBQ0o7QUFDSjtBQWpDSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgY2FvZGk6IGNjLk5vZGUsXHJcbiAgICAgICAgaGFzRmxhZzogW10sXHJcbiAgICAgICAgZmxhZ1JvdzogW10sXHJcbiAgICAgICAgZmxhZ0NvbDogW10sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdmFyIHJlY3QgPSB0aGlzLmNhb2RpLmdldENvbXBvbmVudCgnanV4aW5nJykucmVjdDtcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgNTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaiA9IDA7IGogPCA5OyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGZvcih2YXIgayA9IDA7IGsgPCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykubnVtOyBrKyspIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgd29ybGRTcGFjZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJba10uY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuICAgICAgICAgICAgICAgICAgICBpZihyZWN0W2ldW2pdLmNvbnRhaW5zKHdvcmxkU3BhY2UpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaGFzRmxhZ1trXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmxhZ1Jvd1trXSA9IGk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmxhZ0NvbFtrXSA9IGo7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59KTtcclxuIl19