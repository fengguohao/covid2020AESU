
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/showDeadNormalCell.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e8bd6VNOZRLqKCNCEIk0g5S', 'showDeadNormalCell');
// 人体免疫/scripts/showDeadNormalCell.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    jiangshi: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    var str = '正常细胞总数：';

    if (this.node.parent.parent.parent.parent.name === 'Level01') {
      str += '10';
    } else if (this.node.parent.parent.parent.parent.name === 'Level02') {
      str += '22';
    } else if (this.node.parent.parent.parent.parent.name === 'Level03') {
      str += '36';
    }

    str += '\n';
    str += '已经死亡数量：';
    var deadNum = 0;

    for (var i = 0; i < this.jiangshi.getComponent('zou').num; i++) {
      if (this.jiangshi.getComponent('zou').normalCell[i].active === false) {
        deadNum++;
      }
    }

    str += deadNum.toString();
    this.node.getComponent(cc.Label).string = str;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxzaG93RGVhZE5vcm1hbENlbGwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJqaWFuZ3NoaSIsInR5cGUiLCJOb2RlIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsInN0ciIsIm5vZGUiLCJwYXJlbnQiLCJuYW1lIiwiZGVhZE51bSIsImkiLCJnZXRDb21wb25lbnQiLCJudW0iLCJub3JtYWxDZWxsIiwiYWN0aXZlIiwidG9TdHJpbmciLCJMYWJlbCIsInN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFFBQVEsRUFBRTtBQUNOLGlCQUFTLElBREg7QUFFTkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkg7QUFERixHQUhQO0FBVUw7QUFFQTtBQUVBQyxFQUFBQSxLQWRLLG1CQWNJLENBRVIsQ0FoQkk7QUFrQkxDLEVBQUFBLE1BbEJLLGtCQWtCR0MsRUFsQkgsRUFrQk87QUFDUixRQUFJQyxHQUFHLEdBQUcsU0FBVjs7QUFDQSxRQUFHLEtBQUtDLElBQUwsQ0FBVUMsTUFBVixDQUFpQkEsTUFBakIsQ0FBd0JBLE1BQXhCLENBQStCQSxNQUEvQixDQUFzQ0MsSUFBdEMsS0FBK0MsU0FBbEQsRUFBNkQ7QUFDekRILE1BQUFBLEdBQUcsSUFBSSxJQUFQO0FBQ0gsS0FGRCxNQUVPLElBQUcsS0FBS0MsSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkEsTUFBeEIsQ0FBK0JBLE1BQS9CLENBQXNDQyxJQUF0QyxLQUErQyxTQUFsRCxFQUE2RDtBQUNoRUgsTUFBQUEsR0FBRyxJQUFJLElBQVA7QUFDSCxLQUZNLE1BRUEsSUFBRyxLQUFLQyxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkEsTUFBL0IsQ0FBc0NDLElBQXRDLEtBQStDLFNBQWxELEVBQTZEO0FBQ2hFSCxNQUFBQSxHQUFHLElBQUksSUFBUDtBQUNIOztBQUNEQSxJQUFBQSxHQUFHLElBQUksSUFBUDtBQUNBQSxJQUFBQSxHQUFHLElBQUksU0FBUDtBQUNBLFFBQUlJLE9BQU8sR0FBRyxDQUFkOztBQUNBLFNBQUksSUFBSUMsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtYLFFBQUwsQ0FBY1ksWUFBZCxDQUEyQixLQUEzQixFQUFrQ0MsR0FBckQsRUFBMERGLENBQUMsRUFBM0QsRUFBK0Q7QUFDM0QsVUFBRyxLQUFLWCxRQUFMLENBQWNZLFlBQWQsQ0FBMkIsS0FBM0IsRUFBa0NFLFVBQWxDLENBQTZDSCxDQUE3QyxFQUFnREksTUFBaEQsS0FBMkQsS0FBOUQsRUFBcUU7QUFDakVMLFFBQUFBLE9BQU87QUFDVjtBQUNKOztBQUNESixJQUFBQSxHQUFHLElBQUlJLE9BQU8sQ0FBQ00sUUFBUixFQUFQO0FBQ0EsU0FBS1QsSUFBTCxDQUFVSyxZQUFWLENBQXVCaEIsRUFBRSxDQUFDcUIsS0FBMUIsRUFBaUNDLE1BQWpDLEdBQTBDWixHQUExQztBQUNIO0FBckNJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBqaWFuZ3NoaToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgdmFyIHN0ciA9ICfmraPluLjnu4bog57mgLvmlbDvvJonO1xyXG4gICAgICAgIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDEnKSB7XHJcbiAgICAgICAgICAgIHN0ciArPSAnMTAnO1xyXG4gICAgICAgIH0gZWxzZSBpZih0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAyJykge1xyXG4gICAgICAgICAgICBzdHIgKz0gJzIyJztcclxuICAgICAgICB9IGVsc2UgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50LnBhcmVudC5uYW1lID09PSAnTGV2ZWwwMycpIHtcclxuICAgICAgICAgICAgc3RyICs9ICczNic7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN0ciArPSAnXFxuJztcclxuICAgICAgICBzdHIgKz0gJ+W3sue7j+atu+S6oeaVsOmHj++8mic7XHJcbiAgICAgICAgdmFyIGRlYWROdW0gPSAwO1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnem91JykubnVtOyBpKyspIHtcclxuICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3pvdScpLm5vcm1hbENlbGxbaV0uYWN0aXZlID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgZGVhZE51bSsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN0ciArPSBkZWFkTnVtLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gc3RyO1xyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==