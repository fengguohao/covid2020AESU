
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/gameControl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c7e99PQC3dM87gUdbfhKMrm', 'gameControl');
// 人体免疫/scripts/gameControl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    gameStatus: 'gaming'
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.gameStatus = 'gaming';
    this.node.parent.getChildByName('Box').active = false;
  },
  start: function start() {},
  handleFailure: function handleFailure() {
    if (this.gameStatus === 'fail') {
      //以下是游戏失败需要进行的操作
      this.node.parent.getChildByName('Box').active = true;
      this.node.parent.getChildByName('Box').getChildByName('back').getComponent(cc.Label).string = '很遗憾，游戏失败！';
    }
  },
  handleSuccess: function handleSuccess() {
    if (this.gameStatus === 'succeed') {
      //以下是成功过关需要进行的操作
      this.node.parent.getChildByName('Box').active = true;
      this.node.parent.getChildByName('Box').getChildByName('back').getComponent(cc.Label).string = '恭喜你，成功过关！'; //'hasPassed'是字符串键值，在板块总场景也要用这个名字，'hasPassed'的初始值为0

      if (this.node.parent.parent.name === 'Level01' && cc.sys.localStorage.getItem('hasPassed') === '0') {
        cc.sys.localStorage.setItem('hasPassed', 1);
      } else if (this.node.parent.parent.name === 'Level02' && cc.sys.localStorage.getItem('hasPassed') === '1') {
        cc.sys.localStorage.setItem('hasPassed', 2);
      } else if (this.node.parent.parent.name === 'Level03' && cc.sys.localStorage.getItem('hasPassed') === '2') {
        cc.sys.localStorage.setItem('hasPassed', 3);
      }
    }
  },
  onClick: function onClick() {
    cc.director.loadScene('人体免疫(总)');
  },
  update: function update(dt) {
    this.handleFailure();
    this.handleSuccess();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxnYW1lQ29udHJvbC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImdhbWVTdGF0dXMiLCJvbkxvYWQiLCJub2RlIiwicGFyZW50IiwiZ2V0Q2hpbGRCeU5hbWUiLCJhY3RpdmUiLCJzdGFydCIsImhhbmRsZUZhaWx1cmUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsImhhbmRsZVN1Y2Nlc3MiLCJuYW1lIiwic3lzIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNldEl0ZW0iLCJvbkNsaWNrIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBRTtBQURKLEdBSFA7QUFPTDtBQUVBQyxFQUFBQSxNQVRLLG9CQVNLO0FBQ04sU0FBS0QsVUFBTCxHQUFrQixRQUFsQjtBQUNBLFNBQUtFLElBQUwsQ0FBVUMsTUFBVixDQUFpQkMsY0FBakIsQ0FBZ0MsS0FBaEMsRUFBdUNDLE1BQXZDLEdBQWdELEtBQWhEO0FBQ0gsR0FaSTtBQWNMQyxFQUFBQSxLQWRLLG1CQWNJLENBRVIsQ0FoQkk7QUFrQkxDLEVBQUFBLGFBQWEsRUFBRSx5QkFBVztBQUN0QixRQUFHLEtBQUtQLFVBQUwsS0FBb0IsTUFBdkIsRUFBK0I7QUFDM0I7QUFDQSxXQUFLRSxJQUFMLENBQVVDLE1BQVYsQ0FBaUJDLGNBQWpCLENBQWdDLEtBQWhDLEVBQXVDQyxNQUF2QyxHQUFnRCxJQUFoRDtBQUNBLFdBQUtILElBQUwsQ0FBVUMsTUFBVixDQUFpQkMsY0FBakIsQ0FBZ0MsS0FBaEMsRUFBdUNBLGNBQXZDLENBQXNELE1BQXRELEVBQThESSxZQUE5RCxDQUEyRVosRUFBRSxDQUFDYSxLQUE5RSxFQUFxRkMsTUFBckYsR0FBOEYsV0FBOUY7QUFDSDtBQUNKLEdBeEJJO0FBMEJMQyxFQUFBQSxhQUFhLEVBQUUseUJBQVc7QUFDdEIsUUFBRyxLQUFLWCxVQUFMLEtBQW9CLFNBQXZCLEVBQWtDO0FBQzlCO0FBQ0EsV0FBS0UsSUFBTCxDQUFVQyxNQUFWLENBQWlCQyxjQUFqQixDQUFnQyxLQUFoQyxFQUF1Q0MsTUFBdkMsR0FBZ0QsSUFBaEQ7QUFDQSxXQUFLSCxJQUFMLENBQVVDLE1BQVYsQ0FBaUJDLGNBQWpCLENBQWdDLEtBQWhDLEVBQXVDQSxjQUF2QyxDQUFzRCxNQUF0RCxFQUE4REksWUFBOUQsQ0FBMkVaLEVBQUUsQ0FBQ2EsS0FBOUUsRUFBcUZDLE1BQXJGLEdBQThGLFdBQTlGLENBSDhCLENBSTlCOztBQUNBLFVBQUcsS0FBS1IsSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QlMsSUFBeEIsS0FBaUMsU0FBakMsSUFBOENoQixFQUFFLENBQUNpQixHQUFILENBQU9DLFlBQVAsQ0FBb0JDLE9BQXBCLENBQTRCLFdBQTVCLE1BQTZDLEdBQTlGLEVBQW1HO0FBQy9GbkIsUUFBQUEsRUFBRSxDQUFDaUIsR0FBSCxDQUFPQyxZQUFQLENBQW9CRSxPQUFwQixDQUE0QixXQUE1QixFQUF5QyxDQUF6QztBQUNILE9BRkQsTUFFTyxJQUFHLEtBQUtkLElBQUwsQ0FBVUMsTUFBVixDQUFpQkEsTUFBakIsQ0FBd0JTLElBQXhCLEtBQWlDLFNBQWpDLElBQThDaEIsRUFBRSxDQUFDaUIsR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixXQUE1QixNQUE2QyxHQUE5RixFQUFtRztBQUN0R25CLFFBQUFBLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkUsT0FBcEIsQ0FBNEIsV0FBNUIsRUFBeUMsQ0FBekM7QUFDSCxPQUZNLE1BRUEsSUFBRyxLQUFLZCxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCUyxJQUF4QixLQUFpQyxTQUFqQyxJQUE4Q2hCLEVBQUUsQ0FBQ2lCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsTUFBNkMsR0FBOUYsRUFBbUc7QUFDdEduQixRQUFBQSxFQUFFLENBQUNpQixHQUFILENBQU9DLFlBQVAsQ0FBb0JFLE9BQXBCLENBQTRCLFdBQTVCLEVBQXlDLENBQXpDO0FBQ0g7QUFDSjtBQUNKLEdBeENJO0FBMENMQyxFQUFBQSxPQUFPLEVBQUUsbUJBQVc7QUFDaEJyQixJQUFBQSxFQUFFLENBQUNzQixRQUFILENBQVlDLFNBQVosQ0FBc0IsU0FBdEI7QUFDSCxHQTVDSTtBQThDTEMsRUFBQUEsTUE5Q0ssa0JBOENHQyxFQTlDSCxFQThDTztBQUNSLFNBQUtkLGFBQUw7QUFDQSxTQUFLSSxhQUFMO0FBQ0g7QUFqREksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGdhbWVTdGF0dXM6ICdnYW1pbmcnLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuZ2FtZVN0YXR1cyA9ICdnYW1pbmcnO1xyXG4gICAgICAgIHRoaXMubm9kZS5wYXJlbnQuZ2V0Q2hpbGRCeU5hbWUoJ0JveCcpLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBoYW5kbGVGYWlsdXJlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBpZih0aGlzLmdhbWVTdGF0dXMgPT09ICdmYWlsJykge1xyXG4gICAgICAgICAgICAvL+S7peS4i+aYr+a4uOaIj+Wksei0pemcgOimgei/m+ihjOeahOaTjeS9nFxyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENoaWxkQnlOYW1lKCdCb3gnKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENoaWxkQnlOYW1lKCdCb3gnKS5nZXRDaGlsZEJ5TmFtZSgnYmFjaycpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+W+iOmBl+aGvu+8jOa4uOaIj+Wksei0pe+8gSc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBoYW5kbGVTdWNjZXNzOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBpZih0aGlzLmdhbWVTdGF0dXMgPT09ICdzdWNjZWVkJykge1xyXG4gICAgICAgICAgICAvL+S7peS4i+aYr+aIkOWKn+i/h+WFs+mcgOimgei/m+ihjOeahOaTjeS9nFxyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENoaWxkQnlOYW1lKCdCb3gnKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LmdldENoaWxkQnlOYW1lKCdCb3gnKS5nZXRDaGlsZEJ5TmFtZSgnYmFjaycpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+aBreWWnOS9oO+8jOaIkOWKn+i/h+WFs++8gSc7XHJcbiAgICAgICAgICAgIC8vJ2hhc1Bhc3NlZCfmmK/lrZfnrKbkuLLplK7lgLzvvIzlnKjmnb/lnZfmgLvlnLrmma/kuZ/opoHnlKjov5nkuKrlkI3lrZfvvIwnaGFzUGFzc2VkJ+eahOWIneWni+WAvOS4ujBcclxuICAgICAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDEnICYmIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGFzUGFzc2VkJykgPT09ICcwJykge1xyXG4gICAgICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdoYXNQYXNzZWQnLCAxKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAyJyAmJiBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hhc1Bhc3NlZCcpID09PSAnMScpIHtcclxuICAgICAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaGFzUGFzc2VkJywgMik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZih0aGlzLm5vZGUucGFyZW50LnBhcmVudC5uYW1lID09PSAnTGV2ZWwwMycgJiYgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdoYXNQYXNzZWQnKSA9PT0gJzInKSB7XHJcbiAgICAgICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2hhc1Bhc3NlZCcsIDMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkNsaWNrOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ+S6uuS9k+WFjeeWqyjmgLspJyk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmhhbmRsZUZhaWx1cmUoKTtcclxuICAgICAgICB0aGlzLmhhbmRsZVN1Y2Nlc3MoKTtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=