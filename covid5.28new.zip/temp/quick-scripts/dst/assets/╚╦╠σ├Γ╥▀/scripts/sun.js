
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/sun.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0fab77a7AFEIIwi1r3W0YYd', 'sun');
// 人体免疫/scripts/sun.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    sunNum: 100,
    total: 100
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.sunNum = 100;
    this.total = this.sunNum;
  },
  start: function start() {},
  checkFailure: function checkFailure() {
    if (this.total >= 4000) {
      this.node.parent.parent.getComponent('gameControl').gameStatus = 'fail';
    }
  },
  update: function update(dt) {
    var str = '现有细胞因子：';
    str += this.sunNum;
    str += '\n';
    str += '累计细胞因子：';
    str += this.total;
    this.node.getComponent(cc.Label).string = str;
    this.checkFailure();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxzdW4uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdW5OdW0iLCJ0b3RhbCIsIm9uTG9hZCIsInN0YXJ0IiwiY2hlY2tGYWlsdXJlIiwibm9kZSIsInBhcmVudCIsImdldENvbXBvbmVudCIsImdhbWVTdGF0dXMiLCJ1cGRhdGUiLCJkdCIsInN0ciIsIkxhYmVsIiwic3RyaW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFFLEdBREE7QUFFUkMsSUFBQUEsS0FBSyxFQUFFO0FBRkMsR0FIUDtBQVFMO0FBRUFDLEVBQUFBLE1BVkssb0JBVUs7QUFDTixTQUFLRixNQUFMLEdBQWMsR0FBZDtBQUNBLFNBQUtDLEtBQUwsR0FBYSxLQUFLRCxNQUFsQjtBQUNILEdBYkk7QUFlTEcsRUFBQUEsS0FmSyxtQkFlSSxDQUVSLENBakJJO0FBbUJMQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDckIsUUFBRyxLQUFLSCxLQUFMLElBQWMsSUFBakIsRUFBdUI7QUFDbkIsV0FBS0ksSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkMsWUFBeEIsQ0FBcUMsYUFBckMsRUFBb0RDLFVBQXBELEdBQWlFLE1BQWpFO0FBQ0g7QUFDSixHQXZCSTtBQXlCTEMsRUFBQUEsTUF6Qkssa0JBeUJHQyxFQXpCSCxFQXlCTztBQUVSLFFBQUlDLEdBQUcsR0FBRyxTQUFWO0FBQ0FBLElBQUFBLEdBQUcsSUFBSSxLQUFLWCxNQUFaO0FBQ0FXLElBQUFBLEdBQUcsSUFBSSxJQUFQO0FBQ0FBLElBQUFBLEdBQUcsSUFBSSxTQUFQO0FBQ0FBLElBQUFBLEdBQUcsSUFBSSxLQUFLVixLQUFaO0FBQ0EsU0FBS0ksSUFBTCxDQUFVRSxZQUFWLENBQXVCWCxFQUFFLENBQUNnQixLQUExQixFQUFpQ0MsTUFBakMsR0FBMENGLEdBQTFDO0FBQ0EsU0FBS1AsWUFBTDtBQUNIO0FBbENJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzdW5OdW06IDEwMCxcclxuICAgICAgICB0b3RhbDogMTAwLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuc3VuTnVtID0gMTAwO1xyXG4gICAgICAgIHRoaXMudG90YWwgPSB0aGlzLnN1bk51bTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgY2hlY2tGYWlsdXJlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBpZih0aGlzLnRvdGFsID49IDQwMDApIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnBhcmVudC5wYXJlbnQuZ2V0Q29tcG9uZW50KCdnYW1lQ29udHJvbCcpLmdhbWVTdGF0dXMgPSAnZmFpbCc7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdmFyIHN0ciA9ICfnjrDmnInnu4bog57lm6DlrZDvvJonO1xyXG4gICAgICAgIHN0ciArPSB0aGlzLnN1bk51bTtcclxuICAgICAgICBzdHIgKz0gJ1xcbic7XHJcbiAgICAgICAgc3RyICs9ICfntK/orqHnu4bog57lm6DlrZDvvJonO1xyXG4gICAgICAgIHN0ciArPSB0aGlzLnRvdGFsO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IHN0cjtcclxuICAgICAgICB0aGlzLmNoZWNrRmFpbHVyZSgpO1xyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==