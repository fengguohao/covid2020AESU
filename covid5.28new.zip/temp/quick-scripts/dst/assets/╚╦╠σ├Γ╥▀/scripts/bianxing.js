
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/bianxing.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2a4faLPnmNIwafUZ+RAocLV', 'bianxing');
// 人体免疫/scripts/bianxing.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    jiangshi: cc.Node,
    sp: cc.SpriteFrame,
    changeTime: [],
    clip: {
      "default": null,
      type: cc.AudioClip
    },
    liejie: {
      "default": null,
      type: cc.AnimationClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  init: function init() {
    for (var i = 0; i < this.node.getComponent('TCytotoxicCell').num; i++) {
      if (this.changeTime[i] === undefined) {
        this.changeTime[i] = 0;
      }
    }
  },
  check: function check() {
    var TCytotoxicCell = this.node.getComponent('TCytotoxicCell').sunFlower;

    for (var i = 0; i < this.node.getComponent('TCytotoxicCell').num; i++) {
      for (var j = 0; j < this.jiangshi.getComponent('piao').num; j++) {
        if (TCytotoxicCell[i].active === true && this.jiangshi.getComponent('piao').infectedCell[j].active === true && Math.abs(TCytotoxicCell[i].y - this.jiangshi.getComponent('piao').infectedCell[j].y) <= 1 && this.jiangshi.getComponent('piao').infectedCell[j].x >= TCytotoxicCell[i].x && this.jiangshi.getComponent('piao').infectedCell[j].x - TCytotoxicCell[i].x <= 20 && this.jiangshi.getComponent('piao').hasChanged[j] === false) {
          this.transform(i, j);
        }
      }
    }
  },
  transform: function transform(i, j) {
    this.changeTime[i]++;
    this.jiangshi.getComponent('piao').HP[j] -= 5;
    this.jiangshi.getComponent('piao').infectedCell[j].getComponent(cc.Sprite).spriteFrame = this.sp;
    this.jiangshi.getComponent('piao').hasChanged[j] = true;
    cc.audioEngine.play(this.clip, false, 1);
    var ani = this.jiangshi.getComponent('piao').infectedCell[j].addComponent(cc.Animation);
    ani.addClip(this.liejie, 'liejie');
    ani.node = this.jiangshi.getComponent('piao').infectedCell[j];
    ani.play('liejie');

    if (this.changeTime[i] === 5) {
      this.node.getComponent('TCytotoxicCell').sunFlower[i].active = false;
    }
  },
  update: function update(dt) {
    this.init();
    this.check();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxiaWFueGluZy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImppYW5nc2hpIiwiTm9kZSIsInNwIiwiU3ByaXRlRnJhbWUiLCJjaGFuZ2VUaW1lIiwiY2xpcCIsInR5cGUiLCJBdWRpb0NsaXAiLCJsaWVqaWUiLCJBbmltYXRpb25DbGlwIiwic3RhcnQiLCJpbml0IiwiaSIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJudW0iLCJ1bmRlZmluZWQiLCJjaGVjayIsIlRDeXRvdG94aWNDZWxsIiwic3VuRmxvd2VyIiwiaiIsImFjdGl2ZSIsImluZmVjdGVkQ2VsbCIsIk1hdGgiLCJhYnMiLCJ5IiwieCIsImhhc0NoYW5nZWQiLCJ0cmFuc2Zvcm0iLCJIUCIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwiYXVkaW9FbmdpbmUiLCJwbGF5IiwiYW5pIiwiYWRkQ29tcG9uZW50IiwiQW5pbWF0aW9uIiwiYWRkQ2xpcCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsUUFBUSxFQUFFSixFQUFFLENBQUNLLElBREw7QUFFUkMsSUFBQUEsRUFBRSxFQUFFTixFQUFFLENBQUNPLFdBRkM7QUFHUkMsSUFBQUEsVUFBVSxFQUFFLEVBSEo7QUFJUkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0YsaUJBQVMsSUFEUDtBQUVGQyxNQUFBQSxJQUFJLEVBQUVWLEVBQUUsQ0FBQ1c7QUFGUCxLQUpFO0FBUVJDLElBQUFBLE1BQU0sRUFBQztBQUNILGlCQUFRLElBREw7QUFFSEYsTUFBQUEsSUFBSSxFQUFDVixFQUFFLENBQUNhO0FBRkw7QUFSQyxHQUhQO0FBaUJMO0FBRUE7QUFFQUMsRUFBQUEsS0FyQkssbUJBcUJJLENBRVIsQ0F2Qkk7QUF5QkxDLEVBQUFBLElBQUksRUFBRSxnQkFBVztBQUNiLFNBQUksSUFBSUMsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QixnQkFBdkIsRUFBeUNDLEdBQTVELEVBQWlFSCxDQUFDLEVBQWxFLEVBQXNFO0FBQ2xFLFVBQUcsS0FBS1IsVUFBTCxDQUFnQlEsQ0FBaEIsTUFBdUJJLFNBQTFCLEVBQXFDO0FBQ2pDLGFBQUtaLFVBQUwsQ0FBZ0JRLENBQWhCLElBQXFCLENBQXJCO0FBQ0g7QUFDSjtBQUNKLEdBL0JJO0FBaUNMSyxFQUFBQSxLQUFLLEVBQUUsaUJBQVc7QUFDZCxRQUFJQyxjQUFjLEdBQUcsS0FBS0wsSUFBTCxDQUFVQyxZQUFWLENBQXVCLGdCQUF2QixFQUF5Q0ssU0FBOUQ7O0FBQ0EsU0FBSSxJQUFJUCxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCLGdCQUF2QixFQUF5Q0MsR0FBNUQsRUFBaUVILENBQUMsRUFBbEUsRUFBc0U7QUFDbEUsV0FBSSxJQUFJUSxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsS0FBS3BCLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ0MsR0FBdEQsRUFBMkRLLENBQUMsRUFBNUQsRUFBZ0U7QUFDNUQsWUFBR0YsY0FBYyxDQUFDTixDQUFELENBQWQsQ0FBa0JTLE1BQWxCLEtBQTZCLElBQTdCLElBQXFDLEtBQUtyQixRQUFMLENBQWNjLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNRLFlBQW5DLENBQWdERixDQUFoRCxFQUFtREMsTUFBbkQsS0FBOEQsSUFBbkcsSUFDSEUsSUFBSSxDQUFDQyxHQUFMLENBQVNOLGNBQWMsQ0FBQ04sQ0FBRCxDQUFkLENBQWtCYSxDQUFsQixHQUFzQixLQUFLekIsUUFBTCxDQUFjYyxZQUFkLENBQTJCLE1BQTNCLEVBQW1DUSxZQUFuQyxDQUFnREYsQ0FBaEQsRUFBbURLLENBQWxGLEtBQXdGLENBRHJGLElBRUgsS0FBS3pCLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ1EsWUFBbkMsQ0FBZ0RGLENBQWhELEVBQW1ETSxDQUFuRCxJQUF3RFIsY0FBYyxDQUFDTixDQUFELENBQWQsQ0FBa0JjLENBRnZFLElBR0gsS0FBSzFCLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ1EsWUFBbkMsQ0FBZ0RGLENBQWhELEVBQW1ETSxDQUFuRCxHQUF1RFIsY0FBYyxDQUFDTixDQUFELENBQWQsQ0FBa0JjLENBQXpFLElBQThFLEVBSDNFLElBSUgsS0FBSzFCLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ2EsVUFBbkMsQ0FBOENQLENBQTlDLE1BQXFELEtBSnJELEVBSTREO0FBQ3hELGVBQUtRLFNBQUwsQ0FBZWhCLENBQWYsRUFBa0JRLENBQWxCO0FBQ0g7QUFDSjtBQUNKO0FBQ0osR0E5Q0k7QUFnRExRLEVBQUFBLFNBQVMsRUFBRSxtQkFBU2hCLENBQVQsRUFBWVEsQ0FBWixFQUFlO0FBQ3RCLFNBQUtoQixVQUFMLENBQWdCUSxDQUFoQjtBQUNBLFNBQUtaLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ2UsRUFBbkMsQ0FBc0NULENBQXRDLEtBQTRDLENBQTVDO0FBQ0EsU0FBS3BCLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ1EsWUFBbkMsQ0FBZ0RGLENBQWhELEVBQW1ETixZQUFuRCxDQUFnRWxCLEVBQUUsQ0FBQ2tDLE1BQW5FLEVBQTJFQyxXQUEzRSxHQUF5RixLQUFLN0IsRUFBOUY7QUFDQSxTQUFLRixRQUFMLENBQWNjLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNhLFVBQW5DLENBQThDUCxDQUE5QyxJQUFtRCxJQUFuRDtBQUNBeEIsSUFBQUEsRUFBRSxDQUFDb0MsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUs1QixJQUF6QixFQUErQixLQUEvQixFQUFzQyxDQUF0QztBQUNBLFFBQUk2QixHQUFHLEdBQUcsS0FBS2xDLFFBQUwsQ0FBY2MsWUFBZCxDQUEyQixNQUEzQixFQUFtQ1EsWUFBbkMsQ0FBZ0RGLENBQWhELEVBQW1EZSxZQUFuRCxDQUFnRXZDLEVBQUUsQ0FBQ3dDLFNBQW5FLENBQVY7QUFDQUYsSUFBQUEsR0FBRyxDQUFDRyxPQUFKLENBQVksS0FBSzdCLE1BQWpCLEVBQXdCLFFBQXhCO0FBQ0EwQixJQUFBQSxHQUFHLENBQUNyQixJQUFKLEdBQVcsS0FBS2IsUUFBTCxDQUFjYyxZQUFkLENBQTJCLE1BQTNCLEVBQW1DUSxZQUFuQyxDQUFnREYsQ0FBaEQsQ0FBWDtBQUNBYyxJQUFBQSxHQUFHLENBQUNELElBQUosQ0FBUyxRQUFUOztBQUNBLFFBQUcsS0FBSzdCLFVBQUwsQ0FBZ0JRLENBQWhCLE1BQXVCLENBQTFCLEVBQTZCO0FBQ3pCLFdBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QixnQkFBdkIsRUFBeUNLLFNBQXpDLENBQW1EUCxDQUFuRCxFQUFzRFMsTUFBdEQsR0FBK0QsS0FBL0Q7QUFDSDtBQUNKLEdBN0RJO0FBK0RMaUIsRUFBQUEsTUEvREssa0JBK0RHQyxFQS9ESCxFQStETztBQUNSLFNBQUs1QixJQUFMO0FBQ0EsU0FBS00sS0FBTDtBQUNIO0FBbEVJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBqaWFuZ3NoaTogY2MuTm9kZSxcclxuICAgICAgICBzcDogY2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgY2hhbmdlVGltZTogW10sXHJcbiAgICAgICAgY2xpcDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXAsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBsaWVqaWU6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQW5pbWF0aW9uQ2xpcCxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBpbml0OiBmdW5jdGlvbigpIHtcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnVEN5dG90b3hpY0NlbGwnKS5udW07IGkrKykge1xyXG4gICAgICAgICAgICBpZih0aGlzLmNoYW5nZVRpbWVbaV0gPT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VUaW1lW2ldID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgY2hlY2s6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBUQ3l0b3RveGljQ2VsbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ1RDeXRvdG94aWNDZWxsJykuc3VuRmxvd2VyO1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdUQ3l0b3RveGljQ2VsbCcpLm51bTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaiA9IDA7IGogPCB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLm51bTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZihUQ3l0b3RveGljQ2VsbFtpXS5hY3RpdmUgPT09IHRydWUgJiYgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0uYWN0aXZlID09PSB0cnVlICYmXHJcbiAgICAgICAgICAgICAgICBNYXRoLmFicyhUQ3l0b3RveGljQ2VsbFtpXS55IC0gdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0ueSkgPD0gMSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0ueCA+PSBUQ3l0b3RveGljQ2VsbFtpXS54ICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtqXS54IC0gVEN5dG90b3hpY0NlbGxbaV0ueCA8PSAyMCAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5oYXNDaGFuZ2VkW2pdID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudHJhbnNmb3JtKGksIGopO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICB0cmFuc2Zvcm06IGZ1bmN0aW9uKGksIGopIHtcclxuICAgICAgICB0aGlzLmNoYW5nZVRpbWVbaV0rKztcclxuICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLkhQW2pdIC09IDU7XHJcbiAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0uZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSB0aGlzLnNwO1xyXG4gICAgICAgIHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdwaWFvJykuaGFzQ2hhbmdlZFtqXSA9IHRydWU7XHJcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLmNsaXAsIGZhbHNlLCAxKTtcclxuICAgICAgICB2YXIgYW5pID0gdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal0uYWRkQ29tcG9uZW50KGNjLkFuaW1hdGlvbik7XHJcbiAgICAgICAgYW5pLmFkZENsaXAodGhpcy5saWVqaWUsJ2xpZWppZScpO1xyXG4gICAgICAgIGFuaS5ub2RlID0gdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbal07XHJcbiAgICAgICAgYW5pLnBsYXkoJ2xpZWppZScpO1xyXG4gICAgICAgIGlmKHRoaXMuY2hhbmdlVGltZVtpXSA9PT0gNSkge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdUQ3l0b3RveGljQ2VsbCcpLnN1bkZsb3dlcltpXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmluaXQoKTtcclxuICAgICAgICB0aGlzLmNoZWNrKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19