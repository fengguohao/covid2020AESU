
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/tujian.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ef7a7af37JMM69x6bhVlkCA', 'tujian');
// 人体免疫/scripts/tujian.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    mySprite: cc.Sprite,
    myAtlas: cc.SpriteAtlas
  },
  // LIFE-CYCLE CALLBACKS:
  //onLoad () {},
  click1: function click1() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('NK介绍');
  },
  click2: function click2() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('WBC介绍');
  },
  click3: function click3() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('巨噬细胞介绍');
  },
  click4: function click4() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('树突状细胞介绍');
  },
  click5: function click5() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('B细胞介绍');
  },
  click6: function click6() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('T细胞介绍');
  },
  click7: function click7() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('辅助T细胞介绍');
  },
  click8: function click8() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞毒性T细胞介绍');
  },
  click9: function click9() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞因子介绍');
  },
  click10: function click10() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('抗病毒药物');
  },
  click11: function click11() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞因子抑制剂介绍');
  },
  click12: function click12() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('病毒介绍');
  },
  click13: function click13() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('感染细胞介绍');
  },
  click14: function click14() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('规则介绍');
  },
  click15: function click15() {
    cc.director.loadScene("人体免疫(总)");
  },
  start: function start() {} //update (dt) { this.click2;},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFx0dWppYW4uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJteVNwcml0ZSIsIlNwcml0ZSIsIm15QXRsYXMiLCJTcHJpdGVBdGxhcyIsImNsaWNrMSIsInNwcml0ZUZyYW1lIiwiZ2V0U3ByaXRlRnJhbWUiLCJjbGljazIiLCJjbGljazMiLCJjbGljazQiLCJjbGljazUiLCJjbGljazYiLCJjbGljazciLCJjbGljazgiLCJjbGljazkiLCJjbGljazEwIiwiY2xpY2sxMSIsImNsaWNrMTIiLCJjbGljazEzIiwiY2xpY2sxNCIsImNsaWNrMTUiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsUUFBUSxFQUFDSixFQUFFLENBQUNLLE1BREo7QUFFUkMsSUFBQUEsT0FBTyxFQUFDTixFQUFFLENBQUNPO0FBRkgsR0FIUDtBQVFMO0FBRUE7QUFDQUMsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2IsU0FBS0osUUFBTCxDQUFjSyxXQUFkLEdBQTRCLEtBQUtILE9BQUwsQ0FBYUksY0FBYixDQUE0QixNQUE1QixDQUE1QjtBQUNILEdBYkk7QUFjTEMsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ1osU0FBS1AsUUFBTCxDQUFjSyxXQUFkLEdBQTRCLEtBQUtILE9BQUwsQ0FBYUksY0FBYixDQUE0QixPQUE1QixDQUE1QjtBQUNKLEdBaEJJO0FBaUJMRSxFQUFBQSxNQUFNLEVBQUMsa0JBQVU7QUFDYixTQUFLUixRQUFMLENBQWNLLFdBQWQsR0FBNEIsS0FBS0gsT0FBTCxDQUFhSSxjQUFiLENBQTRCLFFBQTVCLENBQTVCO0FBQ0gsR0FuQkk7QUFvQkxHLEVBQUFBLE1BQU0sRUFBQyxrQkFBVTtBQUNiLFNBQUtULFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsU0FBNUIsQ0FBNUI7QUFDSCxHQXRCSTtBQXVCTEksRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2IsU0FBS1YsUUFBTCxDQUFjSyxXQUFkLEdBQTRCLEtBQUtILE9BQUwsQ0FBYUksY0FBYixDQUE0QixPQUE1QixDQUE1QjtBQUNILEdBekJJO0FBMEJMSyxFQUFBQSxNQUFNLEVBQUMsa0JBQVU7QUFDYixTQUFLWCxRQUFMLENBQWNLLFdBQWQsR0FBNEIsS0FBS0gsT0FBTCxDQUFhSSxjQUFiLENBQTRCLE9BQTVCLENBQTVCO0FBQ0gsR0E1Qkk7QUE2QkxNLEVBQUFBLE1BQU0sRUFBQyxrQkFBVTtBQUNiLFNBQUtaLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsU0FBNUIsQ0FBNUI7QUFDSCxHQS9CSTtBQWdDTE8sRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2IsU0FBS2IsUUFBTCxDQUFjSyxXQUFkLEdBQTRCLEtBQUtILE9BQUwsQ0FBYUksY0FBYixDQUE0QixXQUE1QixDQUE1QjtBQUNILEdBbENJO0FBbUNMUSxFQUFBQSxNQUFNLEVBQUMsa0JBQVU7QUFDYixTQUFLZCxRQUFMLENBQWNLLFdBQWQsR0FBNEIsS0FBS0gsT0FBTCxDQUFhSSxjQUFiLENBQTRCLFFBQTVCLENBQTVCO0FBQ0gsR0FyQ0k7QUFzQ0xTLEVBQUFBLE9BQU8sRUFBQyxtQkFBVTtBQUNkLFNBQUtmLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsT0FBNUIsQ0FBNUI7QUFDSCxHQXhDSTtBQXlDTFUsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS2hCLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsV0FBNUIsQ0FBNUI7QUFDSCxHQTNDSTtBQTRDTFcsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS2pCLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsTUFBNUIsQ0FBNUI7QUFDSCxHQTlDSTtBQStDTFksRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS2xCLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsUUFBNUIsQ0FBNUI7QUFDSCxHQWpESTtBQWtETGEsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS25CLFFBQUwsQ0FBY0ssV0FBZCxHQUE0QixLQUFLSCxPQUFMLENBQWFJLGNBQWIsQ0FBNEIsTUFBNUIsQ0FBNUI7QUFDSCxHQXBESTtBQXFETGMsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2R4QixJQUFBQSxFQUFFLENBQUN5QixRQUFILENBQVlDLFNBQVosQ0FBc0IsU0FBdEI7QUFDSCxHQXZESTtBQXlETEMsRUFBQUEsS0F6REssbUJBeURJLENBRVIsQ0EzREksQ0E2REw7O0FBN0RLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBteVNwcml0ZTpjYy5TcHJpdGUsXHJcbiAgICAgICAgbXlBdGxhczpjYy5TcHJpdGVBdGxhcyxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy9vbkxvYWQgKCkge30sXHJcbiAgICBjbGljazE6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCdOS+S7i+e7jScpO1xyXG4gICAgfSxcclxuICAgIGNsaWNrMjpmdW5jdGlvbigpe1xyXG4gICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCdXQkPku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazM6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCflt6jlmaznu4bog57ku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCfmoJHnqoHnirbnu4bog57ku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazU6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCdC57uG6IOe5LuL57uNJyk7XHJcbiAgICB9LFxyXG4gICAgY2xpY2s2OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5teVNwcml0ZS5zcHJpdGVGcmFtZSA9IHRoaXMubXlBdGxhcy5nZXRTcHJpdGVGcmFtZSgnVOe7huiDnuS7i+e7jScpO1xyXG4gICAgfSxcclxuICAgIGNsaWNrNzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubXlTcHJpdGUuc3ByaXRlRnJhbWUgPSB0aGlzLm15QXRsYXMuZ2V0U3ByaXRlRnJhbWUoJ+i+heWKqVTnu4bog57ku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazg6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCfnu4bog57mr5LmgKdU57uG6IOe5LuL57uNJyk7XHJcbiAgICB9LFxyXG4gICAgY2xpY2s5OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5teVNwcml0ZS5zcHJpdGVGcmFtZSA9IHRoaXMubXlBdGxhcy5nZXRTcHJpdGVGcmFtZSgn57uG6IOe5Zug5a2Q5LuL57uNJyk7XHJcbiAgICB9LFxyXG4gICAgY2xpY2sxMDpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubXlTcHJpdGUuc3ByaXRlRnJhbWUgPSB0aGlzLm15QXRsYXMuZ2V0U3ByaXRlRnJhbWUoJ+aKl+eXheavkuiNr+eJqScpO1xyXG4gICAgfSxcclxuICAgIGNsaWNrMTE6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCfnu4bog57lm6DlrZDmipHliLbliYLku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazEyOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5teVNwcml0ZS5zcHJpdGVGcmFtZSA9IHRoaXMubXlBdGxhcy5nZXRTcHJpdGVGcmFtZSgn55eF5q+S5LuL57uNJyk7XHJcbiAgICB9LFxyXG4gICAgY2xpY2sxMzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubXlTcHJpdGUuc3ByaXRlRnJhbWUgPSB0aGlzLm15QXRsYXMuZ2V0U3ByaXRlRnJhbWUoJ+aEn+afk+e7huiDnuS7i+e7jScpO1xyXG4gICAgfSxcclxuICAgIGNsaWNrMTQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm15U3ByaXRlLnNwcml0ZUZyYW1lID0gdGhpcy5teUF0bGFzLmdldFNwcml0ZUZyYW1lKCfop4TliJnku4vnu40nKTtcclxuICAgIH0sXHJcbiAgICBjbGljazE1OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi5Lq65L2T5YWN55arKOaAuylcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vdXBkYXRlIChkdCkgeyB0aGlzLmNsaWNrMjt9LFxyXG59KTtcclxuIl19