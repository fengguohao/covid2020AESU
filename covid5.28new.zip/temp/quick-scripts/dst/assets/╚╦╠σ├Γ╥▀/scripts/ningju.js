
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/ningju.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '57e5cTCqw9Nh665h4yy/fYB', 'ningju');
// 人体免疫/scripts/ningju.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    hasActivated: [],
    hasCohered: [],
    caodi: cc.Node,
    jiangshi: cc.Node,
    clip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  init: function init() {
    for (var i = 0; i < this.node.getComponent('bozhong').num; i++) {
      if (this.hasActivated[i] === undefined) {
        this.hasActivated[i] = false;
      }

      if (this.hasCohered[i] === undefined) {
        this.hasCohered[i] = false;
      }
    }
  },
  checkActivated: function checkActivated() {
    for (var i = 0; i < this.node.getComponent('bozhong').num; i++) {
      if (this.hasActivated[i] === true && this.hasCohered[i] === false) {
        this.checkEnemy(i); //
      }
    }
  },
  checkEnemy: function checkEnemy(i) {
    var flag = false;

    for (var ii = 0; ii < this.jiangshi.getComponent('jingong').num; ii++) {
      if (Math.abs(this.jiangshi.getComponent('jingong').jiangshi[ii].y - this.node.getComponent('bozhong').sunFlower[i].y) <= 1 && this.jiangshi.getComponent('jingong').jiangshi[ii].x > this.node.getComponent('bozhong').sunFlower[i].x && this.jiangshi.getComponent('jingong').jiangshi[ii].x - this.node.getComponent('bozhong').sunFlower[i].x < 150 && this.hasCohered[i] === false) {
        flag = true;
        this.cohere(i); //
      }
    }

    for (var ii = 0; ii < this.jiangshi.getComponent('piao').num; ii++) {
      if (Math.abs(this.jiangshi.getComponent('piao').infectedCell[ii].y - this.node.getComponent('bozhong').sunFlower[i].y) <= 1 && this.jiangshi.getComponent('piao').infectedCell[ii].x > this.node.getComponent('bozhong').sunFlower[i].x && this.jiangshi.getComponent('piao').infectedCell[ii].x - this.node.getComponent('bozhong').sunFlower[i].x < 150 && this.jiangshi.getComponent('piao').hasChanged[ii] === true && flag === false && this.hasCohered[i] === false) {
        this.cohere(i);
      }
    }
  },
  cohere: function cohere(i) {
    for (var ii = 0; ii < this.jiangshi.getComponent('jingong').num; ii++) {
      if (Math.abs(this.jiangshi.getComponent('jingong').jiangshi[ii].x - this.node.getComponent('bozhong').sunFlower[i].x) < 150 && Math.abs(this.jiangshi.getComponent('jingong').jiangshi[ii].y - this.node.getComponent('bozhong').sunFlower[i].y) < 150) {
        this.jiangshi.getComponent('jingong').jiangshi[ii].stopAllActions();
        var co = cc.moveTo(1, this.node.getComponent('bozhong').sunFlower[i].getPosition());
        this.jiangshi.getComponent('jingong').jiangshi[ii].runAction(co);
        this.hasCohered[i] = true;
        cc.audioEngine.play(this.clip, false, 1);
      }
    }

    for (var ii = 0; ii < this.jiangshi.getComponent('piao').num; ii++) {
      if (Math.abs(this.jiangshi.getComponent('piao').infectedCell[ii].x - this.node.getComponent('bozhong').sunFlower[i].x) < 150 && Math.abs(this.jiangshi.getComponent('piao').infectedCell[ii].y - this.node.getComponent('bozhong').sunFlower[i].y) < 150 && this.jiangshi.getComponent('piao').hasChanged[ii] === true) {
        this.jiangshi.getComponent('piao').infectedCell[ii].stopAllActions();
        var co = cc.moveTo(1, this.node.getComponent('bozhong').sunFlower[i].getPosition());
        cc.log(this.jiangshi.getComponent('piao').infectedCell[ii]);
        this.jiangshi.getComponent('piao').infectedCell[ii].runAction(co); //

        this.hasCohered[i] = true;
        cc.audioEngine.play(this.clip, false, 1);
      }
    }

    this.scheduleOnce(function () {
      this.caodi.getComponent('juxing').isEmpty[this.node.getComponent('bozhong').currentRow[i]][this.node.getComponent('bozhong').currentCol[i]] = true;
      this.node.getComponent('bozhong').sunFlower[i].active = false; //cc.log(this.node.getComponent('bozhong').currentRow[i]);
      //cc.log(this.node.getComponent('bozhong').currentCol[i]);
    }, 1);
  },
  update: function update(dt) {
    this.init();
    this.checkActivated();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxuaW5nanUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJoYXNBY3RpdmF0ZWQiLCJoYXNDb2hlcmVkIiwiY2FvZGkiLCJOb2RlIiwiamlhbmdzaGkiLCJjbGlwIiwidHlwZSIsIkF1ZGlvQ2xpcCIsInN0YXJ0IiwiaW5pdCIsImkiLCJub2RlIiwiZ2V0Q29tcG9uZW50IiwibnVtIiwidW5kZWZpbmVkIiwiY2hlY2tBY3RpdmF0ZWQiLCJjaGVja0VuZW15IiwiZmxhZyIsImlpIiwiTWF0aCIsImFicyIsInkiLCJzdW5GbG93ZXIiLCJ4IiwiY29oZXJlIiwiaW5mZWN0ZWRDZWxsIiwiaGFzQ2hhbmdlZCIsInN0b3BBbGxBY3Rpb25zIiwiY28iLCJtb3ZlVG8iLCJnZXRQb3NpdGlvbiIsInJ1bkFjdGlvbiIsImF1ZGlvRW5naW5lIiwicGxheSIsImxvZyIsInNjaGVkdWxlT25jZSIsImlzRW1wdHkiLCJjdXJyZW50Um93IiwiY3VycmVudENvbCIsImFjdGl2ZSIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsWUFBWSxFQUFFLEVBRE47QUFFUkMsSUFBQUEsVUFBVSxFQUFFLEVBRko7QUFHUkMsSUFBQUEsS0FBSyxFQUFFTixFQUFFLENBQUNPLElBSEY7QUFJUkMsSUFBQUEsUUFBUSxFQUFFUixFQUFFLENBQUNPLElBSkw7QUFLUkUsSUFBQUEsSUFBSSxFQUFFO0FBQ0YsaUJBQVMsSUFEUDtBQUVGQyxNQUFBQSxJQUFJLEVBQUVWLEVBQUUsQ0FBQ1c7QUFGUDtBQUxFLEdBSFA7QUFjTDtBQUVBO0FBRUFDLEVBQUFBLEtBbEJLLG1CQWtCSSxDQUVSLENBcEJJO0FBc0JMQyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDYixTQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxLQUFLQyxJQUFMLENBQVVDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0NDLEdBQXJELEVBQTBESCxDQUFDLEVBQTNELEVBQStEO0FBQzNELFVBQUcsS0FBS1YsWUFBTCxDQUFrQlUsQ0FBbEIsTUFBeUJJLFNBQTVCLEVBQXVDO0FBQ25DLGFBQUtkLFlBQUwsQ0FBa0JVLENBQWxCLElBQXVCLEtBQXZCO0FBQ0g7O0FBQ0QsVUFBRyxLQUFLVCxVQUFMLENBQWdCUyxDQUFoQixNQUF1QkksU0FBMUIsRUFBcUM7QUFDakMsYUFBS2IsVUFBTCxDQUFnQlMsQ0FBaEIsSUFBcUIsS0FBckI7QUFDSDtBQUNKO0FBQ0osR0EvQkk7QUFpQ0xLLEVBQUFBLGNBQWMsRUFBRSwwQkFBVztBQUN2QixTQUFJLElBQUlMLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxLQUFLQyxJQUFMLENBQVVDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0NDLEdBQXJELEVBQTBESCxDQUFDLEVBQTNELEVBQStEO0FBQzNELFVBQUcsS0FBS1YsWUFBTCxDQUFrQlUsQ0FBbEIsTUFBeUIsSUFBekIsSUFBaUMsS0FBS1QsVUFBTCxDQUFnQlMsQ0FBaEIsTUFBdUIsS0FBM0QsRUFBa0U7QUFDOUQsYUFBS00sVUFBTCxDQUFnQk4sQ0FBaEIsRUFEOEQsQ0FDM0M7QUFDdEI7QUFDSjtBQUNKLEdBdkNJO0FBeUNMTSxFQUFBQSxVQUFVLEVBQUUsb0JBQVNOLENBQVQsRUFBWTtBQUNwQixRQUFJTyxJQUFJLEdBQUcsS0FBWDs7QUFDQSxTQUFJLElBQUlDLEVBQUUsR0FBRyxDQUFiLEVBQWdCQSxFQUFFLEdBQUcsS0FBS2QsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDQyxHQUEzRCxFQUFnRUssRUFBRSxFQUFsRSxFQUFzRTtBQUNsRSxVQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDUixRQUF0QyxDQUErQ2MsRUFBL0MsRUFBbURHLENBQW5ELEdBQXVELEtBQUtWLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDVyxDQUEvRyxLQUFxSCxDQUFySCxJQUNILEtBQUtqQixRQUFMLENBQWNRLFlBQWQsQ0FBMkIsU0FBM0IsRUFBc0NSLFFBQXRDLENBQStDYyxFQUEvQyxFQUFtREssQ0FBbkQsR0FBdUQsS0FBS1osSUFBTCxDQUFVQyxZQUFWLENBQXVCLFNBQXZCLEVBQWtDVSxTQUFsQyxDQUE0Q1osQ0FBNUMsRUFBK0NhLENBRG5HLElBRUgsS0FBS25CLFFBQUwsQ0FBY1EsWUFBZCxDQUEyQixTQUEzQixFQUFzQ1IsUUFBdEMsQ0FBK0NjLEVBQS9DLEVBQW1ESyxDQUFuRCxHQUF1RCxLQUFLWixJQUFMLENBQVVDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0NVLFNBQWxDLENBQTRDWixDQUE1QyxFQUErQ2EsQ0FBdEcsR0FBMEcsR0FGdkcsSUFHSCxLQUFLdEIsVUFBTCxDQUFnQlMsQ0FBaEIsTUFBdUIsS0FIdkIsRUFHOEI7QUFDMUJPLFFBQUFBLElBQUksR0FBRyxJQUFQO0FBQ0EsYUFBS08sTUFBTCxDQUFZZCxDQUFaLEVBRjBCLENBRVg7QUFDbEI7QUFDSjs7QUFDRCxTQUFJLElBQUlRLEVBQUUsR0FBRyxDQUFiLEVBQWdCQSxFQUFFLEdBQUcsS0FBS2QsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DQyxHQUF4RCxFQUE2REssRUFBRSxFQUEvRCxFQUFtRTtBQUMvRCxVQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DYSxZQUFuQyxDQUFnRFAsRUFBaEQsRUFBb0RHLENBQXBELEdBQXdELEtBQUtWLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDVyxDQUFoSCxLQUFzSCxDQUF0SCxJQUNILEtBQUtqQixRQUFMLENBQWNRLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNhLFlBQW5DLENBQWdEUCxFQUFoRCxFQUFvREssQ0FBcEQsR0FBd0QsS0FBS1osSUFBTCxDQUFVQyxZQUFWLENBQXVCLFNBQXZCLEVBQWtDVSxTQUFsQyxDQUE0Q1osQ0FBNUMsRUFBK0NhLENBRHBHLElBRUgsS0FBS25CLFFBQUwsQ0FBY1EsWUFBZCxDQUEyQixNQUEzQixFQUFtQ2EsWUFBbkMsQ0FBZ0RQLEVBQWhELEVBQW9ESyxDQUFwRCxHQUF3RCxLQUFLWixJQUFMLENBQVVDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0NVLFNBQWxDLENBQTRDWixDQUE1QyxFQUErQ2EsQ0FBdkcsR0FBMkcsR0FGeEcsSUFHSCxLQUFLbkIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DYyxVQUFuQyxDQUE4Q1IsRUFBOUMsTUFBc0QsSUFIbkQsSUFHMkRELElBQUksS0FBSyxLQUhwRSxJQUc2RSxLQUFLaEIsVUFBTCxDQUFnQlMsQ0FBaEIsTUFBdUIsS0FIdkcsRUFHOEc7QUFDMUcsYUFBS2MsTUFBTCxDQUFZZCxDQUFaO0FBQ0g7QUFDSjtBQUNKLEdBNURJO0FBOERMYyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNkLENBQVQsRUFBWTtBQUNoQixTQUFJLElBQUlRLEVBQUUsR0FBRyxDQUFiLEVBQWdCQSxFQUFFLEdBQUcsS0FBS2QsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDQyxHQUEzRCxFQUFnRUssRUFBRSxFQUFsRSxFQUFzRTtBQUNsRSxVQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDUixRQUF0QyxDQUErQ2MsRUFBL0MsRUFBbURLLENBQW5ELEdBQXVELEtBQUtaLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDYSxDQUEvRyxJQUFvSCxHQUFwSCxJQUNISixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDUixRQUF0QyxDQUErQ2MsRUFBL0MsRUFBbURHLENBQW5ELEdBQXVELEtBQUtWLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDVyxDQUEvRyxJQUFvSCxHQURwSCxFQUN5SDtBQUNySCxhQUFLakIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDUixRQUF0QyxDQUErQ2MsRUFBL0MsRUFBbURTLGNBQW5EO0FBQ0EsWUFBSUMsRUFBRSxHQUFHaEMsRUFBRSxDQUFDaUMsTUFBSCxDQUFVLENBQVYsRUFBYSxLQUFLbEIsSUFBTCxDQUFVQyxZQUFWLENBQXVCLFNBQXZCLEVBQWtDVSxTQUFsQyxDQUE0Q1osQ0FBNUMsRUFBK0NvQixXQUEvQyxFQUFiLENBQVQ7QUFDQSxhQUFLMUIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLFNBQTNCLEVBQXNDUixRQUF0QyxDQUErQ2MsRUFBL0MsRUFBbURhLFNBQW5ELENBQTZESCxFQUE3RDtBQUNBLGFBQUszQixVQUFMLENBQWdCUyxDQUFoQixJQUFxQixJQUFyQjtBQUNBZCxRQUFBQSxFQUFFLENBQUNvQyxXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBSzVCLElBQXpCLEVBQStCLEtBQS9CLEVBQXNDLENBQXRDO0FBQ0g7QUFDSjs7QUFDRCxTQUFJLElBQUlhLEVBQUUsR0FBRyxDQUFiLEVBQWdCQSxFQUFFLEdBQUcsS0FBS2QsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DQyxHQUF4RCxFQUE2REssRUFBRSxFQUEvRCxFQUFtRTtBQUMvRCxVQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DYSxZQUFuQyxDQUFnRFAsRUFBaEQsRUFBb0RLLENBQXBELEdBQXdELEtBQUtaLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDYSxDQUFoSCxJQUFxSCxHQUFySCxJQUNISixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLaEIsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DYSxZQUFuQyxDQUFnRFAsRUFBaEQsRUFBb0RHLENBQXBELEdBQXdELEtBQUtWLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDVyxDQUFoSCxJQUFxSCxHQURsSCxJQUVILEtBQUtqQixRQUFMLENBQWNRLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNjLFVBQW5DLENBQThDUixFQUE5QyxNQUFzRCxJQUZ0RCxFQUU0RDtBQUN4RCxhQUFLZCxRQUFMLENBQWNRLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNhLFlBQW5DLENBQWdEUCxFQUFoRCxFQUFvRFMsY0FBcEQ7QUFDQSxZQUFJQyxFQUFFLEdBQUdoQyxFQUFFLENBQUNpQyxNQUFILENBQVUsQ0FBVixFQUFhLEtBQUtsQixJQUFMLENBQVVDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0NVLFNBQWxDLENBQTRDWixDQUE1QyxFQUErQ29CLFdBQS9DLEVBQWIsQ0FBVDtBQUNBbEMsUUFBQUEsRUFBRSxDQUFDc0MsR0FBSCxDQUFPLEtBQUs5QixRQUFMLENBQWNRLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUNhLFlBQW5DLENBQWdEUCxFQUFoRCxDQUFQO0FBQ0EsYUFBS2QsUUFBTCxDQUFjUSxZQUFkLENBQTJCLE1BQTNCLEVBQW1DYSxZQUFuQyxDQUFnRFAsRUFBaEQsRUFBb0RhLFNBQXBELENBQThESCxFQUE5RCxFQUp3RCxDQUlVOztBQUNsRSxhQUFLM0IsVUFBTCxDQUFnQlMsQ0FBaEIsSUFBcUIsSUFBckI7QUFDQWQsUUFBQUEsRUFBRSxDQUFDb0MsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUs1QixJQUF6QixFQUErQixLQUEvQixFQUFzQyxDQUF0QztBQUNIO0FBQ0o7O0FBQ0QsU0FBSzhCLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixXQUFLakMsS0FBTCxDQUFXVSxZQUFYLENBQXdCLFFBQXhCLEVBQWtDd0IsT0FBbEMsQ0FBMEMsS0FBS3pCLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ3lCLFVBQWxDLENBQTZDM0IsQ0FBN0MsQ0FBMUMsRUFBMkYsS0FBS0MsSUFBTCxDQUFVQyxZQUFWLENBQXVCLFNBQXZCLEVBQWtDMEIsVUFBbEMsQ0FBNkM1QixDQUE3QyxDQUEzRixJQUE4SSxJQUE5STtBQUNBLFdBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QixTQUF2QixFQUFrQ1UsU0FBbEMsQ0FBNENaLENBQTVDLEVBQStDNkIsTUFBL0MsR0FBd0QsS0FBeEQsQ0FGeUIsQ0FHekI7QUFDQTtBQUNILEtBTEQsRUFLRyxDQUxIO0FBTUgsR0EzRkk7QUE2RkxDLEVBQUFBLE1BN0ZLLGtCQTZGR0MsRUE3RkgsRUE2Rk87QUFDUixTQUFLaEMsSUFBTDtBQUNBLFNBQUtNLGNBQUw7QUFDSDtBQWhHSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgaGFzQWN0aXZhdGVkOiBbXSxcclxuICAgICAgICBoYXNDb2hlcmVkOiBbXSxcclxuICAgICAgICBjYW9kaTogY2MuTm9kZSxcclxuICAgICAgICBqaWFuZ3NoaTogY2MuTm9kZSxcclxuICAgICAgICBjbGlwOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcCxcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgaW5pdDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5udW07IGkrKykge1xyXG4gICAgICAgICAgICBpZih0aGlzLmhhc0FjdGl2YXRlZFtpXSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhhc0FjdGl2YXRlZFtpXSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmKHRoaXMuaGFzQ29oZXJlZFtpXSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhhc0NvaGVyZWRbaV0gPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgY2hlY2tBY3RpdmF0ZWQ6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykubnVtOyBpKyspIHtcclxuICAgICAgICAgICAgaWYodGhpcy5oYXNBY3RpdmF0ZWRbaV0gPT09IHRydWUgJiYgdGhpcy5oYXNDb2hlcmVkW2ldID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0VuZW15KGkpOy8vXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGNoZWNrRW5lbXk6IGZ1bmN0aW9uKGkpIHtcclxuICAgICAgICB2YXIgZmxhZyA9IGZhbHNlO1xyXG4gICAgICAgIGZvcih2YXIgaWkgPSAwOyBpaSA8IHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdqaW5nb25nJykubnVtOyBpaSsrKSB7XHJcbiAgICAgICAgICAgIGlmKE1hdGguYWJzKHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdqaW5nb25nJykuamlhbmdzaGlbaWldLnkgLSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykuc3VuRmxvd2VyW2ldLnkpIDw9IDEgJiZcclxuICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ2ppbmdvbmcnKS5qaWFuZ3NoaVtpaV0ueCA+IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJbaV0ueCAmJlxyXG4gICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnamluZ29uZycpLmppYW5nc2hpW2lpXS54IC0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS54IDwgMTUwICYmXHJcbiAgICAgICAgICAgIHRoaXMuaGFzQ29oZXJlZFtpXSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb2hlcmUoaSk7Ly9cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGlpID0gMDsgaWkgPCB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLm51bTsgaWkrKykge1xyXG4gICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpaV0ueSAtIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJbaV0ueSkgPD0gMSAmJlxyXG4gICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpaV0ueCA+IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJbaV0ueCAmJlxyXG4gICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpaV0ueCAtIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJbaV0ueCA8IDE1MCAmJlxyXG4gICAgICAgICAgICB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmhhc0NoYW5nZWRbaWldID09PSB0cnVlICYmIGZsYWcgPT09IGZhbHNlICYmIHRoaXMuaGFzQ29oZXJlZFtpXSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29oZXJlKGkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBjb2hlcmU6IGZ1bmN0aW9uKGkpIHtcclxuICAgICAgICBmb3IodmFyIGlpID0gMDsgaWkgPCB0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnamluZ29uZycpLm51bTsgaWkrKykge1xyXG4gICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnamluZ29uZycpLmppYW5nc2hpW2lpXS54IC0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS54KSA8IDE1MCAmJlxyXG4gICAgICAgICAgICBNYXRoLmFicyh0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgnamluZ29uZycpLmppYW5nc2hpW2lpXS55IC0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS55KSA8IDE1MCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ2ppbmdvbmcnKS5qaWFuZ3NoaVtpaV0uc3RvcEFsbEFjdGlvbnMoKTtcclxuICAgICAgICAgICAgICAgIHZhciBjbyA9IGNjLm1vdmVUbygxLCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykuc3VuRmxvd2VyW2ldLmdldFBvc2l0aW9uKCkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ2ppbmdvbmcnKS5qaWFuZ3NoaVtpaV0ucnVuQWN0aW9uKGNvKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGFzQ29oZXJlZFtpXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMuY2xpcCwgZmFsc2UsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvcih2YXIgaWkgPSAwOyBpaSA8IHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtOyBpaSsrKSB7XHJcbiAgICAgICAgICAgIGlmKE1hdGguYWJzKHRoaXMuamlhbmdzaGkuZ2V0Q29tcG9uZW50KCdwaWFvJykuaW5mZWN0ZWRDZWxsW2lpXS54IC0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS54KSA8IDE1MCAmJlxyXG4gICAgICAgICAgICBNYXRoLmFicyh0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpaV0ueSAtIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5zdW5GbG93ZXJbaV0ueSkgPCAxNTAgJiZcclxuICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5oYXNDaGFuZ2VkW2lpXSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbaWldLnN0b3BBbGxBY3Rpb25zKCk7XHJcbiAgICAgICAgICAgICAgICB2YXIgY28gPSBjYy5tb3ZlVG8oMSwgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS5nZXRQb3NpdGlvbigpKTtcclxuICAgICAgICAgICAgICAgIGNjLmxvZyh0aGlzLmppYW5nc2hpLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpaV0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5qaWFuZ3NoaS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbaWldLnJ1bkFjdGlvbihjbyk7Ly9cclxuICAgICAgICAgICAgICAgIHRoaXMuaGFzQ29oZXJlZFtpXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMuY2xpcCwgZmFsc2UsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0aGlzLmNhb2RpLmdldENvbXBvbmVudCgnanV4aW5nJykuaXNFbXB0eVt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykuY3VycmVudFJvd1tpXV1bdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLmN1cnJlbnRDb2xbaV1dID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLnN1bkZsb3dlcltpXS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy9jYy5sb2codGhpcy5ub2RlLmdldENvbXBvbmVudCgnYm96aG9uZycpLmN1cnJlbnRSb3dbaV0pO1xyXG4gICAgICAgICAgICAvL2NjLmxvZyh0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdib3pob25nJykuY3VycmVudENvbFtpXSk7XHJcbiAgICAgICAgfSwgMSk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmluaXQoKTtcclxuICAgICAgICB0aGlzLmNoZWNrQWN0aXZhdGVkKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19