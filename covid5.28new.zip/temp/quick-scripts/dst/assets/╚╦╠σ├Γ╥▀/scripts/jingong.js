
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/jingong.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f0b5eyGxONLYJFt0oso4dzF', 'jingong');
// 人体免疫/scripts/jingong.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    jiangshi: [cc.Node],
    caodi: cc.Node,
    sp: {
      "default": null,
      type: cc.SpriteFrame
    },
    HP: [],
    num: 0,
    duration: 30,
    hasDestroyedAll: false,
    lastWave: false
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    if (this.node.parent.parent.parent.name === 'Level01') {
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 18 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration * 2);
    }

    if (this.node.parent.parent.parent.name === 'Level02') {
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 24 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 26 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 35 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 26 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 24 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 28 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 34 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 40 + this.duration * 4);
    }

    if (this.node.parent.parent.parent.name === 'Level03') {
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 14 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20 + this.duration);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 16 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 18 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 22 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 26 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 18 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 24 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 26 + this.duration * 3);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 22 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 24 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 34 + this.duration * 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 26 + this.duration * 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 35 + this.duration * 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 40 + this.duration * 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 42 + this.duration * 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 30 + this.duration * 6);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 34 + this.duration * 6);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 39 + this.duration * 6);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 32 + this.duration * 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 36 + this.duration * 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 40 + this.duration * 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 48 + this.duration * 7);
    }
  },
  add: function add(i) {
    var s;
    var random;
    random = Math.floor(Math.random() * 5);
    this.num++;
    this.jiangshi[i] = new cc.Node();
    this.HP[i] = 5;
    s = this.jiangshi[i].addComponent(cc.Sprite);
    s.spriteFrame = this.sp;
    this.jiangshi[i].parent = this.caodi;
    this.jiangshi[i].setPosition(this.caodi.convertToNodeSpaceAR(cc.v2(960, 506.4 - random * 100)));
    this.jiangshi[i].runAction(cc.moveTo(40, this.caodi.convertToNodeSpaceAR(cc.v2(0, 506.4 - random * 100))));
  },
  addInfectedCell: function addInfectedCell() {
    var s;
    var random;
    random = Math.floor(Math.random() * 5);
    this.node.getComponent('piao').infectedCell[this.node.getComponent('piao').num] = new cc.Node();
    this.node.getComponent('piao').HP[this.node.getComponent('piao').num] = 10;
    s = this.node.getComponent('piao').infectedCell[this.node.getComponent('piao').num].addComponent(cc.Sprite);
    s.spriteFrame = this.node.getComponent('piao').sp;
    this.node.getComponent('piao').infectedCell[this.node.getComponent('piao').num].parent = this.caodi;
    this.node.getComponent('piao').infectedCell[this.node.getComponent('piao').num].setPosition(this.caodi.convertToNodeSpaceAR(cc.v2(960, 506.4 - random * 100)));
    this.node.getComponent('piao').infectedCell[this.node.getComponent('piao').num].runAction(cc.moveTo(40, this.caodi.convertToNodeSpaceAR(cc.v2(0, 506.4 - random * 100))));
    this.node.getComponent('piao').num++;
  },
  addNormalCell: function addNormalCell() {
    var s;
    var random;
    random = Math.floor(Math.random() * 5);
    this.node.getComponent('zou').normalCell[this.node.getComponent('zou').num] = new cc.Node();
    this.node.getComponent('zou').HP[this.node.getComponent('zou').num] = 10;
    s = this.node.getComponent('zou').normalCell[this.node.getComponent('zou').num].addComponent(cc.Sprite);
    s.spriteFrame = this.node.getComponent('zou').sp;
    this.node.getComponent('zou').normalCell[this.node.getComponent('zou').num].parent = this.caodi;
    this.node.getComponent('zou').normalCell[this.node.getComponent('zou').num].setPosition(this.caodi.convertToNodeSpaceAR(cc.v2(960, 506.4 - random * 100)));
    this.node.getComponent('zou').normalCell[this.node.getComponent('zou').num].runAction(cc.moveTo(40, this.caodi.convertToNodeSpaceAR(cc.v2(0, 506.4 - random * 100))));
    this.node.getComponent('zou').num++;
  },
  start: function start() {},
  checkDead: function checkDead() {
    for (var i = 0; i < this.num; i++) {
      if (this.HP[i] <= 0) {
        this.jiangshi[i].active = false;
      }
    }
  },
  checkDestroyAll: function checkDestroyAll() {
    if (this.num === 8 && this.node.parent.parent.parent.name === 'Level01') {
      for (var i = 0; i < this.num; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      this.hasDestroyedAll = true;
    }

    if (this.num === 19 && this.node.parent.parent.parent.name === 'Level02') {
      for (var i = 0; i < this.num; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      this.hasDestroyedAll = true;
    }

    if (this.num === 31 && this.node.parent.parent.parent.name === 'Level03') {
      for (var i = 0; i < this.num; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      this.hasDestroyedAll = true;
    }
  },
  checkLaunchLastWave: function checkLaunchLastWave() {
    if (this.hasDestroyedAll === true && this.lastWave === false && this.node.getComponent('piao').hasDestroyedAll === true && this.node.parent.parent.parent.name === 'Level01') {
      this.lastWave = true;
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 6);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 9);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 8);
    }

    if (this.hasDestroyedAll === true && this.lastWave === false && this.node.getComponent('piao').hasDestroyedAll === true && this.node.parent.parent.parent.name === 'Level02') {
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 9);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 13);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 17);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 6);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 9);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 12);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 15);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 18);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 8);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 13);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 14);
    }

    if (this.hasDestroyedAll === true && this.lastWave === false && this.node.getComponent('piao').hasDestroyedAll === true && this.node.parent.parent.parent.name === 'Level03') {
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 4);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 5);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 7);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 10);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 15);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 18);
      this.scheduleOnce(function () {
        this.add(this.num);
      }.bind(this), 20);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 2);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 8);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 12);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 17);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 18);
      this.scheduleOnce(function () {
        this.addInfectedCell();
      }.bind(this), 21);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 3);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 11);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 16);
      this.scheduleOnce(function () {
        this.addNormalCell();
      }.bind(this), 19);
    }
  },
  checkFailure: function checkFailure() {
    for (var i = 0; i < this.num; i++) {
      if (this.jiangshi[i].x < 0.1 - 480) {
        this.caodi.getComponent('gameControl').gameStatus = 'fail';
      }
    }
  },
  checkSuccess: function checkSuccess() {
    /*
    var flag = true;
    if(this.node.parent.parent.parent.name === 'Level01' && this.num === 13 &&
    this.node.getComponent('piao').num === 12) {
        for(var i = 0; i < this.num; i++) {
            if(this.jiangshi[i].active === true) {
                flag = false;
            }
        }
        for(var i = 0; i < this.node.getComponent('piao').num; i++) {
            if(this.node.getComponent('piao').infectedCell[i].active === true) {
                flag = false;
            }
        }
    } else if(this.node.parent.parent.parent.name === 'Level02' && this.num === 25 &&
    this.node.getComponent('piao').num === 26) {
        for(var i = 0; i < this.num; i++) {
            if(this.jiangshi[i].active === true) {
                flag = false;
            }
        }
        for(var i = 0; i < this.node.getComponent('piao').num; i++) {
            if(this.node.getComponent('piao').infectedCell[i].active === true) {
                flag = false;
            }
        }
    } else if(this.node.parent.parent.parent.name === 'Level03' && this.num === 39 &&
    this.node.getComponent('piao').num === 41) {
        for(var i = 0; i < this.num; i++) {
            if(this.jiangshi[i].active === true) {
                flag = false;
            }
        }
        for(var i = 0; i < this.node.getComponent('piao').num; i++) {
            if(this.node.getComponent('piao').infectedCell[i].active === true) {
                flag = false;
            }
        }
    }
    if(this.lastWave === false) {
        flag = false;
    }
    if(this.node.parent.parent.parent.name === 'Level01' && (this.num < 13 ||
    this.node.getComponent('piao').num < 12)) {
        flag = false;
    } else if(this.node.parent.parent.parent.name === 'Level02' && (this.num < 25 ||
    this.node.getComponent('piao').num < 26)) {
        flag = false;
    } else if(this.node.parent.parent.parent.name === 'Level03' && this.num < 39 ||
    this.node.getComponent('piao').num < 41) {
        flag = false;
    }
    if(flag === true) {
        this.caodi.getComponent('gameControl').gameStatus = 'succeed';
    }
    */
    if (this.lastWave === false) {
      return;
    }

    if (this.node.parent.parent.parent.name === 'Level01') {
      if (this.num !== 13 || this.node.getComponent('piao').num !== 12) {
        return;
      }

      for (var i = 0; i < 13; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      for (var i = 0; i < 12; i++) {
        if (this.node.getComponent('piao').infectedCell[i].active === true) {
          return;
        }
      }

      this.caodi.getComponent('gameControl').gameStatus = 'succeed';
    }

    if (this.node.parent.parent.parent.name === 'Level02') {
      if (this.num !== 25 || this.node.getComponent('piao').num !== 26) {
        return;
      }

      for (var i = 0; i < 25; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      for (var i = 0; i < 26; i++) {
        if (this.node.getComponent('piao').infectedCell[i].active === true) {
          return;
        }
      }

      this.caodi.getComponent('gameControl').gameStatus = 'succeed';
    }

    if (this.node.parent.parent.parent.name === 'Level03') {
      if (this.num !== 39 || this.node.getComponent('piao').num !== 41) {
        return;
      }

      for (var i = 0; i < 39; i++) {
        if (this.jiangshi[i].active === true) {
          return;
        }
      }

      for (var i = 0; i < 41; i++) {
        if (this.node.getComponent('piao').infectedCell[i].active === true) {
          return;
        }
      }

      this.caodi.getComponent('gameControl').gameStatus = 'succeed';
    }
  },
  update: function update(dt) {
    this.checkDead();
    this.checkDestroyAll();
    this.checkLaunchLastWave();
    this.checkFailure();
    this.checkSuccess(); //cc.log(this.num, this.node.getComponent('piao').num, this.node.getComponent('piao').hasDestroyedAll);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxqaW5nb25nLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiamlhbmdzaGkiLCJOb2RlIiwiY2FvZGkiLCJzcCIsInR5cGUiLCJTcHJpdGVGcmFtZSIsIkhQIiwibnVtIiwiZHVyYXRpb24iLCJoYXNEZXN0cm95ZWRBbGwiLCJsYXN0V2F2ZSIsIm9uTG9hZCIsIm5vZGUiLCJwYXJlbnQiLCJuYW1lIiwic2NoZWR1bGVPbmNlIiwiYWRkIiwiYmluZCIsImkiLCJzIiwicmFuZG9tIiwiTWF0aCIsImZsb29yIiwiYWRkQ29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJzZXRQb3NpdGlvbiIsImNvbnZlcnRUb05vZGVTcGFjZUFSIiwidjIiLCJydW5BY3Rpb24iLCJtb3ZlVG8iLCJhZGRJbmZlY3RlZENlbGwiLCJnZXRDb21wb25lbnQiLCJpbmZlY3RlZENlbGwiLCJhZGROb3JtYWxDZWxsIiwibm9ybWFsQ2VsbCIsInN0YXJ0IiwiY2hlY2tEZWFkIiwiYWN0aXZlIiwiY2hlY2tEZXN0cm95QWxsIiwiY2hlY2tMYXVuY2hMYXN0V2F2ZSIsImNoZWNrRmFpbHVyZSIsIngiLCJnYW1lU3RhdHVzIiwiY2hlY2tTdWNjZXNzIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxRQUFRLEVBQUUsQ0FBQ0osRUFBRSxDQUFDSyxJQUFKLENBREQ7QUFFVEMsSUFBQUEsS0FBSyxFQUFFTixFQUFFLENBQUNLLElBRkQ7QUFHVEUsSUFBQUEsRUFBRSxFQUFFO0FBQ0EsaUJBQVMsSUFEVDtBQUVBQyxNQUFBQSxJQUFJLEVBQUVSLEVBQUUsQ0FBQ1M7QUFGVCxLQUhLO0FBT1RDLElBQUFBLEVBQUUsRUFBRSxFQVBLO0FBUVRDLElBQUFBLEdBQUcsRUFBRSxDQVJJO0FBU1RDLElBQUFBLFFBQVEsRUFBRSxFQVREO0FBVVRDLElBQUFBLGVBQWUsRUFBRSxLQVZSO0FBV1RDLElBQUFBLFFBQVEsRUFBRTtBQVhELEdBSFA7QUFpQkw7QUFFQUMsRUFBQUEsTUFuQkssb0JBbUJLO0FBRU4sUUFBRyxLQUFLQyxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FBM0MsRUFBc0Q7QUFDbEQsV0FBS0MsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBSUEsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFGeEI7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUZ4QjtBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBRnhCO0FBSUEsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHSDs7QUFFRCxRQUFHLEtBQUtJLElBQUwsQ0FBVUMsTUFBVixDQUFpQkEsTUFBakIsQ0FBd0JBLE1BQXhCLENBQStCQyxJQUEvQixLQUF3QyxTQUEzQyxFQUFzRDtBQUNsRCxXQUFLQyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFJQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUZ4QjtBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBRnhCO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFGeEI7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUZ4QjtBQUlBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBSUEsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBSUEsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUlIOztBQUVELFFBQUcsS0FBS0ksSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkEsTUFBeEIsQ0FBK0JDLElBQS9CLEtBQXdDLFNBQTNDLEVBQXNEO0FBQ2xELFdBQUtDLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUlBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBRnhCO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFGeEI7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUZ4QjtBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBRnhCO0FBSUEsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFJQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFJQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBSUEsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFJQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFJQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0EsV0FBS08sWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEtBQUssS0FBS1QsUUFBTCxHQUFnQixDQUZuQztBQUdBLFdBQUtPLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxLQUFLLEtBQUtULFFBQUwsR0FBZ0IsQ0FGbkM7QUFHQSxXQUFLTyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsS0FBSyxLQUFLVCxRQUFMLEdBQWdCLENBRm5DO0FBR0g7QUFFSixHQTFOSTtBQTROTFEsRUFBQUEsR0FBRyxFQUFFLGFBQVNFLENBQVQsRUFBWTtBQUNiLFFBQUlDLENBQUo7QUFDQSxRQUFJQyxNQUFKO0FBQ0FBLElBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0QsTUFBTCxLQUFnQixDQUEzQixDQUFUO0FBQ0EsU0FBS2IsR0FBTDtBQUNBLFNBQUtQLFFBQUwsQ0FBY2tCLENBQWQsSUFBbUIsSUFBSXRCLEVBQUUsQ0FBQ0ssSUFBUCxFQUFuQjtBQUNBLFNBQUtLLEVBQUwsQ0FBUVksQ0FBUixJQUFhLENBQWI7QUFDQUMsSUFBQUEsQ0FBQyxHQUFHLEtBQUtuQixRQUFMLENBQWNrQixDQUFkLEVBQWlCSyxZQUFqQixDQUE4QjNCLEVBQUUsQ0FBQzRCLE1BQWpDLENBQUo7QUFDQUwsSUFBQUEsQ0FBQyxDQUFDTSxXQUFGLEdBQWdCLEtBQUt0QixFQUFyQjtBQUNBLFNBQUtILFFBQUwsQ0FBY2tCLENBQWQsRUFBaUJMLE1BQWpCLEdBQTBCLEtBQUtYLEtBQS9CO0FBQ0EsU0FBS0YsUUFBTCxDQUFja0IsQ0FBZCxFQUFpQlEsV0FBakIsQ0FBNkIsS0FBS3hCLEtBQUwsQ0FBV3lCLG9CQUFYLENBQWdDL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVyxRQUFRUixNQUFNLEdBQUcsR0FBNUIsQ0FBaEMsQ0FBN0I7QUFDQSxTQUFLcEIsUUFBTCxDQUFja0IsQ0FBZCxFQUFpQlcsU0FBakIsQ0FBMkJqQyxFQUFFLENBQUNrQyxNQUFILENBQVUsRUFBVixFQUFjLEtBQUs1QixLQUFMLENBQVd5QixvQkFBWCxDQUFnQy9CLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsUUFBUVIsTUFBTSxHQUFHLEdBQTFCLENBQWhDLENBQWQsQ0FBM0I7QUFDSCxHQXhPSTtBQTBPTFcsRUFBQUEsZUFBZSxFQUFFLDJCQUFXO0FBQ3hCLFFBQUlaLENBQUo7QUFDQSxRQUFJQyxNQUFKO0FBQ0FBLElBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0QsTUFBTCxLQUFnQixDQUEzQixDQUFUO0FBQ0EsU0FBS1IsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixNQUF2QixFQUErQkMsWUFBL0IsQ0FBNEMsS0FBS3JCLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0J6QixHQUEzRSxJQUFrRixJQUFJWCxFQUFFLENBQUNLLElBQVAsRUFBbEY7QUFDQSxTQUFLVyxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCMUIsRUFBL0IsQ0FBa0MsS0FBS00sSUFBTCxDQUFVb0IsWUFBVixDQUF1QixNQUF2QixFQUErQnpCLEdBQWpFLElBQXdFLEVBQXhFO0FBQ0FZLElBQUFBLENBQUMsR0FBRyxLQUFLUCxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCQyxZQUEvQixDQUE0QyxLQUFLckIsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixNQUF2QixFQUErQnpCLEdBQTNFLEVBQWdGZ0IsWUFBaEYsQ0FBNkYzQixFQUFFLENBQUM0QixNQUFoRyxDQUFKO0FBQ0FMLElBQUFBLENBQUMsQ0FBQ00sV0FBRixHQUFnQixLQUFLYixJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCN0IsRUFBL0M7QUFDQSxTQUFLUyxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCQyxZQUEvQixDQUE0QyxLQUFLckIsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixNQUF2QixFQUErQnpCLEdBQTNFLEVBQWdGTSxNQUFoRixHQUF5RixLQUFLWCxLQUE5RjtBQUNBLFNBQUtVLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0JDLFlBQS9CLENBQTRDLEtBQUtyQixJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCekIsR0FBM0UsRUFBZ0ZtQixXQUFoRixDQUE0RixLQUFLeEIsS0FBTCxDQUFXeUIsb0JBQVgsQ0FBZ0MvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFXLFFBQVFSLE1BQU0sR0FBRyxHQUE1QixDQUFoQyxDQUE1RjtBQUNBLFNBQUtSLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0JDLFlBQS9CLENBQTRDLEtBQUtyQixJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCekIsR0FBM0UsRUFBZ0ZzQixTQUFoRixDQUEwRmpDLEVBQUUsQ0FBQ2tDLE1BQUgsQ0FBVSxFQUFWLEVBQWMsS0FBSzVCLEtBQUwsQ0FBV3lCLG9CQUFYLENBQWdDL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLENBQU4sRUFBUyxRQUFRUixNQUFNLEdBQUcsR0FBMUIsQ0FBaEMsQ0FBZCxDQUExRjtBQUNBLFNBQUtSLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0J6QixHQUEvQjtBQUNILEdBdFBJO0FBd1BMMkIsRUFBQUEsYUFBYSxFQUFFLHlCQUFXO0FBQ3RCLFFBQUlmLENBQUo7QUFDQSxRQUFJQyxNQUFKO0FBQ0FBLElBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0QsTUFBTCxLQUFnQixDQUEzQixDQUFUO0FBQ0EsU0FBS1IsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixLQUF2QixFQUE4QkcsVUFBOUIsQ0FBeUMsS0FBS3ZCLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsS0FBdkIsRUFBOEJ6QixHQUF2RSxJQUE4RSxJQUFJWCxFQUFFLENBQUNLLElBQVAsRUFBOUU7QUFDQSxTQUFLVyxJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCMUIsRUFBOUIsQ0FBaUMsS0FBS00sSUFBTCxDQUFVb0IsWUFBVixDQUF1QixLQUF2QixFQUE4QnpCLEdBQS9ELElBQXNFLEVBQXRFO0FBQ0FZLElBQUFBLENBQUMsR0FBRyxLQUFLUCxJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCRyxVQUE5QixDQUF5QyxLQUFLdkIsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixLQUF2QixFQUE4QnpCLEdBQXZFLEVBQTRFZ0IsWUFBNUUsQ0FBeUYzQixFQUFFLENBQUM0QixNQUE1RixDQUFKO0FBQ0FMLElBQUFBLENBQUMsQ0FBQ00sV0FBRixHQUFnQixLQUFLYixJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCN0IsRUFBOUM7QUFDQSxTQUFLUyxJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCRyxVQUE5QixDQUF5QyxLQUFLdkIsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixLQUF2QixFQUE4QnpCLEdBQXZFLEVBQTRFTSxNQUE1RSxHQUFxRixLQUFLWCxLQUExRjtBQUNBLFNBQUtVLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsS0FBdkIsRUFBOEJHLFVBQTlCLENBQXlDLEtBQUt2QixJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCekIsR0FBdkUsRUFBNEVtQixXQUE1RSxDQUF3RixLQUFLeEIsS0FBTCxDQUFXeUIsb0JBQVgsQ0FBZ0MvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFXLFFBQVFSLE1BQU0sR0FBRyxHQUE1QixDQUFoQyxDQUF4RjtBQUNBLFNBQUtSLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsS0FBdkIsRUFBOEJHLFVBQTlCLENBQXlDLEtBQUt2QixJQUFMLENBQVVvQixZQUFWLENBQXVCLEtBQXZCLEVBQThCekIsR0FBdkUsRUFBNEVzQixTQUE1RSxDQUFzRmpDLEVBQUUsQ0FBQ2tDLE1BQUgsQ0FBVSxFQUFWLEVBQWMsS0FBSzVCLEtBQUwsQ0FBV3lCLG9CQUFYLENBQWdDL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLENBQU4sRUFBUyxRQUFRUixNQUFNLEdBQUcsR0FBMUIsQ0FBaEMsQ0FBZCxDQUF0RjtBQUNBLFNBQUtSLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsS0FBdkIsRUFBOEJ6QixHQUE5QjtBQUNILEdBcFFJO0FBc1FMNkIsRUFBQUEsS0F0UUssbUJBc1FJLENBRVIsQ0F4UUk7QUEwUUxDLEVBQUFBLFNBQVMsRUFBRSxxQkFBVztBQUNsQixTQUFJLElBQUluQixDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsS0FBS1gsR0FBeEIsRUFBNkJXLENBQUMsRUFBOUIsRUFBa0M7QUFDOUIsVUFBRyxLQUFLWixFQUFMLENBQVFZLENBQVIsS0FBYyxDQUFqQixFQUFvQjtBQUNoQixhQUFLbEIsUUFBTCxDQUFja0IsQ0FBZCxFQUFpQm9CLE1BQWpCLEdBQTBCLEtBQTFCO0FBQ0g7QUFDSjtBQUNKLEdBaFJJO0FBa1JMQyxFQUFBQSxlQUFlLEVBQUUsMkJBQVc7QUFDeEIsUUFBRyxLQUFLaEMsR0FBTCxLQUFhLENBQWIsSUFBa0IsS0FBS0ssSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkEsTUFBeEIsQ0FBK0JDLElBQS9CLEtBQXdDLFNBQTdELEVBQXdFO0FBQ3BFLFdBQUksSUFBSUksQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtYLEdBQXhCLEVBQTZCVyxDQUFDLEVBQTlCLEVBQWtDO0FBQzlCLFlBQUcsS0FBS2xCLFFBQUwsQ0FBY2tCLENBQWQsRUFBaUJvQixNQUFqQixLQUE0QixJQUEvQixFQUFxQztBQUNqQztBQUNIO0FBQ0o7O0FBQ0QsV0FBSzdCLGVBQUwsR0FBdUIsSUFBdkI7QUFDSDs7QUFFRCxRQUFHLEtBQUtGLEdBQUwsS0FBYSxFQUFiLElBQW1CLEtBQUtLLElBQUwsQ0FBVUMsTUFBVixDQUFpQkEsTUFBakIsQ0FBd0JBLE1BQXhCLENBQStCQyxJQUEvQixLQUF3QyxTQUE5RCxFQUF5RTtBQUNyRSxXQUFJLElBQUlJLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxLQUFLWCxHQUF4QixFQUE2QlcsQ0FBQyxFQUE5QixFQUFrQztBQUM5QixZQUFHLEtBQUtsQixRQUFMLENBQWNrQixDQUFkLEVBQWlCb0IsTUFBakIsS0FBNEIsSUFBL0IsRUFBcUM7QUFDakM7QUFDSDtBQUNKOztBQUNELFdBQUs3QixlQUFMLEdBQXVCLElBQXZCO0FBQ0g7O0FBRUQsUUFBRyxLQUFLRixHQUFMLEtBQWEsRUFBYixJQUFtQixLQUFLSyxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FBOUQsRUFBeUU7QUFDckUsV0FBSSxJQUFJSSxDQUFDLEdBQUcsQ0FBWixFQUFlQSxDQUFDLEdBQUcsS0FBS1gsR0FBeEIsRUFBNkJXLENBQUMsRUFBOUIsRUFBa0M7QUFDOUIsWUFBRyxLQUFLbEIsUUFBTCxDQUFja0IsQ0FBZCxFQUFpQm9CLE1BQWpCLEtBQTRCLElBQS9CLEVBQXFDO0FBQ2pDO0FBQ0g7QUFDSjs7QUFDRCxXQUFLN0IsZUFBTCxHQUF1QixJQUF2QjtBQUNIO0FBQ0osR0E3U0k7QUErU0wrQixFQUFBQSxtQkFBbUIsRUFBRSwrQkFBVztBQUM1QixRQUFHLEtBQUsvQixlQUFMLEtBQXlCLElBQXpCLElBQWlDLEtBQUtDLFFBQUwsS0FBa0IsS0FBbkQsSUFDSCxLQUFLRSxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCdkIsZUFBL0IsS0FBbUQsSUFEaEQsSUFFSCxLQUFLRyxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FGeEMsRUFFbUQ7QUFDL0MsV0FBS0osUUFBTCxHQUFnQixJQUFoQjtBQUVBLFdBQUtLLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFJQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUlBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdIOztBQUVELFFBQUcsS0FBS1IsZUFBTCxLQUF5QixJQUF6QixJQUFpQyxLQUFLQyxRQUFMLEtBQWtCLEtBQW5ELElBQ0MsS0FBS0UsSUFBTCxDQUFVb0IsWUFBVixDQUF1QixNQUF2QixFQUErQnZCLGVBQS9CLEtBQW1ELElBRHBELElBRUMsS0FBS0csSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkEsTUFBeEIsQ0FBK0JDLElBQS9CLEtBQXdDLFNBRjVDLEVBRXVEO0FBQy9DLFdBQUtDLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUlBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFJQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS21CLGFBQUw7QUFDSCxPQUZpQixDQUVoQmpCLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVhLENBRmI7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS21CLGFBQUw7QUFDSCxPQUZpQixDQUVoQmpCLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS21CLGFBQUw7QUFDSCxPQUZpQixDQUVoQmpCLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS21CLGFBQUw7QUFDSCxPQUZpQixDQUVoQmpCLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFJSDs7QUFFRCxRQUFHLEtBQUtSLGVBQUwsS0FBeUIsSUFBekIsSUFBaUMsS0FBS0MsUUFBTCxLQUFrQixLQUFuRCxJQUNILEtBQUtFLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0J2QixlQUEvQixLQUFtRCxJQURoRCxJQUVILEtBQUtHLElBQUwsQ0FBVUMsTUFBVixDQUFpQkEsTUFBakIsQ0FBd0JBLE1BQXhCLENBQStCQyxJQUEvQixLQUF3QyxTQUZ4QyxFQUVtRDtBQUMvQyxXQUFLQyxZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtDLEdBQUwsQ0FBUyxLQUFLVCxHQUFkO0FBQ0gsT0FGaUIsQ0FFaEJVLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVhLEVBRmI7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS0MsR0FBTCxDQUFTLEtBQUtULEdBQWQ7QUFDSCxPQUZpQixDQUVoQlUsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLQyxHQUFMLENBQVMsS0FBS1QsR0FBZDtBQUNILE9BRmlCLENBRWhCVSxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBSUEsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLENBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxDQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLZ0IsZUFBTDtBQUNILE9BRmlCLENBRWhCZCxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYyxFQUZkO0FBR0EsV0FBS0YsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLGFBQUtnQixlQUFMO0FBQ0gsT0FGaUIsQ0FFaEJkLElBRmdCLENBRVgsSUFGVyxDQUFsQixFQUVjLEVBRmQ7QUFHQSxXQUFLRixZQUFMLENBQWtCLFlBQVc7QUFDekIsYUFBS2dCLGVBQUw7QUFDSCxPQUZpQixDQUVoQmQsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUlBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsQ0FGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdBLFdBQUtGLFlBQUwsQ0FBa0IsWUFBVztBQUN6QixhQUFLbUIsYUFBTDtBQUNILE9BRmlCLENBRWhCakIsSUFGZ0IsQ0FFWCxJQUZXLENBQWxCLEVBRWMsRUFGZDtBQUdIO0FBQ1IsR0ExZEk7QUE0ZEx3QixFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDckIsU0FBSSxJQUFJdkIsQ0FBQyxHQUFHLENBQVosRUFBZUEsQ0FBQyxHQUFHLEtBQUtYLEdBQXhCLEVBQTZCVyxDQUFDLEVBQTlCLEVBQWtDO0FBQzlCLFVBQUcsS0FBS2xCLFFBQUwsQ0FBY2tCLENBQWQsRUFBaUJ3QixDQUFqQixHQUFxQixNQUFNLEdBQTlCLEVBQW1DO0FBQy9CLGFBQUt4QyxLQUFMLENBQVc4QixZQUFYLENBQXdCLGFBQXhCLEVBQXVDVyxVQUF2QyxHQUFvRCxNQUFwRDtBQUNIO0FBQ0o7QUFDSixHQWxlSTtBQW9lTEMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3JCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXdERCxRQUFHLEtBQUtsQyxRQUFMLEtBQWtCLEtBQXJCLEVBQTRCO0FBQ3hCO0FBQ0g7O0FBQ0QsUUFBRyxLQUFLRSxJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FBM0MsRUFBc0Q7QUFDbEQsVUFBRyxLQUFLUCxHQUFMLEtBQWEsRUFBYixJQUFtQixLQUFLSyxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCekIsR0FBL0IsS0FBdUMsRUFBN0QsRUFBaUU7QUFDN0Q7QUFDSDs7QUFDRCxXQUFJLElBQUlXLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixZQUFHLEtBQUtsQixRQUFMLENBQWNrQixDQUFkLEVBQWlCb0IsTUFBakIsS0FBNEIsSUFBL0IsRUFBcUM7QUFDakM7QUFDSDtBQUNKOztBQUNELFdBQUksSUFBSXBCLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixZQUFHLEtBQUtOLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0JDLFlBQS9CLENBQTRDZixDQUE1QyxFQUErQ29CLE1BQS9DLEtBQTBELElBQTdELEVBQW1FO0FBQy9EO0FBQ0g7QUFDSjs7QUFDRCxXQUFLcEMsS0FBTCxDQUFXOEIsWUFBWCxDQUF3QixhQUF4QixFQUF1Q1csVUFBdkMsR0FBb0QsU0FBcEQ7QUFDSDs7QUFDQSxRQUFHLEtBQUsvQixJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FBM0MsRUFBc0Q7QUFDbkQsVUFBRyxLQUFLUCxHQUFMLEtBQWEsRUFBYixJQUFtQixLQUFLSyxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCekIsR0FBL0IsS0FBdUMsRUFBN0QsRUFBaUU7QUFDekQ7QUFDUDs7QUFDRCxXQUFJLElBQUlXLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixZQUFHLEtBQUtsQixRQUFMLENBQWNrQixDQUFkLEVBQWlCb0IsTUFBakIsS0FBNEIsSUFBL0IsRUFBcUM7QUFDakM7QUFDRjtBQUNKOztBQUNGLFdBQUksSUFBSXBCLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN6QixZQUFHLEtBQUtOLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0JDLFlBQS9CLENBQTRDZixDQUE1QyxFQUErQ29CLE1BQS9DLEtBQTBELElBQTdELEVBQW1FO0FBQzlEO0FBQ0Y7QUFDSjs7QUFDRCxXQUFLcEMsS0FBTCxDQUFXOEIsWUFBWCxDQUF3QixhQUF4QixFQUF1Q1csVUFBdkMsR0FBb0QsU0FBcEQ7QUFDSDs7QUFDRCxRQUFHLEtBQUsvQixJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCQSxNQUF4QixDQUErQkMsSUFBL0IsS0FBd0MsU0FBM0MsRUFBc0Q7QUFDbEQsVUFBRyxLQUFLUCxHQUFMLEtBQWEsRUFBYixJQUFtQixLQUFLSyxJQUFMLENBQVVvQixZQUFWLENBQXVCLE1BQXZCLEVBQStCekIsR0FBL0IsS0FBdUMsRUFBN0QsRUFBaUU7QUFDakU7QUFDSDs7QUFDRCxXQUFJLElBQUlXLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixZQUFHLEtBQUtsQixRQUFMLENBQWNrQixDQUFkLEVBQWlCb0IsTUFBakIsS0FBNEIsSUFBL0IsRUFBcUM7QUFDakM7QUFDSDtBQUNKOztBQUNELFdBQUksSUFBSXBCLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBRyxFQUFuQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixZQUFHLEtBQUtOLElBQUwsQ0FBVW9CLFlBQVYsQ0FBdUIsTUFBdkIsRUFBK0JDLFlBQS9CLENBQTRDZixDQUE1QyxFQUErQ29CLE1BQS9DLEtBQTBELElBQTdELEVBQW1FO0FBQy9EO0FBQ0g7QUFDSjs7QUFDRCxXQUFLcEMsS0FBTCxDQUFXOEIsWUFBWCxDQUF3QixhQUF4QixFQUF1Q1csVUFBdkMsR0FBb0QsU0FBcEQ7QUFDQztBQUNKLEdBaGxCSTtBQWtsQkxFLEVBQUFBLE1BbGxCSyxrQkFrbEJHQyxFQWxsQkgsRUFrbEJPO0FBQ1IsU0FBS1QsU0FBTDtBQUNBLFNBQUtFLGVBQUw7QUFDQSxTQUFLQyxtQkFBTDtBQUNBLFNBQUtDLFlBQUw7QUFDQSxTQUFLRyxZQUFMLEdBTFEsQ0FNUjtBQUNIO0FBemxCSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICBqaWFuZ3NoaTogW2NjLk5vZGVdLFxyXG4gICAgICAgY2FvZGk6IGNjLk5vZGUsXHJcbiAgICAgICBzcDoge1xyXG4gICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICB9LFxyXG4gICAgICAgSFA6IFtdLFxyXG4gICAgICAgbnVtOiAwLFxyXG4gICAgICAgZHVyYXRpb246IDMwLFxyXG4gICAgICAgaGFzRGVzdHJveWVkQWxsOiBmYWxzZSxcclxuICAgICAgIGxhc3RXYXZlOiBmYWxzZSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAxJykge1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxMCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjApO1xyXG4gICAgXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDEwICsgdGhpcy5kdXJhdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2ICsgdGhpcy5kdXJhdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDIwICsgdGhpcy5kdXJhdGlvbik7XHJcbiAgICBcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTggKyB0aGlzLmR1cmF0aW9uICogMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDIwICsgdGhpcy5kdXJhdGlvbiAqIDIpOyAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAyJykge1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxMCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjApO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTAgKyB0aGlzLmR1cmF0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTYgKyB0aGlzLmR1cmF0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjAgKyB0aGlzLmR1cmF0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjQgKyB0aGlzLmR1cmF0aW9uKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2ICsgdGhpcy5kdXJhdGlvbiAqIDIpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyMCArIHRoaXMuZHVyYXRpb24gKiAyKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjYgKyB0aGlzLmR1cmF0aW9uICogMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDMwICsgdGhpcy5kdXJhdGlvbiAqIDIpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAzNSArIHRoaXMuZHVyYXRpb24gKiAyKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDIwICsgdGhpcy5kdXJhdGlvbiAqIDMpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyNiArIHRoaXMuZHVyYXRpb24gKiAzKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMzAgKyB0aGlzLmR1cmF0aW9uICogMyk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyNCArIHRoaXMuZHVyYXRpb24gKiA0KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjggKyB0aGlzLmR1cmF0aW9uICogNCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDM0ICsgdGhpcy5kdXJhdGlvbiAqIDQpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCA0MCArIHRoaXMuZHVyYXRpb24gKiA0KTtcclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDMnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDEwKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTYpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyMCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxMCArIHRoaXMuZHVyYXRpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxNCArIHRoaXMuZHVyYXRpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxNiArIHRoaXMuZHVyYXRpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyMCArIHRoaXMuZHVyYXRpb24pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTYgKyB0aGlzLmR1cmF0aW9uICogMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDE4ICsgdGhpcy5kdXJhdGlvbiAqIDIpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyMiArIHRoaXMuZHVyYXRpb24gKiAyKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjYgKyB0aGlzLmR1cmF0aW9uICogMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDMwICsgdGhpcy5kdXJhdGlvbiAqIDIpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTggKyB0aGlzLmR1cmF0aW9uICogMyk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDI0ICsgdGhpcy5kdXJhdGlvbiAqIDMpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyNiArIHRoaXMuZHVyYXRpb24gKiAzKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDIyICsgdGhpcy5kdXJhdGlvbiAqIDQpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAyNCArIHRoaXMuZHVyYXRpb24gKiA0KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMzAgKyB0aGlzLmR1cmF0aW9uICogNCk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDM0ICsgdGhpcy5kdXJhdGlvbiAqIDQpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMjYgKyB0aGlzLmR1cmF0aW9uICogNSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDMwICsgdGhpcy5kdXJhdGlvbiAqIDUpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAzNSArIHRoaXMuZHVyYXRpb24gKiA1KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNDAgKyB0aGlzLmR1cmF0aW9uICogNSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDQyICsgdGhpcy5kdXJhdGlvbiAqIDUpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMzAgKyB0aGlzLmR1cmF0aW9uICogNik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDM0ICsgdGhpcy5kdXJhdGlvbiAqIDYpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAzOSArIHRoaXMuZHVyYXRpb24gKiA2KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDMyICsgdGhpcy5kdXJhdGlvbiAqIDcpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAzNiArIHRoaXMuZHVyYXRpb24gKiA3KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNDAgKyB0aGlzLmR1cmF0aW9uICogNyk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDQ4ICsgdGhpcy5kdXJhdGlvbiAqIDcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGFkZDogZnVuY3Rpb24oaSkge1xyXG4gICAgICAgIHZhciBzO1xyXG4gICAgICAgIHZhciByYW5kb207XHJcbiAgICAgICAgcmFuZG9tID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNSk7XHJcbiAgICAgICAgdGhpcy5udW0rKztcclxuICAgICAgICB0aGlzLmppYW5nc2hpW2ldID0gbmV3IGNjLk5vZGUoKTtcclxuICAgICAgICB0aGlzLkhQW2ldID0gNTtcclxuICAgICAgICBzID0gdGhpcy5qaWFuZ3NoaVtpXS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzLnNwcml0ZUZyYW1lID0gdGhpcy5zcDtcclxuICAgICAgICB0aGlzLmppYW5nc2hpW2ldLnBhcmVudCA9IHRoaXMuY2FvZGk7XHJcbiAgICAgICAgdGhpcy5qaWFuZ3NoaVtpXS5zZXRQb3NpdGlvbih0aGlzLmNhb2RpLmNvbnZlcnRUb05vZGVTcGFjZUFSKGNjLnYyKDk2MCwgNTA2LjQgLSByYW5kb20gKiAxMDApKSk7XHJcbiAgICAgICAgdGhpcy5qaWFuZ3NoaVtpXS5ydW5BY3Rpb24oY2MubW92ZVRvKDQwLCB0aGlzLmNhb2RpLmNvbnZlcnRUb05vZGVTcGFjZUFSKGNjLnYyKDAsIDUwNi40IC0gcmFuZG9tICogMTAwKSkpKTtcclxuICAgIH0sXHJcblxyXG4gICAgYWRkSW5mZWN0ZWRDZWxsOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgcztcclxuICAgICAgICB2YXIgcmFuZG9tO1xyXG4gICAgICAgIHJhbmRvbSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDUpO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bV0gPSBuZXcgY2MuTm9kZSgpO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5IUFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtXSA9IDEwO1xyXG4gICAgICAgIHMgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuaW5mZWN0ZWRDZWxsW3RoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW1dLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xyXG4gICAgICAgIHMuc3ByaXRlRnJhbWUgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuc3A7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtXS5wYXJlbnQgPSB0aGlzLmNhb2RpO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bV0uc2V0UG9zaXRpb24odGhpcy5jYW9kaS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihjYy52Mig5NjAsIDUwNi40IC0gcmFuZG9tICogMTAwKSkpO1xyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5pbmZlY3RlZENlbGxbdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bV0ucnVuQWN0aW9uKGNjLm1vdmVUbyg0MCwgdGhpcy5jYW9kaS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihjYy52MigwLCA1MDYuNCAtIHJhbmRvbSAqIDEwMCkpKSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bSsrOyAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIGFkZE5vcm1hbENlbGw6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzO1xyXG4gICAgICAgIHZhciByYW5kb207XHJcbiAgICAgICAgcmFuZG9tID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91Jykubm9ybWFsQ2VsbFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5udW1dID0gbmV3IGNjLk5vZGUoKTtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5IUFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5udW1dID0gMTA7XHJcbiAgICAgICAgcyA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3pvdScpLm5vcm1hbENlbGxbdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91JykubnVtXS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzLnNwcml0ZUZyYW1lID0gdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91Jykuc3A7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91Jykubm9ybWFsQ2VsbFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5udW1dLnBhcmVudCA9IHRoaXMuY2FvZGk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91Jykubm9ybWFsQ2VsbFt0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5udW1dLnNldFBvc2l0aW9uKHRoaXMuY2FvZGkuY29udmVydFRvTm9kZVNwYWNlQVIoY2MudjIoOTYwLCA1MDYuNCAtIHJhbmRvbSAqIDEwMCkpKTtcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCd6b3UnKS5ub3JtYWxDZWxsW3RoaXMubm9kZS5nZXRDb21wb25lbnQoJ3pvdScpLm51bV0ucnVuQWN0aW9uKGNjLm1vdmVUbyg0MCwgdGhpcy5jYW9kaS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihjYy52MigwLCA1MDYuNCAtIHJhbmRvbSAqIDEwMCkpKSk7XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgnem91JykubnVtKys7ICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgY2hlY2tEZWFkOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICBpZih0aGlzLkhQW2ldIDw9IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuamlhbmdzaGlbaV0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGNoZWNrRGVzdHJveUFsbDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgaWYodGhpcy5udW0gPT09IDggJiYgdGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAxJykge1xyXG4gICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5oYXNEZXN0cm95ZWRBbGwgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYodGhpcy5udW0gPT09IDE5ICYmIHRoaXMubm9kZS5wYXJlbnQucGFyZW50LnBhcmVudC5uYW1lID09PSAnTGV2ZWwwMicpIHtcclxuICAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHRoaXMubnVtOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmKHRoaXMuamlhbmdzaGlbaV0uYWN0aXZlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuaGFzRGVzdHJveWVkQWxsID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmKHRoaXMubnVtID09PSAzMSAmJiB0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDMnKSB7XHJcbiAgICAgICAgICAgIGZvcih2YXIgaSA9IDA7IGkgPCB0aGlzLm51bTsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmppYW5nc2hpW2ldLmFjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmhhc0Rlc3Ryb3llZEFsbCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBjaGVja0xhdW5jaExhc3RXYXZlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBpZih0aGlzLmhhc0Rlc3Ryb3llZEFsbCA9PT0gdHJ1ZSAmJiB0aGlzLmxhc3RXYXZlID09PSBmYWxzZSAmJlxyXG4gICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5oYXNEZXN0cm95ZWRBbGwgPT09IHRydWUgJiZcclxuICAgICAgICB0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDEnKSB7XHJcbiAgICAgICAgICAgIHRoaXMubGFzdFdhdmUgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDQpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCA1KTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNyk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDEwKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMyk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgOSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkTm9ybWFsQ2VsbCgpO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDMpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkTm9ybWFsQ2VsbCgpO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksIDgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYodGhpcy5oYXNEZXN0cm95ZWRBbGwgPT09IHRydWUgJiYgdGhpcy5sYXN0V2F2ZSA9PT0gZmFsc2UgJiZcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmhhc0Rlc3Ryb3llZEFsbCA9PT0gdHJ1ZSAmJlxyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDInKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCA0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxMyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDE3KTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgOSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDE1KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mZWN0ZWRDZWxsKCk7ICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxNik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTgpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkTm9ybWFsQ2VsbCgpO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGROb3JtYWxDZWxsKCk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGROb3JtYWxDZWxsKCk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDEzKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkTm9ybWFsQ2VsbCgpO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxNCk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYodGhpcy5oYXNEZXN0cm95ZWRBbGwgPT09IHRydWUgJiYgdGhpcy5sYXN0V2F2ZSA9PT0gZmFsc2UgJiZcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmhhc0Rlc3Ryb3llZEFsbCA9PT0gdHJ1ZSAmJlxyXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDMnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCA0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkKHRoaXMubnVtKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgNSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxMCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksMTUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGQodGhpcy5udW0pO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxOCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZCh0aGlzLm51bSk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDIwKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgOCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkSW5mZWN0ZWRDZWxsKCk7ICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxNyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZEluZmVjdGVkQ2VsbCgpOyAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRJbmZlY3RlZENlbGwoKTsgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDIxKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZE5vcm1hbENlbGwoKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZE5vcm1hbENlbGwoKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSwgMTEpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGROb3JtYWxDZWxsKCk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcyksIDE2KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkTm9ybWFsQ2VsbCgpO1xyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpLCAxOSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgY2hlY2tGYWlsdXJlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICBpZih0aGlzLmppYW5nc2hpW2ldLnggPCAwLjEgLSA0ODApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2FvZGkuZ2V0Q29tcG9uZW50KCdnYW1lQ29udHJvbCcpLmdhbWVTdGF0dXMgPSAnZmFpbCc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGNoZWNrU3VjY2VzczogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLypcclxuICAgICAgICB2YXIgZmxhZyA9IHRydWU7XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAxJyAmJiB0aGlzLm51bSA9PT0gMTMgJiZcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtID09PSAxMikge1xyXG4gICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAyJyAmJiB0aGlzLm51bSA9PT0gMjUgJiZcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtID09PSAyNikge1xyXG4gICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAzJyAmJiB0aGlzLm51bSA9PT0gMzkgJiZcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtID09PSA0MSkge1xyXG4gICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgdGhpcy5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW07IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLmluZmVjdGVkQ2VsbFtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5sYXN0V2F2ZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgZmxhZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDEnICYmICh0aGlzLm51bSA8IDEzIHx8XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bSA8IDEyKSkge1xyXG4gICAgICAgICAgICBmbGFnID0gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50LnBhcmVudC5uYW1lID09PSAnTGV2ZWwwMicgJiYgKHRoaXMubnVtIDwgMjUgfHxcclxuICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtIDwgMjYpKSB7XHJcbiAgICAgICAgICAgIGZsYWcgPSBmYWxzZTtcclxuICAgICAgICB9IGVsc2UgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAzJyAmJiB0aGlzLm51bSA8IDM5IHx8XHJcbiAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudCgncGlhbycpLm51bSA8IDQxKSB7XHJcbiAgICAgICAgICAgIGZsYWcgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoZmxhZyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNhb2RpLmdldENvbXBvbmVudCgnZ2FtZUNvbnRyb2wnKS5nYW1lU3RhdHVzID0gJ3N1Y2NlZWQnO1xyXG4gICAgICAgIH1cclxuICAgICAgICAqL1xyXG4gICAgICAgaWYodGhpcy5sYXN0V2F2ZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICB9XHJcbiAgICAgICBpZih0aGlzLm5vZGUucGFyZW50LnBhcmVudC5wYXJlbnQubmFtZSA9PT0gJ0xldmVsMDEnKSB7XHJcbiAgICAgICAgICAgaWYodGhpcy5udW0gIT09IDEzIHx8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW0gIT09IDEyKSB7XHJcbiAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IDEzOyBpKyspIHtcclxuICAgICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgMTI7IGkrKykge1xyXG4gICAgICAgICAgICAgICBpZih0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuaW5mZWN0ZWRDZWxsW2ldLmFjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIHRoaXMuY2FvZGkuZ2V0Q29tcG9uZW50KCdnYW1lQ29udHJvbCcpLmdhbWVTdGF0dXMgPSAnc3VjY2VlZCc7XHJcbiAgICAgICB9XHJcbiAgICAgICAgaWYodGhpcy5ub2RlLnBhcmVudC5wYXJlbnQucGFyZW50Lm5hbWUgPT09ICdMZXZlbDAyJykge1xyXG4gICAgICAgICAgIGlmKHRoaXMubnVtICE9PSAyNSB8fCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtICE9PSAyNikge1xyXG4gICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgMjU7IGkrKykge1xyXG4gICAgICAgICAgICAgICBpZih0aGlzLmppYW5nc2hpW2ldLmFjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IDI2OyBpKyspIHtcclxuICAgICAgICAgICAgICBpZih0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuaW5mZWN0ZWRDZWxsW2ldLmFjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuY2FvZGkuZ2V0Q29tcG9uZW50KCdnYW1lQ29udHJvbCcpLmdhbWVTdGF0dXMgPSAnc3VjY2VlZCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50LnBhcmVudC5uYW1lID09PSAnTGV2ZWwwMycpIHtcclxuICAgICAgICAgICAgaWYodGhpcy5udW0gIT09IDM5IHx8IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ3BpYW8nKS5udW0gIT09IDQxKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yKHZhciBpID0gMDsgaSA8IDM5OyBpKyspIHtcclxuICAgICAgICAgICAgaWYodGhpcy5qaWFuZ3NoaVtpXS5hY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDwgNDE7IGkrKykge1xyXG4gICAgICAgICAgICBpZih0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuaW5mZWN0ZWRDZWxsW2ldLmFjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2FvZGkuZ2V0Q29tcG9uZW50KCdnYW1lQ29udHJvbCcpLmdhbWVTdGF0dXMgPSAnc3VjY2VlZCc7XHJcbiAgICAgICAgfSAgICAgICAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmNoZWNrRGVhZCgpO1xyXG4gICAgICAgIHRoaXMuY2hlY2tEZXN0cm95QWxsKCk7XHJcbiAgICAgICAgdGhpcy5jaGVja0xhdW5jaExhc3RXYXZlKCk7XHJcbiAgICAgICAgdGhpcy5jaGVja0ZhaWx1cmUoKTtcclxuICAgICAgICB0aGlzLmNoZWNrU3VjY2VzcygpO1xyXG4gICAgICAgIC8vY2MubG9nKHRoaXMubnVtLCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykubnVtLCB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KCdwaWFvJykuaGFzRGVzdHJveWVkQWxsKTtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=