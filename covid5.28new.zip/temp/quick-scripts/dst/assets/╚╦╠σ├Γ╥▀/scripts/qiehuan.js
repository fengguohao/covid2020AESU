
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/qiehuan.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7053fxX8NJKxLjhPhkQg/E+', 'qiehuan');
// 人体免疫/scripts/qiehuan.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    /*
    if(cc.sys.localStorage.getItem('hasPassed') === 1){
        this.node.getChildByName('level02').getComponent(cc.Button).interactable = true;
        this.node.getChildByName('level03').getComponent(cc.Button).interactable = false;
    }
    else{
        this.node.getChildByName('level02').getComponent(cc.Button).interactable = false;
        this.node.getChildByName('level03').getComponent(cc.Button).interactable = false;
    }
    if(cc.sys.localStorage.getItem('hasPassed') === 2){
        this.node.getChildByName('level03').getComponent(cc.Button).interactable = true;
    }
    else{
        this.node.getChildByName('level03').getComponent(cc.Button).interactable = false;
    }
    */
    if (cc.sys.localStorage.getItem('hasPassed') === null) {
      cc.sys.localStorage.setItem('hasPassed', 0);
    }

    cc.log(cc.sys.localStorage.getItem('hasPassed'));

    if (cc.sys.localStorage.getItem('hasPassed') === '0') {
      this.node.getChildByName('level01').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level01').getChildByName('Background').color = new cc.Color(255, 255, 255);
      this.node.getChildByName('level02').getComponent(cc.Button).interactable = false;
      this.node.getChildByName('level02').getChildByName('Background').color = new cc.Color(127, 127, 127);
      this.node.getChildByName('level03').getComponent(cc.Button).interactable = false;
      this.node.getChildByName('level03').getChildByName('Background').color = new cc.Color(127, 127, 127);
    } else if (cc.sys.localStorage.getItem('hasPassed') === '1') {
      this.node.getChildByName('level01').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level01').getChildByName('Background').color = new cc.Color(255, 255, 255);
      this.node.getChildByName('level02').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level02').getChildByName('Background').color = new cc.Color(255, 255, 255);
      this.node.getChildByName('level03').getComponent(cc.Button).interactable = false;
      this.node.getChildByName('level03').getChildByName('Background').color = new cc.Color(127, 127, 127);
    } else if (cc.sys.localStorage.getItem('hasPassed') === '2' || cc.sys.localStorage.getItem('hasPassed') === '3') {
      this.node.getChildByName('level01').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level01').getChildByName('Background').color = new cc.Color(255, 255, 255);
      this.node.getChildByName('level02').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level02').getChildByName('Background').color = new cc.Color(255, 255, 255);
      this.node.getChildByName('level03').getComponent(cc.Button).interactable = true;
      this.node.getChildByName('level03').getChildByName('Background').color = new cc.Color(255, 255, 255);
    }
  },
  start: function start() {},
  onclickbutton1: function onclickbutton1() {
    cc.director.loadScene("Level01");
  },
  onclickbutton2: function onclickbutton2() {
    cc.director.loadScene("Level02");
  },
  onclickbutton3: function onclickbutton3() {
    cc.director.loadScene("Level03");
  },
  onclickbutton4: function onclickbutton4() {
    cc.director.loadScene("衔接场景");
  },
  onclickbutton5: function onclickbutton5() {
    cc.director.loadScene("tujian");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxxaWVodWFuLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwic3lzIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInNldEl0ZW0iLCJsb2ciLCJub2RlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJCdXR0b24iLCJpbnRlcmFjdGFibGUiLCJjb2xvciIsIkNvbG9yIiwic3RhcnQiLCJvbmNsaWNrYnV0dG9uMSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwib25jbGlja2J1dHRvbjIiLCJvbmNsaWNrYnV0dG9uMyIsIm9uY2xpY2tidXR0b240Iiwib25jbGlja2J1dHRvbjUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsTUFUSyxvQkFTSztBQUNOOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLFFBQUdKLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixXQUE1QixNQUE2QyxJQUFoRCxFQUFzRDtBQUNsRFAsTUFBQUEsRUFBRSxDQUFDSyxHQUFILENBQU9DLFlBQVAsQ0FBb0JFLE9BQXBCLENBQTRCLFdBQTVCLEVBQXlDLENBQXpDO0FBQ0g7O0FBQ0RSLElBQUFBLEVBQUUsQ0FBQ1MsR0FBSCxDQUFPVCxFQUFFLENBQUNLLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsQ0FBUDs7QUFDQSxRQUFHUCxFQUFFLENBQUNLLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsTUFBNkMsR0FBaEQsRUFBcUQ7QUFDakQsV0FBS0csSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQyxZQUFwQyxDQUFpRFosRUFBRSxDQUFDYSxNQUFwRCxFQUE0REMsWUFBNUQsR0FBMkUsSUFBM0U7QUFDQSxXQUFLSixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NBLGNBQXBDLENBQW1ELFlBQW5ELEVBQWlFSSxLQUFqRSxHQUF5RSxJQUFJZixFQUFFLENBQUNnQixLQUFQLENBQWEsR0FBYixFQUFrQixHQUFsQixFQUF1QixHQUF2QixDQUF6RTtBQUNBLFdBQUtOLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0MsWUFBcEMsQ0FBaURaLEVBQUUsQ0FBQ2EsTUFBcEQsRUFBNERDLFlBQTVELEdBQTJFLEtBQTNFO0FBQ0EsV0FBS0osSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQSxjQUFwQyxDQUFtRCxZQUFuRCxFQUFpRUksS0FBakUsR0FBeUUsSUFBSWYsRUFBRSxDQUFDZ0IsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBekU7QUFDQSxXQUFLTixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NDLFlBQXBDLENBQWlEWixFQUFFLENBQUNhLE1BQXBELEVBQTREQyxZQUE1RCxHQUEyRSxLQUEzRTtBQUNBLFdBQUtKLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0EsY0FBcEMsQ0FBbUQsWUFBbkQsRUFBaUVJLEtBQWpFLEdBQXlFLElBQUlmLEVBQUUsQ0FBQ2dCLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLEdBQWxCLEVBQXVCLEdBQXZCLENBQXpFO0FBQ0gsS0FQRCxNQU9PLElBQUdoQixFQUFFLENBQUNLLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsTUFBNkMsR0FBaEQsRUFBcUQ7QUFDeEQsV0FBS0csSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQyxZQUFwQyxDQUFpRFosRUFBRSxDQUFDYSxNQUFwRCxFQUE0REMsWUFBNUQsR0FBMkUsSUFBM0U7QUFDQSxXQUFLSixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NBLGNBQXBDLENBQW1ELFlBQW5ELEVBQWlFSSxLQUFqRSxHQUF5RSxJQUFJZixFQUFFLENBQUNnQixLQUFQLENBQWEsR0FBYixFQUFrQixHQUFsQixFQUF1QixHQUF2QixDQUF6RTtBQUNBLFdBQUtOLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0MsWUFBcEMsQ0FBaURaLEVBQUUsQ0FBQ2EsTUFBcEQsRUFBNERDLFlBQTVELEdBQTJFLElBQTNFO0FBQ0EsV0FBS0osSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQSxjQUFwQyxDQUFtRCxZQUFuRCxFQUFpRUksS0FBakUsR0FBeUUsSUFBSWYsRUFBRSxDQUFDZ0IsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBekU7QUFDQSxXQUFLTixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NDLFlBQXBDLENBQWlEWixFQUFFLENBQUNhLE1BQXBELEVBQTREQyxZQUE1RCxHQUEyRSxLQUEzRTtBQUNBLFdBQUtKLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0EsY0FBcEMsQ0FBbUQsWUFBbkQsRUFBaUVJLEtBQWpFLEdBQXlFLElBQUlmLEVBQUUsQ0FBQ2dCLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLEdBQWxCLEVBQXVCLEdBQXZCLENBQXpFO0FBQ0gsS0FQTSxNQU9BLElBQUdoQixFQUFFLENBQUNLLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsTUFBNkMsR0FBN0MsSUFBb0RQLEVBQUUsQ0FBQ0ssR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixXQUE1QixNQUE2QyxHQUFwRyxFQUF5RztBQUM1RyxXQUFLRyxJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NDLFlBQXBDLENBQWlEWixFQUFFLENBQUNhLE1BQXBELEVBQTREQyxZQUE1RCxHQUEyRSxJQUEzRTtBQUNBLFdBQUtKLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0EsY0FBcEMsQ0FBbUQsWUFBbkQsRUFBaUVJLEtBQWpFLEdBQXlFLElBQUlmLEVBQUUsQ0FBQ2dCLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLEdBQWxCLEVBQXVCLEdBQXZCLENBQXpFO0FBQ0EsV0FBS04sSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQyxZQUFwQyxDQUFpRFosRUFBRSxDQUFDYSxNQUFwRCxFQUE0REMsWUFBNUQsR0FBMkUsSUFBM0U7QUFDQSxXQUFLSixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsU0FBekIsRUFBb0NBLGNBQXBDLENBQW1ELFlBQW5ELEVBQWlFSSxLQUFqRSxHQUF5RSxJQUFJZixFQUFFLENBQUNnQixLQUFQLENBQWEsR0FBYixFQUFrQixHQUFsQixFQUF1QixHQUF2QixDQUF6RTtBQUNBLFdBQUtOLElBQUwsQ0FBVUMsY0FBVixDQUF5QixTQUF6QixFQUFvQ0MsWUFBcEMsQ0FBaURaLEVBQUUsQ0FBQ2EsTUFBcEQsRUFBNERDLFlBQTVELEdBQTJFLElBQTNFO0FBQ0EsV0FBS0osSUFBTCxDQUFVQyxjQUFWLENBQXlCLFNBQXpCLEVBQW9DQSxjQUFwQyxDQUFtRCxZQUFuRCxFQUFpRUksS0FBakUsR0FBeUUsSUFBSWYsRUFBRSxDQUFDZ0IsS0FBUCxDQUFhLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsQ0FBekU7QUFDSDtBQUNKLEdBcERJO0FBc0RMQyxFQUFBQSxLQXRESyxtQkFzREksQ0FFUixDQXhESTtBQXlETEMsRUFBQUEsY0FBYyxFQUFDLDBCQUFVO0FBQ3JCbEIsSUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBQ0gsR0EzREk7QUE2RExDLEVBQUFBLGNBQWMsRUFBQywwQkFBVTtBQUNyQnJCLElBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixTQUF0QjtBQUNILEdBL0RJO0FBaUVMRSxFQUFBQSxjQUFjLEVBQUMsMEJBQVU7QUFDckJ0QixJQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlDLFNBQVosQ0FBc0IsU0FBdEI7QUFDSCxHQW5FSTtBQW9FTEcsRUFBQUEsY0FBYyxFQUFDLDBCQUFVO0FBQ3JCdkIsSUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0F0RUk7QUF1RUxJLEVBQUFBLGNBQWMsRUFBQywwQkFBVTtBQUNyQnhCLElBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixRQUF0QjtBQUNILEdBekVJLENBMEVMOztBQTFFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICAvKlxyXG4gICAgICAgIGlmKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGFzUGFzc2VkJykgPT09IDEpe1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDInKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDMnKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAyJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMycpLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hhc1Bhc3NlZCcpID09PSAyKXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAzJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAzJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICovXHJcbiAgICAgICAgaWYoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdoYXNQYXNzZWQnKSA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2hhc1Bhc3NlZCcsIDApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYy5sb2coY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdoYXNQYXNzZWQnKSk7XHJcbiAgICAgICAgaWYoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdoYXNQYXNzZWQnKSA9PT0gJzAnKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMScpLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMScpLmdldENoaWxkQnlOYW1lKCdCYWNrZ3JvdW5kJykuY29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDI1NSk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMicpLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDInKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmNvbG9yID0gbmV3IGNjLkNvbG9yKDEyNywgMTI3LCAxMjcpO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDMnKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAzJykuZ2V0Q2hpbGRCeU5hbWUoJ0JhY2tncm91bmQnKS5jb2xvciA9IG5ldyBjYy5Db2xvcigxMjcsIDEyNywgMTI3KTsgICAgICAgICAgICBcclxuICAgICAgICB9IGVsc2UgaWYoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdoYXNQYXNzZWQnKSA9PT0gJzEnKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMScpLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZSA9IHRydWVcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAxJykuZ2V0Q2hpbGRCeU5hbWUoJ0JhY2tncm91bmQnKS5jb2xvciA9IG5ldyBjYy5Db2xvcigyNTUsIDI1NSwgMjU1KTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAyJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAyJykuZ2V0Q2hpbGRCeU5hbWUoJ0JhY2tncm91bmQnKS5jb2xvciA9IG5ldyBjYy5Db2xvcigyNTUsIDI1NSwgMjU1KTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAzJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnbGV2ZWwwMycpLmdldENoaWxkQnlOYW1lKCdCYWNrZ3JvdW5kJykuY29sb3IgPSBuZXcgY2MuQ29sb3IoMTI3LCAxMjcsIDEyNyk7ICAgICAgICAgICAgXHJcbiAgICAgICAgfSBlbHNlIGlmKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnaGFzUGFzc2VkJykgPT09ICcyJyB8fCBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2hhc1Bhc3NlZCcpID09PSAnMycpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCdsZXZlbDAxJykuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlID0gdHJ1ZVxyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDEnKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDInKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDInKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDMnKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ2xldmVsMDMnKS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcbiAgICBvbmNsaWNrYnV0dG9uMTpmdW5jdGlvbigpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkxldmVsMDFcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uY2xpY2tidXR0b24yOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTGV2ZWwwMlwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgb25jbGlja2J1dHRvbjM6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJMZXZlbDAzXCIpO1xyXG4gICAgfSxcclxuICAgIG9uY2xpY2tidXR0b240OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi6KGU5o6l5Zy65pmvXCIpO1xyXG4gICAgfSxcclxuICAgIG9uY2xpY2tidXR0b241OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwidHVqaWFuXCIpO1xyXG4gICAgfSxcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19