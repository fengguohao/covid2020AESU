
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/人体免疫/scripts/showCoolingTime.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '645f1ypypNFYJ5RE2E1aKuH', 'showCoolingTime');
// 人体免疫/scripts/showCoolingTime.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this.node.parent.name === 'antiviral') {
      if (this.node.parent.parent.getComponent('antiviral').cooling1 !== 0) {
        this.node.getComponent(cc.Label).string = this.node.parent.parent.getComponent('antiviral').cooling1;
      } else {
        this.node.getComponent(cc.Label).string = '';
      }
    } else if (this.node.parent.name === 'antiCK') {
      if (this.node.parent.parent.getComponent('antiviral').cooling2 !== 0) {
        this.node.getComponent(cc.Label).string = this.node.parent.parent.getComponent('antiviral').cooling2;
      } else {
        this.node.getComponent(cc.Label).string = '';
      }
    } else if (this.node.parent.name === 'kafeidoukuang') {
      if (this.node.parent.getComponent('huohua').cooling !== 0) {
        this.node.getComponent(cc.Label).string = this.node.parent.getComponent('huohua').cooling;
      } else {
        this.node.getComponent(cc.Label).string = '';
      }
    } else {
      if (this.node.parent.getComponent('bozhong').cooling !== 0) {
        this.node.getComponent(cc.Label).string = this.node.parent.getComponent('bozhong').cooling;
      } else {
        this.node.getComponent(cc.Label).string = '';
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Lq65L2T5YWN55arXFxzY3JpcHRzXFxzaG93Q29vbGluZ1RpbWUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwibm9kZSIsInBhcmVudCIsIm5hbWUiLCJnZXRDb21wb25lbnQiLCJjb29saW5nMSIsIkxhYmVsIiwic3RyaW5nIiwiY29vbGluZzIiLCJjb29saW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsQ0FDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmUSxHQUhQO0FBcUJMO0FBRUE7QUFFQUMsRUFBQUEsS0F6QkssbUJBeUJJLENBRVIsQ0EzQkk7QUE2QkxDLEVBQUFBLE1BN0JLLGtCQTZCR0MsRUE3QkgsRUE2Qk87QUFDUixRQUFHLEtBQUtDLElBQUwsQ0FBVUMsTUFBVixDQUFpQkMsSUFBakIsS0FBMEIsV0FBN0IsRUFBMEM7QUFDdEMsVUFBRyxLQUFLRixJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCRSxZQUF4QixDQUFxQyxXQUFyQyxFQUFrREMsUUFBbEQsS0FBK0QsQ0FBbEUsRUFBcUU7QUFDakUsYUFBS0osSUFBTCxDQUFVRyxZQUFWLENBQXVCVixFQUFFLENBQUNZLEtBQTFCLEVBQWlDQyxNQUFqQyxHQUEwQyxLQUFLTixJQUFMLENBQVVDLE1BQVYsQ0FBaUJBLE1BQWpCLENBQXdCRSxZQUF4QixDQUFxQyxXQUFyQyxFQUFrREMsUUFBNUY7QUFDSCxPQUZELE1BRU87QUFDSCxhQUFLSixJQUFMLENBQVVHLFlBQVYsQ0FBdUJWLEVBQUUsQ0FBQ1ksS0FBMUIsRUFBaUNDLE1BQWpDLEdBQTBDLEVBQTFDO0FBQ0g7QUFDSixLQU5ELE1BTU8sSUFBRyxLQUFLTixJQUFMLENBQVVDLE1BQVYsQ0FBaUJDLElBQWpCLEtBQTBCLFFBQTdCLEVBQXVDO0FBQzFDLFVBQUcsS0FBS0YsSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkUsWUFBeEIsQ0FBcUMsV0FBckMsRUFBa0RJLFFBQWxELEtBQStELENBQWxFLEVBQXFFO0FBQ2pFLGFBQUtQLElBQUwsQ0FBVUcsWUFBVixDQUF1QlYsRUFBRSxDQUFDWSxLQUExQixFQUFpQ0MsTUFBakMsR0FBMEMsS0FBS04sSUFBTCxDQUFVQyxNQUFWLENBQWlCQSxNQUFqQixDQUF3QkUsWUFBeEIsQ0FBcUMsV0FBckMsRUFBa0RJLFFBQTVGO0FBQ0gsT0FGRCxNQUVPO0FBQ0gsYUFBS1AsSUFBTCxDQUFVRyxZQUFWLENBQXVCVixFQUFFLENBQUNZLEtBQTFCLEVBQWlDQyxNQUFqQyxHQUEwQyxFQUExQztBQUNIO0FBQ0osS0FOTSxNQU1BLElBQUcsS0FBS04sSUFBTCxDQUFVQyxNQUFWLENBQWlCQyxJQUFqQixLQUEwQixlQUE3QixFQUE4QztBQUNqRCxVQUFHLEtBQUtGLElBQUwsQ0FBVUMsTUFBVixDQUFpQkUsWUFBakIsQ0FBOEIsUUFBOUIsRUFBd0NLLE9BQXhDLEtBQW9ELENBQXZELEVBQTBEO0FBQ3RELGFBQUtSLElBQUwsQ0FBVUcsWUFBVixDQUF1QlYsRUFBRSxDQUFDWSxLQUExQixFQUFpQ0MsTUFBakMsR0FBMEMsS0FBS04sSUFBTCxDQUFVQyxNQUFWLENBQWlCRSxZQUFqQixDQUE4QixRQUE5QixFQUF3Q0ssT0FBbEY7QUFDSCxPQUZELE1BRU87QUFDSCxhQUFLUixJQUFMLENBQVVHLFlBQVYsQ0FBdUJWLEVBQUUsQ0FBQ1ksS0FBMUIsRUFBaUNDLE1BQWpDLEdBQTBDLEVBQTFDO0FBQ0g7QUFDSixLQU5NLE1BTUE7QUFDSCxVQUFHLEtBQUtOLElBQUwsQ0FBVUMsTUFBVixDQUFpQkUsWUFBakIsQ0FBOEIsU0FBOUIsRUFBeUNLLE9BQXpDLEtBQXFELENBQXhELEVBQTJEO0FBQ3ZELGFBQUtSLElBQUwsQ0FBVUcsWUFBVixDQUF1QlYsRUFBRSxDQUFDWSxLQUExQixFQUFpQ0MsTUFBakMsR0FBMEMsS0FBS04sSUFBTCxDQUFVQyxNQUFWLENBQWlCRSxZQUFqQixDQUE4QixTQUE5QixFQUF5Q0ssT0FBbkY7QUFDSCxPQUZELE1BRU87QUFDSCxhQUFLUixJQUFMLENBQVVHLFlBQVYsQ0FBdUJWLEVBQUUsQ0FBQ1ksS0FBMUIsRUFBaUNDLE1BQWpDLEdBQTBDLEVBQTFDO0FBQ0g7QUFDSjtBQUNKO0FBdkRJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50Lm5hbWUgPT09ICdhbnRpdmlyYWwnKSB7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmdldENvbXBvbmVudCgnYW50aXZpcmFsJykuY29vbGluZzEgIT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmdldENvbXBvbmVudCgnYW50aXZpcmFsJykuY29vbGluZzE7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAnJzsgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSAgICAgICAgICAgIFxyXG4gICAgICAgIH0gZWxzZSBpZih0aGlzLm5vZGUucGFyZW50Lm5hbWUgPT09ICdhbnRpQ0snKSB7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmdldENvbXBvbmVudCgnYW50aXZpcmFsJykuY29vbGluZzIgIT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IHRoaXMubm9kZS5wYXJlbnQucGFyZW50LmdldENvbXBvbmVudCgnYW50aXZpcmFsJykuY29vbGluZzI7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAnJzsgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSAgICAgICAgICAgIFxyXG4gICAgICAgIH0gZWxzZSBpZih0aGlzLm5vZGUucGFyZW50Lm5hbWUgPT09ICdrYWZlaWRvdWt1YW5nJykge1xyXG4gICAgICAgICAgICBpZih0aGlzLm5vZGUucGFyZW50LmdldENvbXBvbmVudCgnaHVvaHVhJykuY29vbGluZyAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gdGhpcy5ub2RlLnBhcmVudC5nZXRDb21wb25lbnQoJ2h1b2h1YScpLmNvb2xpbmc7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAnJzsgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSAgICAgICAgICAgIFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmKHRoaXMubm9kZS5wYXJlbnQuZ2V0Q29tcG9uZW50KCdib3pob25nJykuY29vbGluZyAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gdGhpcy5ub2RlLnBhcmVudC5nZXRDb21wb25lbnQoJ2JvemhvbmcnKS5jb29saW5nO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJyc7ICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIH0gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59KTtcclxuIl19