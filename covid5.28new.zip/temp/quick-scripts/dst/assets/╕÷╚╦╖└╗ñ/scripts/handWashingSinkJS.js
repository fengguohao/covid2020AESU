
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/handWashingSinkJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f5ef4of4uFDIaYYBDOd6dG9', 'handWashingSinkJS');
// 火车防护/scripts/handWashingSinkJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    promptBox: {
      "default": null,
      type: cc.Node
    },
    buttonConfirm: {
      "default": null,
      type: cc.Node
    },
    show: {
      "default": null,
      type: cc.Node
    },
    controlLimit: {
      "default": null,
      type: cc.Node
    },
    control: {
      "default": null,
      type: cc.Node
    },
    gamePlayer: {
      "default": null,
      type: cc.Node
    },
    audioMgr: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.audioMgr = this.audioMgr.getComponent("AudioMgr");
  },
  onClick: function onClick() {
    var gamePlayer = this.gamePlayer.getComponent('gamePlayer');

    if (Math.abs(this.gamePlayer.x - this.node.x) <= 80 && Math.abs(this.gamePlayer.y - this.node.y) <= 60 && gamePlayer.hasReleased === false && gamePlayer.direction !== "down" && gamePlayer.direction !== "right") {
      this.control.x = this.control.getComponent('UIcontrol').defaultPos.x;
      this.control.y = this.control.getComponent('UIcontrol').defaultPos.y;
      this.controlLimit.active = false;
      this.control.getComponent('UIcontrol').ontouch = 0;
      this.promptBox.active = true;
      this.buttonConfirm.active = true;
      var tell = this.show.getComponent(cc.Label);
      tell.string = "你已洗手~";
      this.gamePlayer.hasWashedHandsBefore = true;
      this.audioMgr.playMusic("washHands");
    }

    if (Math.abs(this.gamePlayer.x - this.node.x) <= 80 && Math.abs(this.gamePlayer.y - this.node.y) <= 60 && gamePlayer.hasReleased === true && gamePlayer.direction !== "down" && gamePlayer.direction !== "right") {
      this.control.x = this.control.getComponent('UIcontrol').defaultPos.x;
      this.control.y = this.control.getComponent('UIcontrol').defaultPos.y;
      this.controlLimit.active = false;
      this.control.getComponent('UIcontrol').ontouch = 0;
      this.promptBox.active = true;
      this.buttonConfirm.active = true;
      var tell = this.show.getComponent(cc.Label);
      tell.string = "你已洗手~";
      this.gamePlayer.hasWashedHandsAfter = true;
    }
    /*
    cc.log("是否已上厕所：", gamePlayer.hasReleased);
    cc.log("玩家的方向：", gamePlayer.direction);
    cc.log("洗手池的位置：", this.node.x, this.node.y);
    cc.log("玩家的位置：", this.gamePlayer.x, this.gamePlayer.y);
    cc.log("坐标差的绝对值：", Math.abs(this.gamePlayer.x - this.node.x), Math.abs(this.gamePlayer.y - this.node.y));
    */

  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxoYW5kV2FzaGluZ1NpbmtKUy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInByb21wdEJveCIsInR5cGUiLCJOb2RlIiwiYnV0dG9uQ29uZmlybSIsInNob3ciLCJjb250cm9sTGltaXQiLCJjb250cm9sIiwiZ2FtZVBsYXllciIsImF1ZGlvTWdyIiwic3RhcnQiLCJnZXRDb21wb25lbnQiLCJvbkNsaWNrIiwiTWF0aCIsImFicyIsIngiLCJub2RlIiwieSIsImhhc1JlbGVhc2VkIiwiZGlyZWN0aW9uIiwiZGVmYXVsdFBvcyIsImFjdGl2ZSIsIm9udG91Y2giLCJ0ZWxsIiwiTGFiZWwiLCJzdHJpbmciLCJoYXNXYXNoZWRIYW5kc0JlZm9yZSIsInBsYXlNdXNpYyIsImhhc1dhc2hlZEhhbmRzQWZ0ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUVSQyxJQUFBQSxTQUFTLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZGLEtBRkg7QUFPUkMsSUFBQUEsYUFBYSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRSxLQVBQO0FBWVJFLElBQUFBLElBQUksRUFBRTtBQUNGLGlCQUFTLElBRFA7QUFFRkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlAsS0FaRTtBQWlCUkcsSUFBQUEsWUFBWSxFQUFFO0FBQ1YsaUJBQVMsSUFEQztBQUVWSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGQyxLQWpCTjtBQXNCUkksSUFBQUEsT0FBTyxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSixLQXRCRDtBQTJCUkssSUFBQUEsVUFBVSxFQUFFO0FBQ1IsaUJBQVMsSUFERDtBQUVSTixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRCxLQTNCSjtBQWdDUk0sSUFBQUEsUUFBUSxFQUFDO0FBQ0wsaUJBQVMsSUFESjtBQUVMUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSjtBQWhDRCxHQUhQO0FBMENMO0FBRUE7QUFFQU8sRUFBQUEsS0E5Q0ssbUJBOENJO0FBQ0wsU0FBS0QsUUFBTCxHQUFjLEtBQUtBLFFBQUwsQ0FBY0UsWUFBZCxDQUEyQixVQUEzQixDQUFkO0FBQ0gsR0FoREk7QUFrRExDLEVBQUFBLE9BQU8sRUFBRSxtQkFBVztBQUVoQixRQUFJSixVQUFVLEdBQUcsS0FBS0EsVUFBTCxDQUFnQkcsWUFBaEIsQ0FBNkIsWUFBN0IsQ0FBakI7O0FBRUEsUUFBR0UsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS04sVUFBTCxDQUFnQk8sQ0FBaEIsR0FBb0IsS0FBS0MsSUFBTCxDQUFVRCxDQUF2QyxLQUE2QyxFQUE3QyxJQUFtREYsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS04sVUFBTCxDQUFnQlMsQ0FBaEIsR0FBb0IsS0FBS0QsSUFBTCxDQUFVQyxDQUF2QyxLQUE2QyxFQUFoRyxJQUNDVCxVQUFVLENBQUNVLFdBQVgsS0FBMkIsS0FENUIsSUFDcUNWLFVBQVUsQ0FBQ1csU0FBWCxLQUF5QixNQUQ5RCxJQUN3RVgsVUFBVSxDQUFDVyxTQUFYLEtBQXlCLE9BRHBHLEVBQzZHO0FBQ3pHLFdBQUtaLE9BQUwsQ0FBYVEsQ0FBYixHQUFpQixLQUFLUixPQUFMLENBQWFJLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUNTLFVBQXZDLENBQWtETCxDQUFuRTtBQUNBLFdBQUtSLE9BQUwsQ0FBYVUsQ0FBYixHQUFpQixLQUFLVixPQUFMLENBQWFJLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUNTLFVBQXZDLENBQWtESCxDQUFuRTtBQUNBLFdBQUtYLFlBQUwsQ0FBa0JlLE1BQWxCLEdBQTJCLEtBQTNCO0FBQ0EsV0FBS2QsT0FBTCxDQUFhSSxZQUFiLENBQTBCLFdBQTFCLEVBQXVDVyxPQUF2QyxHQUFpRCxDQUFqRDtBQUNBLFdBQUtyQixTQUFMLENBQWVvQixNQUFmLEdBQXdCLElBQXhCO0FBQ0EsV0FBS2pCLGFBQUwsQ0FBbUJpQixNQUFuQixHQUE0QixJQUE1QjtBQUNBLFVBQUlFLElBQUksR0FBRyxLQUFLbEIsSUFBTCxDQUFVTSxZQUFWLENBQXVCZCxFQUFFLENBQUMyQixLQUExQixDQUFYO0FBQ0FELE1BQUFBLElBQUksQ0FBQ0UsTUFBTCxHQUFjLE9BQWQ7QUFDQSxXQUFLakIsVUFBTCxDQUFnQmtCLG9CQUFoQixHQUF1QyxJQUF2QztBQUNBLFdBQUtqQixRQUFMLENBQWNrQixTQUFkLENBQXdCLFdBQXhCO0FBQ0g7O0FBRUQsUUFBR2QsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS04sVUFBTCxDQUFnQk8sQ0FBaEIsR0FBb0IsS0FBS0MsSUFBTCxDQUFVRCxDQUF2QyxLQUE2QyxFQUE3QyxJQUFtREYsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS04sVUFBTCxDQUFnQlMsQ0FBaEIsR0FBb0IsS0FBS0QsSUFBTCxDQUFVQyxDQUF2QyxLQUE2QyxFQUFoRyxJQUNDVCxVQUFVLENBQUNVLFdBQVgsS0FBMkIsSUFENUIsSUFDb0NWLFVBQVUsQ0FBQ1csU0FBWCxLQUF5QixNQUQ3RCxJQUN1RVgsVUFBVSxDQUFDVyxTQUFYLEtBQXlCLE9BRG5HLEVBQzRHO0FBQ3hHLFdBQUtaLE9BQUwsQ0FBYVEsQ0FBYixHQUFpQixLQUFLUixPQUFMLENBQWFJLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUNTLFVBQXZDLENBQWtETCxDQUFuRTtBQUNBLFdBQUtSLE9BQUwsQ0FBYVUsQ0FBYixHQUFpQixLQUFLVixPQUFMLENBQWFJLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUNTLFVBQXZDLENBQWtESCxDQUFuRTtBQUNBLFdBQUtYLFlBQUwsQ0FBa0JlLE1BQWxCLEdBQTJCLEtBQTNCO0FBQ0EsV0FBS2QsT0FBTCxDQUFhSSxZQUFiLENBQTBCLFdBQTFCLEVBQXVDVyxPQUF2QyxHQUFpRCxDQUFqRDtBQUNBLFdBQUtyQixTQUFMLENBQWVvQixNQUFmLEdBQXdCLElBQXhCO0FBQ0EsV0FBS2pCLGFBQUwsQ0FBbUJpQixNQUFuQixHQUE0QixJQUE1QjtBQUNBLFVBQUlFLElBQUksR0FBRyxLQUFLbEIsSUFBTCxDQUFVTSxZQUFWLENBQXVCZCxFQUFFLENBQUMyQixLQUExQixDQUFYO0FBQ0FELE1BQUFBLElBQUksQ0FBQ0UsTUFBTCxHQUFjLE9BQWQ7QUFDQSxXQUFLakIsVUFBTCxDQUFnQm9CLG1CQUFoQixHQUFzQyxJQUF0QztBQUNIO0FBQ0Q7Ozs7Ozs7O0FBT0gsR0F2RkksQ0F5Rkw7O0FBekZLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgICAgICBwcm9tcHRCb3g6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBidXR0b25Db25maXJtOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgc2hvdzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGNvbnRyb2xMaW1pdDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGNvbnRyb2w6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBnYW1lUGxheWVyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgYXVkaW9NZ3I6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5hdWRpb01ncj10aGlzLmF1ZGlvTWdyLmdldENvbXBvbmVudChcIkF1ZGlvTWdyXCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkNsaWNrOiBmdW5jdGlvbigpIHtcclxuXHJcbiAgICAgICAgdmFyIGdhbWVQbGF5ZXIgPSB0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJyk7XHJcblxyXG4gICAgICAgIGlmKE1hdGguYWJzKHRoaXMuZ2FtZVBsYXllci54IC0gdGhpcy5ub2RlLngpIDw9IDgwICYmIE1hdGguYWJzKHRoaXMuZ2FtZVBsYXllci55IC0gdGhpcy5ub2RlLnkpIDw9IDYwXHJcbiAgICAgICAgICYmIGdhbWVQbGF5ZXIuaGFzUmVsZWFzZWQgPT09IGZhbHNlICYmIGdhbWVQbGF5ZXIuZGlyZWN0aW9uICE9PSBcImRvd25cIiAmJiBnYW1lUGxheWVyLmRpcmVjdGlvbiAhPT0gXCJyaWdodFwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC54ID0gdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykuZGVmYXVsdFBvcy54O1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRyb2wueSA9IHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLmRlZmF1bHRQb3MueTtcclxuICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLm9udG91Y2ggPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbkNvbmZpcm0uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdmFyIHRlbGwgPSB0aGlzLnNob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuICAgICAgICAgICAgdGVsbC5zdHJpbmcgPSBcIuS9oOW3sua0l+aJi35cIjtcclxuICAgICAgICAgICAgdGhpcy5nYW1lUGxheWVyLmhhc1dhc2hlZEhhbmRzQmVmb3JlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5hdWRpb01nci5wbGF5TXVzaWMoXCJ3YXNoSGFuZHNcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZihNYXRoLmFicyh0aGlzLmdhbWVQbGF5ZXIueCAtIHRoaXMubm9kZS54KSA8PSA4MCAmJiBNYXRoLmFicyh0aGlzLmdhbWVQbGF5ZXIueSAtIHRoaXMubm9kZS55KSA8PSA2MFxyXG4gICAgICAgICAmJiBnYW1lUGxheWVyLmhhc1JlbGVhc2VkID09PSB0cnVlICYmIGdhbWVQbGF5ZXIuZGlyZWN0aW9uICE9PSBcImRvd25cIiAmJiBnYW1lUGxheWVyLmRpcmVjdGlvbiAhPT0gXCJyaWdodFwiKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC54ID0gdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykuZGVmYXVsdFBvcy54O1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRyb2wueSA9IHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLmRlZmF1bHRQb3MueTtcclxuICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLm9udG91Y2ggPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbkNvbmZpcm0uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdmFyIHRlbGwgPSB0aGlzLnNob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuICAgICAgICAgICAgdGVsbC5zdHJpbmcgPSBcIuS9oOW3sua0l+aJi35cIjtcclxuICAgICAgICAgICAgdGhpcy5nYW1lUGxheWVyLmhhc1dhc2hlZEhhbmRzQWZ0ZXIgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvKlxyXG4gICAgICAgIGNjLmxvZyhcIuaYr+WQpuW3suS4iuWOleaJgO+8mlwiLCBnYW1lUGxheWVyLmhhc1JlbGVhc2VkKTtcclxuICAgICAgICBjYy5sb2coXCLnjqnlrrbnmoTmlrnlkJHvvJpcIiwgZ2FtZVBsYXllci5kaXJlY3Rpb24pO1xyXG4gICAgICAgIGNjLmxvZyhcIua0l+aJi+axoOeahOS9jee9ru+8mlwiLCB0aGlzLm5vZGUueCwgdGhpcy5ub2RlLnkpO1xyXG4gICAgICAgIGNjLmxvZyhcIueOqeWutueahOS9jee9ru+8mlwiLCB0aGlzLmdhbWVQbGF5ZXIueCwgdGhpcy5nYW1lUGxheWVyLnkpO1xyXG4gICAgICAgIGNjLmxvZyhcIuWdkOagh+W3rueahOe7neWvueWAvO+8mlwiLCBNYXRoLmFicyh0aGlzLmdhbWVQbGF5ZXIueCAtIHRoaXMubm9kZS54KSwgTWF0aC5hYnModGhpcy5nYW1lUGxheWVyLnkgLSB0aGlzLm5vZGUueSkpO1xyXG4gICAgICAgICovXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19