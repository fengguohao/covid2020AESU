
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/neighborMoveJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a6c4bpLrOtMFKlhPXDbaAUR', 'neighborMoveJS');
// 火车防护/scripts/neighborMoveJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    uicontrol: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  start: function start() {
    this.uicontrol = this.uicontrol.getComponent("UIcontrol");
    this.scheduleOnce(function () {
      this.node.runAction(cc.moveTo(3.5, 780, 0));
      this.uicontrol.Walk(this.node, 1, "down");
    }, 15);
    this.scheduleOnce(function () {
      this.node.runAction(cc.moveTo(40, 2600, 0));
      this.uicontrol.Walk(this.node, 1, "right");
    }, 18.5);
    this.scheduleOnce(function () {
      this.uicontrol.Walk(this.node, 1, "stop");
    }, 60);
  },
  onload: function onload() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxuZWlnaGJvck1vdmVKUy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInVpY29udHJvbCIsIk5vZGUiLCJzdGFydCIsImdldENvbXBvbmVudCIsInNjaGVkdWxlT25jZSIsIm5vZGUiLCJydW5BY3Rpb24iLCJtb3ZlVG8iLCJXYWxrIiwib25sb2FkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsU0FBUyxFQUFDSixFQUFFLENBQUNLO0FBREwsR0FIUDtBQU9MO0FBRUFDLEVBQUFBLEtBVEssbUJBU0k7QUFDTCxTQUFLRixTQUFMLEdBQWUsS0FBS0EsU0FBTCxDQUFlRyxZQUFmLENBQTRCLFdBQTVCLENBQWY7QUFDQSxTQUFLQyxZQUFMLENBQWtCLFlBQVc7QUFDekIsV0FBS0MsSUFBTCxDQUFVQyxTQUFWLENBQW9CVixFQUFFLENBQUNXLE1BQUgsQ0FBVSxHQUFWLEVBQWUsR0FBZixFQUFvQixDQUFwQixDQUFwQjtBQUNBLFdBQUtQLFNBQUwsQ0FBZVEsSUFBZixDQUFvQixLQUFLSCxJQUF6QixFQUE4QixDQUE5QixFQUFnQyxNQUFoQztBQUVILEtBSkQsRUFJRyxFQUpIO0FBS0EsU0FBS0QsWUFBTCxDQUFrQixZQUFXO0FBQ3pCLFdBQUtDLElBQUwsQ0FBVUMsU0FBVixDQUFvQlYsRUFBRSxDQUFDVyxNQUFILENBQVUsRUFBVixFQUFjLElBQWQsRUFBb0IsQ0FBcEIsQ0FBcEI7QUFDQSxXQUFLUCxTQUFMLENBQWVRLElBQWYsQ0FBb0IsS0FBS0gsSUFBekIsRUFBOEIsQ0FBOUIsRUFBZ0MsT0FBaEM7QUFHSCxLQUxELEVBS0csSUFMSDtBQU1BLFNBQUtELFlBQUwsQ0FBa0IsWUFBVztBQUV6QixXQUFLSixTQUFMLENBQWVRLElBQWYsQ0FBb0IsS0FBS0gsSUFBekIsRUFBOEIsQ0FBOUIsRUFBZ0MsTUFBaEM7QUFHSCxLQUxELEVBS0UsRUFMRjtBQU1ILEdBNUJJO0FBOEJMSSxFQUFBQSxNQTlCSyxvQkE4QkssQ0FFVCxDQWhDSSxDQWtDTDs7QUFsQ0ssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHVpY29udHJvbDpjYy5Ob2RlLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy51aWNvbnRyb2w9dGhpcy51aWNvbnRyb2wuZ2V0Q29tcG9uZW50KFwiVUljb250cm9sXCIpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucnVuQWN0aW9uKGNjLm1vdmVUbygzLjUsIDc4MCwgMCkpO1xyXG4gICAgICAgICAgICB0aGlzLnVpY29udHJvbC5XYWxrKHRoaXMubm9kZSwxLFwiZG93blwiKTtcclxuXHJcbiAgICAgICAgfSwgMTUpO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucnVuQWN0aW9uKGNjLm1vdmVUbyg0MCwgMjYwMCwgMCkpO1xyXG4gICAgICAgICAgICB0aGlzLnVpY29udHJvbC5XYWxrKHRoaXMubm9kZSwxLFwicmlnaHRcIik7XHJcblxyXG5cclxuICAgICAgICB9LCAxOC41KTtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMudWljb250cm9sLldhbGsodGhpcy5ub2RlLDEsXCJzdG9wXCIpO1xyXG5cclxuXHJcbiAgICAgICAgfSw2MCk7XHJcbiAgICB9LFxyXG5cclxuICAgIG9ubG9hZCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19