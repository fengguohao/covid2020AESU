
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/informationJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6a787iKsKtFkKKaxxg1E0E3', 'informationJS');
// 火车防护/scripts/informationJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    information01: {
      "default": null,
      type: cc.TextAsset
    },
    information02: {
      "default": null,
      type: cc.TextAsset
    },
    information03: {
      "default": null,
      type: cc.TextAsset
    },
    information04: {
      "default": null,
      type: cc.TextAsset
    },
    information05: {
      "default": null,
      type: cc.TextAsset
    },
    information06: {
      "default": null,
      type: cc.TextAsset
    },
    information: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var l = this.information.getComponent(cc.Label);
    l.string = "";
    var appear = cc.fadeTo(1.5, 200);
    var disappear = cc.fadeOut(1.5);
    var remain = cc.fadeTo(4, 200);
    var interval = cc.fadeTo(15, 0);
    var func1 = cc.callFunc(function () {
      l.string = this.information01.text;
    }.bind(this));
    var func2 = cc.callFunc(function () {
      l.string = this.information02.text;
    }.bind(this));
    var func3 = cc.callFunc(function () {
      l.string = this.information03.text;
    }.bind(this));
    var func4 = cc.callFunc(function () {
      l.string = this.information04.text;
    }.bind(this));
    var func5 = cc.callFunc(function () {
      l.string = this.information05.text;
    }.bind(this));
    var func6 = cc.callFunc(function () {
      l.string = this.information06.text;
    }.bind(this));
    this.node.runAction(cc.sequence([func1, appear, func1, remain, func2, remain, func3, remain, func4, remain, func5, remain, func6, remain, disappear, interval])).repeatForever();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxpbmZvcm1hdGlvbkpTLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiaW5mb3JtYXRpb24wMSIsInR5cGUiLCJUZXh0QXNzZXQiLCJpbmZvcm1hdGlvbjAyIiwiaW5mb3JtYXRpb24wMyIsImluZm9ybWF0aW9uMDQiLCJpbmZvcm1hdGlvbjA1IiwiaW5mb3JtYXRpb24wNiIsImluZm9ybWF0aW9uIiwiTm9kZSIsIm9uTG9hZCIsImwiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsImFwcGVhciIsImZhZGVUbyIsImRpc2FwcGVhciIsImZhZGVPdXQiLCJyZW1haW4iLCJpbnRlcnZhbCIsImZ1bmMxIiwiY2FsbEZ1bmMiLCJ0ZXh0IiwiYmluZCIsImZ1bmMyIiwiZnVuYzMiLCJmdW5jNCIsImZ1bmM1IiwiZnVuYzYiLCJub2RlIiwicnVuQWN0aW9uIiwic2VxdWVuY2UiLCJyZXBlYXRGb3JldmVyIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUVSQyxJQUFBQSxhQUFhLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVhDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZFLEtBRlA7QUFPUkMsSUFBQUEsYUFBYSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRSxLQVBQO0FBWVJFLElBQUFBLGFBQWEsRUFBRTtBQUNYLGlCQUFTLElBREU7QUFFWEgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkUsS0FaUDtBQWlCUkcsSUFBQUEsYUFBYSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRSxLQWpCUDtBQXNCUkksSUFBQUEsYUFBYSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRSxLQXRCUDtBQTJCUkssSUFBQUEsYUFBYSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYTixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRSxLQTNCUDtBQWdDUk0sSUFBQUEsV0FBVyxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ2E7QUFGQTtBQWhDTCxHQUhQO0FBeUNMO0FBRUFDLEVBQUFBLE1BM0NLLG9CQTJDSztBQUVOLFFBQUlDLENBQUMsR0FBRyxLQUFLSCxXQUFMLENBQWlCSSxZQUFqQixDQUE4QmhCLEVBQUUsQ0FBQ2lCLEtBQWpDLENBQVI7QUFDQUYsSUFBQUEsQ0FBQyxDQUFDRyxNQUFGLEdBQVcsRUFBWDtBQUVBLFFBQUlDLE1BQU0sR0FBR25CLEVBQUUsQ0FBQ29CLE1BQUgsQ0FBVSxHQUFWLEVBQWUsR0FBZixDQUFiO0FBQ0EsUUFBSUMsU0FBUyxHQUFHckIsRUFBRSxDQUFDc0IsT0FBSCxDQUFXLEdBQVgsQ0FBaEI7QUFDQSxRQUFJQyxNQUFNLEdBQUd2QixFQUFFLENBQUNvQixNQUFILENBQVUsQ0FBVixFQUFhLEdBQWIsQ0FBYjtBQUNBLFFBQUlJLFFBQVEsR0FBR3hCLEVBQUUsQ0FBQ29CLE1BQUgsQ0FBVSxFQUFWLEVBQWMsQ0FBZCxDQUFmO0FBRUEsUUFBSUssS0FBSyxHQUFHekIsRUFBRSxDQUFDMEIsUUFBSCxDQUFZLFlBQVc7QUFDL0JYLE1BQUFBLENBQUMsQ0FBQ0csTUFBRixHQUFXLEtBQUtkLGFBQUwsQ0FBbUJ1QixJQUE5QjtBQUNILEtBRnVCLENBRXRCQyxJQUZzQixDQUVqQixJQUZpQixDQUFaLENBQVo7QUFHQSxRQUFJQyxLQUFLLEdBQUc3QixFQUFFLENBQUMwQixRQUFILENBQVksWUFBVztBQUMvQlgsTUFBQUEsQ0FBQyxDQUFDRyxNQUFGLEdBQVcsS0FBS1gsYUFBTCxDQUFtQm9CLElBQTlCO0FBQ0gsS0FGdUIsQ0FFdEJDLElBRnNCLENBRWpCLElBRmlCLENBQVosQ0FBWjtBQUdBLFFBQUlFLEtBQUssR0FBRzlCLEVBQUUsQ0FBQzBCLFFBQUgsQ0FBWSxZQUFXO0FBQy9CWCxNQUFBQSxDQUFDLENBQUNHLE1BQUYsR0FBVyxLQUFLVixhQUFMLENBQW1CbUIsSUFBOUI7QUFDSCxLQUZ1QixDQUV0QkMsSUFGc0IsQ0FFakIsSUFGaUIsQ0FBWixDQUFaO0FBR0EsUUFBSUcsS0FBSyxHQUFHL0IsRUFBRSxDQUFDMEIsUUFBSCxDQUFZLFlBQVc7QUFDL0JYLE1BQUFBLENBQUMsQ0FBQ0csTUFBRixHQUFXLEtBQUtULGFBQUwsQ0FBbUJrQixJQUE5QjtBQUNILEtBRnVCLENBRXRCQyxJQUZzQixDQUVqQixJQUZpQixDQUFaLENBQVo7QUFHQSxRQUFJSSxLQUFLLEdBQUdoQyxFQUFFLENBQUMwQixRQUFILENBQVksWUFBVztBQUMvQlgsTUFBQUEsQ0FBQyxDQUFDRyxNQUFGLEdBQVcsS0FBS1IsYUFBTCxDQUFtQmlCLElBQTlCO0FBQ0gsS0FGdUIsQ0FFdEJDLElBRnNCLENBRWpCLElBRmlCLENBQVosQ0FBWjtBQUdBLFFBQUlLLEtBQUssR0FBR2pDLEVBQUUsQ0FBQzBCLFFBQUgsQ0FBWSxZQUFXO0FBQy9CWCxNQUFBQSxDQUFDLENBQUNHLE1BQUYsR0FBVyxLQUFLUCxhQUFMLENBQW1CZ0IsSUFBOUI7QUFDSCxLQUZ1QixDQUV0QkMsSUFGc0IsQ0FFakIsSUFGaUIsQ0FBWixDQUFaO0FBSUEsU0FBS00sSUFBTCxDQUFVQyxTQUFWLENBQW9CbkMsRUFBRSxDQUFDb0MsUUFBSCxDQUFZLENBQUNYLEtBQUQsRUFBUU4sTUFBUixFQUFnQk0sS0FBaEIsRUFDNUJGLE1BRDRCLEVBQ3BCTSxLQURvQixFQUNiTixNQURhLEVBQ0xPLEtBREssRUFDRVAsTUFERixFQUNVUSxLQURWLEVBQ2lCUixNQURqQixFQUU1QlMsS0FGNEIsRUFFckJULE1BRnFCLEVBRWJVLEtBRmEsRUFFTlYsTUFGTSxFQUVFRixTQUZGLEVBRWFHLFFBRmIsQ0FBWixDQUFwQixFQUV5RGEsYUFGekQ7QUFJSCxHQTVFSTtBQThFTEMsRUFBQUEsS0E5RUssbUJBOEVJLENBRVIsQ0FoRkksQ0FrRkw7O0FBbEZLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgICAgICBpbmZvcm1hdGlvbjAxOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjAyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjAzOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjA0OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjA1OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjA2OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBpbmZvcm1hdGlvbjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcblxyXG4gICAgICAgIHZhciBsID0gdGhpcy5pbmZvcm1hdGlvbi5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gICAgICAgIGwuc3RyaW5nID0gXCJcIjtcclxuXHJcbiAgICAgICAgdmFyIGFwcGVhciA9IGNjLmZhZGVUbygxLjUsIDIwMCk7XHJcbiAgICAgICAgdmFyIGRpc2FwcGVhciA9IGNjLmZhZGVPdXQoMS41KTtcclxuICAgICAgICB2YXIgcmVtYWluID0gY2MuZmFkZVRvKDQsIDIwMCk7XHJcbiAgICAgICAgdmFyIGludGVydmFsID0gY2MuZmFkZVRvKDE1LCAwKTtcclxuXHJcbiAgICAgICAgdmFyIGZ1bmMxID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGwuc3RyaW5nID0gdGhpcy5pbmZvcm1hdGlvbjAxLnRleHQ7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICB2YXIgZnVuYzIgPSBjYy5jYWxsRnVuYyhmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgbC5zdHJpbmcgPSB0aGlzLmluZm9ybWF0aW9uMDIudGV4dDtcclxuICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgIHZhciBmdW5jMyA9IGNjLmNhbGxGdW5jKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBsLnN0cmluZyA9IHRoaXMuaW5mb3JtYXRpb24wMy50ZXh0O1xyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcbiAgICAgICAgdmFyIGZ1bmM0ID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGwuc3RyaW5nID0gdGhpcy5pbmZvcm1hdGlvbjA0LnRleHQ7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICB2YXIgZnVuYzUgPSBjYy5jYWxsRnVuYyhmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgbC5zdHJpbmcgPSB0aGlzLmluZm9ybWF0aW9uMDUudGV4dDtcclxuICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgIHZhciBmdW5jNiA9IGNjLmNhbGxGdW5jKGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBsLnN0cmluZyA9IHRoaXMuaW5mb3JtYXRpb24wNi50ZXh0O1xyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoW2Z1bmMxLCBhcHBlYXIsIGZ1bmMxLCBcclxuICAgICAgICAgICAgcmVtYWluLCBmdW5jMiwgcmVtYWluLCBmdW5jMywgcmVtYWluLCBmdW5jNCwgcmVtYWluLCBcclxuICAgICAgICAgICAgZnVuYzUsIHJlbWFpbiwgZnVuYzYsIHJlbWFpbiwgZGlzYXBwZWFyLCBpbnRlcnZhbF0pKS5yZXBlYXRGb3JldmVyKCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==