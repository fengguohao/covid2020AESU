
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/oppositeOnceJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a4d149ukklFt4IgNcBTC9uK', 'oppositeOnceJS');
// 火车防护/scripts/oppositeOnceJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    promptBox: {
      "default": null,
      type: cc.Node
    },
    npc: {
      "default": null,
      type: cc.Node
    },
    control: {
      "default": null,
      type: cc.Node
    },
    OppositeOnce01: {
      "default": null,
      type: cc.TextAsset
    },
    OppositeOnce02: {
      "default": null,
      type: cc.TextAsset
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.promptBox.active = false;
    this.node.active = false;
    var oppositeOnce = this.node.getComponent(cc.Label);
    this.node.on("OppositeOnce01", function () {
      if (oppositeOnce !== null) {
        this.promptBox.active = true;
        this.node.active = true;
        cc.director.getScheduler().pauseTarget(this.npc);
        cc.director.getScheduler().pauseTarget(this.control);
        oppositeOnce.string = this.OppositeOnce01.text;
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
          this.node.dispatchEvent(new cc.Event.EventCustom("OppositeOnce02"));
        }, this);
      }
    }, this);
    this.node.on("OppositeOnce02", function () {
      if (oppositeOnce !== null) {
        oppositeOnce.string = this.OppositeOnce02.text;
        this.node.on(cc.Node.EventType.TOUCH_END, function () {
          this.node.dispatchEvent(new cc.Event.EventCustom("endOppositeOnce"));
        }, this);
      }
    }, this);
    this.node.on("endOppositeOnce", function () {
      oppositeOnce = null;
      this.promptBox.active = false;
      this.node.active = false;
      cc.director.getScheduler().resumeTarget(this.npc);
      cc.director.getScheduler().resumeTarget(this.control);
      this.node.off("OppositeOnce01", function () {
        if (oppositeOnce !== null) {
          this.node.active = true;
          oppositeOnce.string = this.OppositeOnce01.text;
          this.node.on(cc.Node.EventType.TOUCH_END, function () {
            this.node.dispatchEvent(new cc.Event.EventCustom("OppositeOnce02"));
          }, this);
        }
      }, this);
      this.node.off("OppositeOnce02", function () {
        if (oppositeOnce !== null) {
          oppositeOnce.string = this.OppositeOnce02.text;
          this.node.on(cc.Node.EventType.TOUCH_END, function () {
            this.node.dispatchEvent(new cc.Event.EventCustom("endOppositeOnce"));
          }, this);
        }
      }, this);
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxvcHBvc2l0ZU9uY2VKUy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInByb21wdEJveCIsInR5cGUiLCJOb2RlIiwibnBjIiwiY29udHJvbCIsIk9wcG9zaXRlT25jZTAxIiwiVGV4dEFzc2V0IiwiT3Bwb3NpdGVPbmNlMDIiLCJvbkxvYWQiLCJhY3RpdmUiLCJub2RlIiwib3Bwb3NpdGVPbmNlIiwiZ2V0Q29tcG9uZW50IiwiTGFiZWwiLCJvbiIsImRpcmVjdG9yIiwiZ2V0U2NoZWR1bGVyIiwicGF1c2VUYXJnZXQiLCJzdHJpbmciLCJ0ZXh0IiwiRXZlbnRUeXBlIiwiVE9VQ0hfRU5EIiwiZGlzcGF0Y2hFdmVudCIsIkV2ZW50IiwiRXZlbnRDdXN0b20iLCJyZXN1bWVUYXJnZXQiLCJvZmYiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBRVJDLElBQUFBLFNBQVMsRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkYsS0FGSDtBQU9SQyxJQUFBQSxHQUFHLEVBQUU7QUFDRCxpQkFBUyxJQURSO0FBRURGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZSLEtBUEc7QUFZUkUsSUFBQUEsT0FBTyxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSixLQVpEO0FBaUJSRyxJQUFBQSxjQUFjLEVBQUU7QUFDWixpQkFBUyxJQURHO0FBRVpKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVTtBQUZHLEtBakJSO0FBcUJSQyxJQUFBQSxjQUFjLEVBQUU7QUFDWixpQkFBUyxJQURHO0FBRVpOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVTtBQUZHO0FBckJSLEdBSFA7QUE4Qkw7QUFFQUUsRUFBQUEsTUFoQ0ssb0JBZ0NLO0FBRU4sU0FBS1IsU0FBTCxDQUFlUyxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS0MsSUFBTCxDQUFVRCxNQUFWLEdBQW1CLEtBQW5CO0FBQ0EsUUFBSUUsWUFBWSxHQUFHLEtBQUtELElBQUwsQ0FBVUUsWUFBVixDQUF1QmhCLEVBQUUsQ0FBQ2lCLEtBQTFCLENBQW5CO0FBRUEsU0FBS0gsSUFBTCxDQUFVSSxFQUFWLENBQWEsZ0JBQWIsRUFBK0IsWUFBVztBQUN0QyxVQUFHSCxZQUFZLEtBQUssSUFBcEIsRUFBMEI7QUFDdEIsYUFBS1gsU0FBTCxDQUFlUyxNQUFmLEdBQXdCLElBQXhCO0FBQ0EsYUFBS0MsSUFBTCxDQUFVRCxNQUFWLEdBQW1CLElBQW5CO0FBQ0FiLFFBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWUMsWUFBWixHQUEyQkMsV0FBM0IsQ0FBdUMsS0FBS2QsR0FBNUM7QUFDQVAsUUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxZQUFaLEdBQTJCQyxXQUEzQixDQUF1QyxLQUFLYixPQUE1QztBQUNBTyxRQUFBQSxZQUFZLENBQUNPLE1BQWIsR0FBc0IsS0FBS2IsY0FBTCxDQUFvQmMsSUFBMUM7QUFDQSxhQUFLVCxJQUFMLENBQVVJLEVBQVYsQ0FBYWxCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsU0FBL0IsRUFBMEMsWUFBVztBQUNqRCxlQUFLWCxJQUFMLENBQVVZLGFBQVYsQ0FBd0IsSUFBSTFCLEVBQUUsQ0FBQzJCLEtBQUgsQ0FBU0MsV0FBYixDQUF5QixnQkFBekIsQ0FBeEI7QUFDSCxTQUZELEVBRUcsSUFGSDtBQUdIO0FBQ0osS0FYRCxFQVdHLElBWEg7QUFhQSxTQUFLZCxJQUFMLENBQVVJLEVBQVYsQ0FBYSxnQkFBYixFQUErQixZQUFXO0FBQ3RDLFVBQUdILFlBQVksS0FBSyxJQUFwQixFQUEwQjtBQUN0QkEsUUFBQUEsWUFBWSxDQUFDTyxNQUFiLEdBQXNCLEtBQUtYLGNBQUwsQ0FBb0JZLElBQTFDO0FBQ0EsYUFBS1QsSUFBTCxDQUFVSSxFQUFWLENBQWFsQixFQUFFLENBQUNNLElBQUgsQ0FBUWtCLFNBQVIsQ0FBa0JDLFNBQS9CLEVBQTBDLFlBQVc7QUFDakQsZUFBS1gsSUFBTCxDQUFVWSxhQUFWLENBQXdCLElBQUkxQixFQUFFLENBQUMyQixLQUFILENBQVNDLFdBQWIsQ0FBeUIsaUJBQXpCLENBQXhCO0FBQ0gsU0FGRCxFQUVHLElBRkg7QUFHSDtBQUNKLEtBUEQsRUFPRyxJQVBIO0FBU0EsU0FBS2QsSUFBTCxDQUFVSSxFQUFWLENBQWEsaUJBQWIsRUFBZ0MsWUFBVztBQUN2Q0gsTUFBQUEsWUFBWSxHQUFHLElBQWY7QUFDQSxXQUFLWCxTQUFMLENBQWVTLE1BQWYsR0FBd0IsS0FBeEI7QUFDQSxXQUFLQyxJQUFMLENBQVVELE1BQVYsR0FBbUIsS0FBbkI7QUFDQWIsTUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxZQUFaLEdBQTJCUyxZQUEzQixDQUF3QyxLQUFLdEIsR0FBN0M7QUFDQVAsTUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxZQUFaLEdBQTJCUyxZQUEzQixDQUF3QyxLQUFLckIsT0FBN0M7QUFDQSxXQUFLTSxJQUFMLENBQVVnQixHQUFWLENBQWMsZ0JBQWQsRUFBZ0MsWUFBVztBQUN2QyxZQUFHZixZQUFZLEtBQUssSUFBcEIsRUFBMEI7QUFDdEIsZUFBS0QsSUFBTCxDQUFVRCxNQUFWLEdBQW1CLElBQW5CO0FBQ0FFLFVBQUFBLFlBQVksQ0FBQ08sTUFBYixHQUFzQixLQUFLYixjQUFMLENBQW9CYyxJQUExQztBQUNBLGVBQUtULElBQUwsQ0FBVUksRUFBVixDQUFhbEIsRUFBRSxDQUFDTSxJQUFILENBQVFrQixTQUFSLENBQWtCQyxTQUEvQixFQUEwQyxZQUFXO0FBQ2pELGlCQUFLWCxJQUFMLENBQVVZLGFBQVYsQ0FBd0IsSUFBSTFCLEVBQUUsQ0FBQzJCLEtBQUgsQ0FBU0MsV0FBYixDQUF5QixnQkFBekIsQ0FBeEI7QUFDSCxXQUZELEVBRUcsSUFGSDtBQUdIO0FBQ0osT0FSRCxFQVFHLElBUkg7QUFTQSxXQUFLZCxJQUFMLENBQVVnQixHQUFWLENBQWMsZ0JBQWQsRUFBZ0MsWUFBVztBQUN2QyxZQUFHZixZQUFZLEtBQUssSUFBcEIsRUFBMEI7QUFDdEJBLFVBQUFBLFlBQVksQ0FBQ08sTUFBYixHQUFzQixLQUFLWCxjQUFMLENBQW9CWSxJQUExQztBQUNBLGVBQUtULElBQUwsQ0FBVUksRUFBVixDQUFhbEIsRUFBRSxDQUFDTSxJQUFILENBQVFrQixTQUFSLENBQWtCQyxTQUEvQixFQUEwQyxZQUFXO0FBQ2pELGlCQUFLWCxJQUFMLENBQVVZLGFBQVYsQ0FBd0IsSUFBSTFCLEVBQUUsQ0FBQzJCLEtBQUgsQ0FBU0MsV0FBYixDQUF5QixpQkFBekIsQ0FBeEI7QUFDSCxXQUZELEVBRUcsSUFGSDtBQUdIO0FBQ0osT0FQRCxFQU9HLElBUEg7QUFRSCxLQXZCRCxFQXVCRyxJQXZCSDtBQXdCSCxHQXBGSTtBQXNGTEcsRUFBQUEsS0F0RkssbUJBc0ZJLENBRVIsQ0F4RkksQ0EwRkw7O0FBMUZLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcbiAgICAgICAgcHJvbXB0Qm94OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgbnBjOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgY29udHJvbDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIE9wcG9zaXRlT25jZTAxOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIE9wcG9zaXRlT25jZTAyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlRleHRBc3NldCxcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG5cclxuICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdmFyIG9wcG9zaXRlT25jZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUub24oXCJPcHBvc2l0ZU9uY2UwMVwiLCBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgaWYob3Bwb3NpdGVPbmNlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjYy5kaXJlY3Rvci5nZXRTY2hlZHVsZXIoKS5wYXVzZVRhcmdldCh0aGlzLm5wYyk7XHJcbiAgICAgICAgICAgICAgICBjYy5kaXJlY3Rvci5nZXRTY2hlZHVsZXIoKS5wYXVzZVRhcmdldCh0aGlzLmNvbnRyb2wpO1xyXG4gICAgICAgICAgICAgICAgb3Bwb3NpdGVPbmNlLnN0cmluZyA9IHRoaXMuT3Bwb3NpdGVPbmNlMDEudGV4dDtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbShcIk9wcG9zaXRlT25jZTAyXCIpKTtcclxuICAgICAgICAgICAgICAgIH0sIHRoaXMpO1xyXG4gICAgICAgICAgICB9ICAgICBcclxuICAgICAgICB9LCB0aGlzKTtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwiT3Bwb3NpdGVPbmNlMDJcIiwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGlmKG9wcG9zaXRlT25jZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgb3Bwb3NpdGVPbmNlLnN0cmluZyA9IHRoaXMuT3Bwb3NpdGVPbmNlMDIudGV4dDtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbShcImVuZE9wcG9zaXRlT25jZVwiKSk7XHJcbiAgICAgICAgICAgICAgICB9LCB0aGlzKTtcclxuICAgICAgICAgICAgfSAgICAgICAgICAgICAgIFxyXG4gICAgICAgIH0sIHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUub24oXCJlbmRPcHBvc2l0ZU9uY2VcIiwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIG9wcG9zaXRlT25jZSA9IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmdldFNjaGVkdWxlcigpLnJlc3VtZVRhcmdldCh0aGlzLm5wYyk7XHJcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmdldFNjaGVkdWxlcigpLnJlc3VtZVRhcmdldCh0aGlzLmNvbnRyb2wpO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUub2ZmKFwiT3Bwb3NpdGVPbmNlMDFcIiwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICBpZihvcHBvc2l0ZU9uY2UgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBvcHBvc2l0ZU9uY2Uuc3RyaW5nID0gdGhpcy5PcHBvc2l0ZU9uY2UwMS50ZXh0O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJPcHBvc2l0ZU9uY2UwMlwiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgICAgICAgICB9ICAgICBcclxuICAgICAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5vZmYoXCJPcHBvc2l0ZU9uY2UwMlwiLCBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIGlmKG9wcG9zaXRlT25jZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9wcG9zaXRlT25jZS5zdHJpbmcgPSB0aGlzLk9wcG9zaXRlT25jZTAyLnRleHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5kaXNwYXRjaEV2ZW50KG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbShcImVuZE9wcG9zaXRlT25jZVwiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgICAgICAgICB9ICAgXHJcbiAgICAgICAgICAgIH0sIHRoaXMpO1xyXG4gICAgICAgIH0sIHRoaXMpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==