
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/AudioMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '91104OkaT5E5L7dfOj2/lSz', 'AudioMgr');
// 火车防护/scripts/AudioMgr.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    trainMusic: {
      "default": null,
      type: cc.AudioClip
    },
    bump: {
      "default": null,
      type: cc.AudioClip
    },
    openDoor: {
      "default": null,
      type: cc.AudioClip
    },
    washHands: {
      "default": null,
      type: cc.AudioClip
    },
    toliet: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.maxNum = cc.audioEngine.getMaxAudioInstance();
    this.audioPool = [];
    console.log(cc.audioEngine); // check deprecated

    ['playMusic', 'playEffect'].forEach(function (name) {
      if (!cc.audioEngine[name]) {
        cc.warn('.' + name + ' is not found!');
      }
    });
  },
  start: function start() {},
  playMusic: function playMusic(name) {
    switch (name) {
      case "trainMusic":
        this.play(this.trainMusic);
        break;

      case "bump":
        this.play(this.bump);
        break;

      case "openDoor":
        this.play(this.openDoor);
        break;

      case "washHands":
        this.play(this.washHands);
        break;

      case "toliet":
        this.play(this.toliet);
        break;
    }

    console.log(name + "success");
  },
  stopAll: function stopAll() {
    cc.audioEngine.stopAll();
    this.audioPool = [];
  },
  play: function play(audio) {
    if (!audio || this.audioPool.length === this.maxNum) return;
    var id = cc.audioEngine.play(audio, false, 1);
    this.audioPool.push(id); // set finish callback

    cc.audioEngine.setFinishCallback(id, this.removeAudio.bind(this, id));
  },
  removeAudio: function removeAudio(id) {
    var idx = this.audioPool.indexOf(id);

    if (idx > -1) {
      this.audioPool.splice(idx, 1);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxBdWRpb01nci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInRyYWluTXVzaWMiLCJ0eXBlIiwiQXVkaW9DbGlwIiwiYnVtcCIsIm9wZW5Eb29yIiwid2FzaEhhbmRzIiwidG9saWV0Iiwib25Mb2FkIiwibWF4TnVtIiwiYXVkaW9FbmdpbmUiLCJnZXRNYXhBdWRpb0luc3RhbmNlIiwiYXVkaW9Qb29sIiwiY29uc29sZSIsImxvZyIsImZvckVhY2giLCJuYW1lIiwid2FybiIsInN0YXJ0IiwicGxheU11c2ljIiwicGxheSIsInN0b3BBbGwiLCJhdWRpbyIsImxlbmd0aCIsImlkIiwicHVzaCIsInNldEZpbmlzaENhbGxiYWNrIiwicmVtb3ZlQXVkaW8iLCJiaW5kIiwiaWR4IiwiaW5kZXhPZiIsInNwbGljZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBQztBQUNQLGlCQUFRLElBREQ7QUFFUEMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNO0FBRkQsS0FESDtBQUtSQyxJQUFBQSxJQUFJLEVBQUM7QUFDRCxpQkFBUSxJQURQO0FBRURGLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTTtBQUZQLEtBTEc7QUFTUkUsSUFBQUEsUUFBUSxFQUFDO0FBQ0wsaUJBQVEsSUFESDtBQUVMSCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ007QUFGSCxLQVREO0FBYVJHLElBQUFBLFNBQVMsRUFBQztBQUNOLGlCQUFRLElBREY7QUFFTkosTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNO0FBRkYsS0FiRjtBQWlCUkksSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ007QUFGTDtBQWpCQyxHQUhQO0FBNEJMO0FBRUNLLEVBQUFBLE1BOUJJLG9CQThCTTtBQUNQLFNBQUtDLE1BQUwsR0FBY1osRUFBRSxDQUFDYSxXQUFILENBQWVDLG1CQUFmLEVBQWQ7QUFDQSxTQUFLQyxTQUFMLEdBQWlCLEVBQWpCO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZakIsRUFBRSxDQUFDYSxXQUFmLEVBSE8sQ0FLUDs7QUFDQSxLQUFDLFdBQUQsRUFBYyxZQUFkLEVBQTRCSyxPQUE1QixDQUFvQyxVQUFVQyxJQUFWLEVBQWdCO0FBQ2hELFVBQUksQ0FBQ25CLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlTSxJQUFmLENBQUwsRUFBMkI7QUFDdkJuQixRQUFBQSxFQUFFLENBQUNvQixJQUFILENBQVEsTUFBTUQsSUFBTixHQUFhLGdCQUFyQjtBQUNIO0FBQ0osS0FKRDtBQU1GLEdBMUNHO0FBNENMRSxFQUFBQSxLQTVDSyxtQkE0Q0ksQ0FFUixDQTlDSTtBQWdETEMsRUFBQUEsU0FoREsscUJBZ0RLSCxJQWhETCxFQWdEVTtBQUNYLFlBQU9BLElBQVA7QUFDSSxXQUFLLFlBQUw7QUFDSSxhQUFLSSxJQUFMLENBQVUsS0FBS25CLFVBQWY7QUFDQTs7QUFDSixXQUFLLE1BQUw7QUFDSSxhQUFLbUIsSUFBTCxDQUFVLEtBQUtoQixJQUFmO0FBQ0E7O0FBQ0osV0FBSyxVQUFMO0FBQ0ksYUFBS2dCLElBQUwsQ0FBVSxLQUFLZixRQUFmO0FBQ0E7O0FBQ0osV0FBSyxXQUFMO0FBQ0ksYUFBS2UsSUFBTCxDQUFVLEtBQUtkLFNBQWY7QUFDQTs7QUFDSixXQUFLLFFBQUw7QUFDSSxhQUFLYyxJQUFMLENBQVUsS0FBS2IsTUFBZjtBQUNBO0FBZlI7O0FBaUJBTSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUUsSUFBSSxHQUFDLFNBQWpCO0FBQ0gsR0FuRUk7QUFvRUxLLEVBQUFBLE9BcEVLLHFCQW9FTTtBQUNQeEIsSUFBQUEsRUFBRSxDQUFDYSxXQUFILENBQWVXLE9BQWY7QUFDQSxTQUFLVCxTQUFMLEdBQWlCLEVBQWpCO0FBRUgsR0F4RUk7QUF5RUxRLEVBQUFBLElBekVLLGdCQXlFQ0UsS0F6RUQsRUF5RVE7QUFDVCxRQUFJLENBQUNBLEtBQUQsSUFBVSxLQUFLVixTQUFMLENBQWVXLE1BQWYsS0FBMEIsS0FBS2QsTUFBN0MsRUFBcUQ7QUFDckQsUUFBSWUsRUFBRSxHQUFHM0IsRUFBRSxDQUFDYSxXQUFILENBQWVVLElBQWYsQ0FBb0JFLEtBQXBCLEVBQTJCLEtBQTNCLEVBQWtDLENBQWxDLENBQVQ7QUFDQSxTQUFLVixTQUFMLENBQWVhLElBQWYsQ0FBb0JELEVBQXBCLEVBSFMsQ0FNVDs7QUFDQTNCLElBQUFBLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlZ0IsaUJBQWYsQ0FBaUNGLEVBQWpDLEVBQXFDLEtBQUtHLFdBQUwsQ0FBaUJDLElBQWpCLENBQXNCLElBQXRCLEVBQTRCSixFQUE1QixDQUFyQztBQUNILEdBakZJO0FBa0ZMRyxFQUFBQSxXQWxGSyx1QkFrRlFILEVBbEZSLEVBa0ZZO0FBQ2IsUUFBSUssR0FBRyxHQUFHLEtBQUtqQixTQUFMLENBQWVrQixPQUFmLENBQXVCTixFQUF2QixDQUFWOztBQUNBLFFBQUlLLEdBQUcsR0FBRyxDQUFDLENBQVgsRUFBYztBQUNWLFdBQUtqQixTQUFMLENBQWVtQixNQUFmLENBQXNCRixHQUF0QixFQUEyQixDQUEzQjtBQUNIO0FBRUo7QUF4RkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHRyYWluTXVzaWM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfSxcclxuICAgICAgICBidW1wOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb3BlbkRvb3I6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfSxcclxuICAgICAgICB3YXNoSGFuZHM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfSxcclxuICAgICAgICB0b2xpZXQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMubWF4TnVtID0gY2MuYXVkaW9FbmdpbmUuZ2V0TWF4QXVkaW9JbnN0YW5jZSgpO1xyXG4gICAgICAgIHRoaXMuYXVkaW9Qb29sID0gW107XHJcbiAgICAgICAgY29uc29sZS5sb2coY2MuYXVkaW9FbmdpbmUpO1xyXG4gXHJcbiAgICAgICAgLy8gY2hlY2sgZGVwcmVjYXRlZFxyXG4gICAgICAgIFsncGxheU11c2ljJywgJ3BsYXlFZmZlY3QnXS5mb3JFYWNoKGZ1bmN0aW9uIChuYW1lKSB7XHJcbiAgICAgICAgICAgIGlmICghY2MuYXVkaW9FbmdpbmVbbmFtZV0pIHtcclxuICAgICAgICAgICAgICAgIGNjLndhcm4oJy4nICsgbmFtZSArICcgaXMgbm90IGZvdW5kIScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICBwbGF5TXVzaWMobmFtZSl7XHJcbiAgICAgICAgc3dpdGNoKG5hbWUpe1xyXG4gICAgICAgICAgICBjYXNlIFwidHJhaW5NdXNpY1wiOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5wbGF5KHRoaXMudHJhaW5NdXNpYyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcImJ1bXBcIjpcclxuICAgICAgICAgICAgICAgIHRoaXMucGxheSh0aGlzLmJ1bXApO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJvcGVuRG9vclwiOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5wbGF5KHRoaXMub3BlbkRvb3IpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJ3YXNoSGFuZHNcIjpcclxuICAgICAgICAgICAgICAgIHRoaXMucGxheSh0aGlzLndhc2hIYW5kcyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcInRvbGlldFwiOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5wbGF5KHRoaXMudG9saWV0KTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZyhuYW1lK1wic3VjY2Vzc1wiKTtcclxuICAgIH0sXHJcbiAgICBzdG9wQWxsICgpIHtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wQWxsKCk7XHJcbiAgICAgICAgdGhpcy5hdWRpb1Bvb2wgPSBbXTtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBwbGF5IChhdWRpbykge1xyXG4gICAgICAgIGlmICghYXVkaW8gfHwgdGhpcy5hdWRpb1Bvb2wubGVuZ3RoID09PSB0aGlzLm1heE51bSkgcmV0dXJuO1xyXG4gICAgICAgIHZhciBpZCA9IGNjLmF1ZGlvRW5naW5lLnBsYXkoYXVkaW8sIGZhbHNlLCAxKTtcclxuICAgICAgICB0aGlzLmF1ZGlvUG9vbC5wdXNoKGlkKTtcclxuICAgICAgICBcclxuIFxyXG4gICAgICAgIC8vIHNldCBmaW5pc2ggY2FsbGJhY2tcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zZXRGaW5pc2hDYWxsYmFjayhpZCwgdGhpcy5yZW1vdmVBdWRpby5iaW5kKHRoaXMsIGlkKSk7XHJcbiAgICB9LFxyXG4gICAgcmVtb3ZlQXVkaW8gKGlkKSB7XHJcbiAgICAgICAgdmFyIGlkeCA9IHRoaXMuYXVkaW9Qb29sLmluZGV4T2YoaWQpO1xyXG4gICAgICAgIGlmIChpZHggPiAtMSkge1xyXG4gICAgICAgICAgICB0aGlzLmF1ZGlvUG9vbC5zcGxpY2UoaWR4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG59KTtcclxuIl19