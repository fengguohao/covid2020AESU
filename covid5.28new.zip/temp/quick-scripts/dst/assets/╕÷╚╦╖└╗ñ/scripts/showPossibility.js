
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/showPossibility.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e61c30+53VCb6McG/r/vpfR', 'showPossibility');
// 火车防护/scripts/showPossibility.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    showLabel: cc.Label,
    dataFrom: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    this.showLabel.string = "感染概率：\n" + this.dataFrom.getComponent("gamePlayer").infectPossibility + '%'
    /*+"  "+this.dataFrom.getComponent("gamePlayer").direction*/
    ;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxzaG93UG9zc2liaWxpdHkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzaG93TGFiZWwiLCJMYWJlbCIsImRhdGFGcm9tIiwiTm9kZSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiLCJzdHJpbmciLCJnZXRDb21wb25lbnQiLCJpbmZlY3RQb3NzaWJpbGl0eSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFNBQVMsRUFBQ0osRUFBRSxDQUFDSyxLQURMO0FBRVJDLElBQUFBLFFBQVEsRUFBQ04sRUFBRSxDQUFDTztBQUZKLEdBSFA7QUFRTDtBQUVBO0FBRUFDLEVBQUFBLEtBWkssbUJBWUksQ0FFUixDQWRJO0FBZ0JKQyxFQUFBQSxNQWhCSSxrQkFnQklDLEVBaEJKLEVBZ0JRO0FBQ1IsU0FBS04sU0FBTCxDQUFlTyxNQUFmLEdBQXNCLFlBQVUsS0FBS0wsUUFBTCxDQUFjTSxZQUFkLENBQTJCLFlBQTNCLEVBQXlDQyxpQkFBbkQsR0FBdUU7QUFBRztBQUFoRztBQUNIO0FBbEJHLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBzaG93TGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgZGF0YUZyb206Y2MuTm9kZVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICAgdGhpcy5zaG93TGFiZWwuc3RyaW5nPVwi5oSf5p+T5qaC546H77yaXFxuXCIrdGhpcy5kYXRhRnJvbS5nZXRDb21wb25lbnQoXCJnYW1lUGxheWVyXCIpLmluZmVjdFBvc3NpYmlsaXR5ICsgJyUnLyorXCIgIFwiK3RoaXMuZGF0YUZyb20uZ2V0Q29tcG9uZW50KFwiZ2FtZVBsYXllclwiKS5kaXJlY3Rpb24qLztcclxuICAgICB9LFxyXG59KTtcclxuIl19