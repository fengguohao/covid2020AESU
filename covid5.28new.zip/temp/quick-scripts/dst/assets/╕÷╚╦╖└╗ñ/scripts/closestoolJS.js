
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/closestoolJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd95b8+w+xxFqJeL9xaa5KiX', 'closestoolJS');
// 火车防护/scripts/closestoolJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    promptBox: {
      "default": null,
      type: cc.Node
    },
    buttonConfirm: {
      "default": null,
      type: cc.Node
    },
    show: {
      "default": null,
      type: cc.Node
    },
    controlLimit: {
      "default": null,
      type: cc.Node
    },
    control: {
      "default": null,
      type: cc.Node
    },
    gamePlayer: {
      "default": null,
      type: cc.Node
    },
    audioMgr: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onClick: function onClick() {
    var gamePlayer = this.gamePlayer.getComponent('gamePlayer');

    if (Math.abs(this.gamePlayer.x - this.node.x) <= 100 && Math.abs(this.gamePlayer.y - this.node.y) <= 40 && gamePlayer.direction === 'left' && gamePlayer.direction !== 'down') {
      this.control.x = this.control.getComponent('UIcontrol').defaultPos.x;
      this.control.y = this.control.getComponent('UIcontrol').defaultPos.y;
      this.controlLimit.active = false;
      this.control.getComponent('UIcontrol').ontouch = 0;
      this.promptBox.active = true;
      this.buttonConfirm.active = true;
      var tell = this.show.getComponent(cc.Label);
      tell.string = "你已如厕~";
      this.audioMgr.playMusic("toliet");
      this.gamePlayer.hasReleased = true;
    }
    /*
    cc.log("洗手池的位置：", this.node.x, this.node.y);
    cc.log("玩家的位置：", this.gamePlayer.x, this.gamePlayer.y);
    cc.log("坐标差的绝对值：", Math.abs(this.gamePlayer.x - this.node.x), Math.abs(this.gamePlayer.y - this.node.y));
    */

  },
  start: function start() {
    this.audioMgr = this.audioMgr.getComponent("AudioMgr");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxjbG9zZXN0b29sSlMuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwcm9tcHRCb3giLCJ0eXBlIiwiTm9kZSIsImJ1dHRvbkNvbmZpcm0iLCJzaG93IiwiY29udHJvbExpbWl0IiwiY29udHJvbCIsImdhbWVQbGF5ZXIiLCJhdWRpb01nciIsIm9uQ2xpY2siLCJnZXRDb21wb25lbnQiLCJNYXRoIiwiYWJzIiwieCIsIm5vZGUiLCJ5IiwiZGlyZWN0aW9uIiwiZGVmYXVsdFBvcyIsImFjdGl2ZSIsIm9udG91Y2giLCJ0ZWxsIiwiTGFiZWwiLCJzdHJpbmciLCJwbGF5TXVzaWMiLCJoYXNSZWxlYXNlZCIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFFUkMsSUFBQUEsU0FBUyxFQUFFO0FBQ1AsaUJBQVMsSUFERjtBQUVQQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRixLQUZIO0FBT1JDLElBQUFBLGFBQWEsRUFBRTtBQUNYLGlCQUFTLElBREU7QUFFWEYsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkUsS0FQUDtBQVlSRSxJQUFBQSxJQUFJLEVBQUU7QUFDRixpQkFBUyxJQURQO0FBRUZILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZQLEtBWkU7QUFpQlJHLElBQUFBLFlBQVksRUFBRTtBQUNWLGlCQUFTLElBREM7QUFFVkosTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkMsS0FqQk47QUFzQlJJLElBQUFBLE9BQU8sRUFBRTtBQUNMLGlCQUFTLElBREo7QUFFTEwsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkosS0F0QkQ7QUEyQlJLLElBQUFBLFVBQVUsRUFBRTtBQUNSLGlCQUFTLElBREQ7QUFFUk4sTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkQsS0EzQko7QUErQlJNLElBQUFBLFFBQVEsRUFBQztBQUNMLGlCQUFTLElBREo7QUFFTFAsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRko7QUEvQkQsR0FIUDtBQXlDTDtBQUVBO0FBRUFPLEVBQUFBLE9BQU8sRUFBRSxtQkFBVztBQUVoQixRQUFJRixVQUFVLEdBQUcsS0FBS0EsVUFBTCxDQUFnQkcsWUFBaEIsQ0FBNkIsWUFBN0IsQ0FBakI7O0FBRUEsUUFBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS0wsVUFBTCxDQUFnQk0sQ0FBaEIsR0FBb0IsS0FBS0MsSUFBTCxDQUFVRCxDQUF2QyxLQUE2QyxHQUE3QyxJQUFvREYsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS0wsVUFBTCxDQUFnQlEsQ0FBaEIsR0FBb0IsS0FBS0QsSUFBTCxDQUFVQyxDQUF2QyxLQUE2QyxFQUFqRyxJQUNBUixVQUFVLENBQUNTLFNBQVgsS0FBeUIsTUFEekIsSUFDbUNULFVBQVUsQ0FBQ1MsU0FBWCxLQUF5QixNQUQvRCxFQUN1RTtBQUNuRSxXQUFLVixPQUFMLENBQWFPLENBQWIsR0FBaUIsS0FBS1AsT0FBTCxDQUFhSSxZQUFiLENBQTBCLFdBQTFCLEVBQXVDTyxVQUF2QyxDQUFrREosQ0FBbkU7QUFDQSxXQUFLUCxPQUFMLENBQWFTLENBQWIsR0FBaUIsS0FBS1QsT0FBTCxDQUFhSSxZQUFiLENBQTBCLFdBQTFCLEVBQXVDTyxVQUF2QyxDQUFrREYsQ0FBbkU7QUFDQSxXQUFLVixZQUFMLENBQWtCYSxNQUFsQixHQUEyQixLQUEzQjtBQUNBLFdBQUtaLE9BQUwsQ0FBYUksWUFBYixDQUEwQixXQUExQixFQUF1Q1MsT0FBdkMsR0FBaUQsQ0FBakQ7QUFDQSxXQUFLbkIsU0FBTCxDQUFla0IsTUFBZixHQUF3QixJQUF4QjtBQUNBLFdBQUtmLGFBQUwsQ0FBbUJlLE1BQW5CLEdBQTRCLElBQTVCO0FBQ0EsVUFBSUUsSUFBSSxHQUFHLEtBQUtoQixJQUFMLENBQVVNLFlBQVYsQ0FBdUJkLEVBQUUsQ0FBQ3lCLEtBQTFCLENBQVg7QUFDQUQsTUFBQUEsSUFBSSxDQUFDRSxNQUFMLEdBQWMsT0FBZDtBQUNBLFdBQUtkLFFBQUwsQ0FBY2UsU0FBZCxDQUF3QixRQUF4QjtBQUNBLFdBQUtoQixVQUFMLENBQWdCaUIsV0FBaEIsR0FBOEIsSUFBOUI7QUFDSDtBQUVEOzs7Ozs7QUFLSCxHQXBFSTtBQXNFTEMsRUFBQUEsS0F0RUssbUJBc0VJO0FBQ0wsU0FBS2pCLFFBQUwsR0FBYyxLQUFLQSxRQUFMLENBQWNFLFlBQWQsQ0FBMkIsVUFBM0IsQ0FBZDtBQUNILEdBeEVJLENBMEVMOztBQTFFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgICAgIHByb21wdEJveDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGJ1dHRvbkNvbmZpcm06IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBzaG93OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgY29udHJvbExpbWl0OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgY29udHJvbDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGdhbWVQbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGF1ZGlvTWdyOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgb25DbGljazogZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgICAgIHZhciBnYW1lUGxheWVyID0gdGhpcy5nYW1lUGxheWVyLmdldENvbXBvbmVudCgnZ2FtZVBsYXllcicpO1xyXG5cclxuICAgICAgICBpZihNYXRoLmFicyh0aGlzLmdhbWVQbGF5ZXIueCAtIHRoaXMubm9kZS54KSA8PSAxMDAgJiYgTWF0aC5hYnModGhpcy5nYW1lUGxheWVyLnkgLSB0aGlzLm5vZGUueSkgPD0gNDAgXHJcbiAgICAgICAgJiYgZ2FtZVBsYXllci5kaXJlY3Rpb24gPT09ICdsZWZ0JyAmJiBnYW1lUGxheWVyLmRpcmVjdGlvbiAhPT0gJ2Rvd24nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC54ID0gdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykuZGVmYXVsdFBvcy54O1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRyb2wueSA9IHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLmRlZmF1bHRQb3MueTtcclxuICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLm9udG91Y2ggPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbkNvbmZpcm0uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdmFyIHRlbGwgPSB0aGlzLnNob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuICAgICAgICAgICAgdGVsbC5zdHJpbmcgPSBcIuS9oOW3suWmguWOlX5cIjtcclxuICAgICAgICAgICAgdGhpcy5hdWRpb01nci5wbGF5TXVzaWMoXCJ0b2xpZXRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuZ2FtZVBsYXllci5oYXNSZWxlYXNlZCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvKlxyXG4gICAgICAgIGNjLmxvZyhcIua0l+aJi+axoOeahOS9jee9ru+8mlwiLCB0aGlzLm5vZGUueCwgdGhpcy5ub2RlLnkpO1xyXG4gICAgICAgIGNjLmxvZyhcIueOqeWutueahOS9jee9ru+8mlwiLCB0aGlzLmdhbWVQbGF5ZXIueCwgdGhpcy5nYW1lUGxheWVyLnkpO1xyXG4gICAgICAgIGNjLmxvZyhcIuWdkOagh+W3rueahOe7neWvueWAvO+8mlwiLCBNYXRoLmFicyh0aGlzLmdhbWVQbGF5ZXIueCAtIHRoaXMubm9kZS54KSwgTWF0aC5hYnModGhpcy5nYW1lUGxheWVyLnkgLSB0aGlzLm5vZGUueSkpO1xyXG4gICAgICAgICovXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLmF1ZGlvTWdyPXRoaXMuYXVkaW9NZ3IuZ2V0Q29tcG9uZW50KFwiQXVkaW9NZ3JcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19