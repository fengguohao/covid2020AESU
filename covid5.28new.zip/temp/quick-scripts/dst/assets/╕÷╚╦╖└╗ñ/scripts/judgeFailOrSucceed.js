
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/judgeFailOrSucceed.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '84f1892Iv5Ch4zKLoc1+buU', 'judgeFailOrSucceed');
// 个人防护/scripts/judgeFailOrSucceed.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    gamePlayer: {
      "default": null,
      type: cc.Node
    },
    promptBox: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  judgeFail: function judgeFail() {
    /*
    var flag = false;
    if(this.gamePlayer.getComponent('gamePlayer').infectPossibility >= 40) {
        flag = true;
    }
    if(780 <= this.gamePlayer.x && this.gamePlayer.x <= 890 &&
    170 <= this.gamePlayer.y && this.gamePlayer.y <= 240) {
        if(this.gamePlayer.getComponent('gamePlayer').hasReleased === true) {
            if(this.gamePlayer.getComponent('gamePlayer').hasWashedHandsBefore === false ||
            this.gamePlayer.getComponent('gamePlayer').hasWashedHandsAfter) {
                flag = true;
            }
        }
    }
    if(flag === true) {
        this.promptBox.active = true;
        this.promptBox.getChildByName('show').getComponent(cc.Label).string = 'fail';
        this.promptBox.getChildByName('buttonConfirm').active = true;
    }
    */
    if (this.gamePlayer.getComponent('gamePlayer').infectPossibility >= 40) {
      this.promptBox.active = true;
      this.promptBox.getChildByName('show').getComponent(cc.Label).string = '你的染病概率已经很高了，请重新再来！';
      this.promptBox.getChildByName('buttonConfirm').active = true;
      this.promptBox.getChildByName('buttonConfirm').on(cc.Node.EventType.TOUCH_END, function () {
        cc.director.loadScene('衔接场景');
      }.bind(this));
    }

    if (780 <= this.gamePlayer.x && this.gamePlayer.x <= 890 && 170 <= this.gamePlayer.y && this.gamePlayer.y <= 240 && this.gamePlayer.getComponent('gamePlayer').hasReleased === true) {
      if (this.gamePlayer.getComponent('gamePlayer').hasWashedHandsBefore === false) {
        this.promptBox.active = true;
        this.promptBox.getChildByName('show').getComponent(cc.Label).string = '推开卫生间的门时可能会沾染到病毒，如厕前请洗手，此次游戏失败~';
        this.promptBox.getChildByName('buttonConfirm').active = true;
        this.promptBox.getChildByName('buttonConfirm').on(cc.Node.EventType.TOUCH_END, function () {
          cc.director.loadScene('衔接场景');
        }.bind(this));
      } else if (this.gamePlayer.getComponent('gamePlayer').hasWashedHandsAfter === false) {
        this.promptBox.active = true;
        this.promptBox.getChildByName('show').getComponent(cc.Label).string = '推开卫生间的门时可能会沾染到病毒，如厕后忘记洗手了哦，此次游戏失败~';
        this.promptBox.getChildByName('buttonConfirm').active = true;
        this.promptBox.getChildByName('buttonConfirm').on(cc.Node.EventType.TOUCH_END, function () {
          cc.director.loadScene('衔接场景');
        }.bind(this));
      }
    }
  },
  judgeSucceed: function judgeSucceed() {
    if (780 <= this.gamePlayer.x && this.gamePlayer.x <= 890 && 170 <= this.gamePlayer.y && this.gamePlayer.y <= 240 && this.gamePlayer.getComponent('gamePlayer').hasReleased === true && this.gamePlayer.getComponent('gamePlayer').hasWashedHandsBefore === true && this.gamePlayer.getComponent('gamePlayer').hasWashedHandsAfter === true) {
      this.promptBox.active = true;
      this.promptBox.getChildByName('show').getComponent(cc.Label).string = '恭喜你达成了目标，防护成功！';
      this.promptBox.getChildByName('buttonConfirm').active = true;
      this.promptBox.getChildByName('buttonConfirm').on(cc.Node.EventType.TOUCH_END, function () {
        cc.director.loadScene('衔接场景');
      }.bind(this));
    }
  },
  onClickReturn: function onClickReturn() {
    cc.director.loadScene('衔接场景');
  },
  update: function update(dt) {
    this.judgeFail();
    this.judgeSucceed();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5Liq5Lq66Ziy5oqkXFxzY3JpcHRzXFxqdWRnZUZhaWxPclN1Y2NlZWQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJnYW1lUGxheWVyIiwidHlwZSIsIk5vZGUiLCJwcm9tcHRCb3giLCJzdGFydCIsImp1ZGdlRmFpbCIsImdldENvbXBvbmVudCIsImluZmVjdFBvc3NpYmlsaXR5IiwiYWN0aXZlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJMYWJlbCIsInN0cmluZyIsIm9uIiwiRXZlbnRUeXBlIiwiVE9VQ0hfRU5EIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJiaW5kIiwieCIsInkiLCJoYXNSZWxlYXNlZCIsImhhc1dhc2hlZEhhbmRzQmVmb3JlIiwiaGFzV2FzaGVkSGFuZHNBZnRlciIsImp1ZGdlU3VjY2VlZCIsIm9uQ2xpY2tSZXR1cm4iLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBRTtBQUNSLGlCQUFTLElBREQ7QUFFUkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkQsS0FESjtBQUtSQyxJQUFBQSxTQUFTLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZGO0FBTEgsR0FIUDtBQWNMO0FBRUE7QUFFQUUsRUFBQUEsS0FsQkssbUJBa0JJLENBRVIsQ0FwQkk7QUFzQkxDLEVBQUFBLFNBQVMsRUFBRSxxQkFBVztBQUNsQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsUUFBRyxLQUFLTCxVQUFMLENBQWdCTSxZQUFoQixDQUE2QixZQUE3QixFQUEyQ0MsaUJBQTNDLElBQWdFLEVBQW5FLEVBQXVFO0FBQ25FLFdBQUtKLFNBQUwsQ0FBZUssTUFBZixHQUF3QixJQUF4QjtBQUNBLFdBQUtMLFNBQUwsQ0FBZU0sY0FBZixDQUE4QixNQUE5QixFQUFzQ0gsWUFBdEMsQ0FBbURWLEVBQUUsQ0FBQ2MsS0FBdEQsRUFBNkRDLE1BQTdELEdBQXNFLG9CQUF0RTtBQUNBLFdBQUtSLFNBQUwsQ0FBZU0sY0FBZixDQUE4QixlQUE5QixFQUErQ0QsTUFBL0MsR0FBd0QsSUFBeEQ7QUFDQSxXQUFLTCxTQUFMLENBQWVNLGNBQWYsQ0FBOEIsZUFBOUIsRUFBK0NHLEVBQS9DLENBQWtEaEIsRUFBRSxDQUFDTSxJQUFILENBQVFXLFNBQVIsQ0FBa0JDLFNBQXBFLEVBQStFLFlBQVc7QUFDdEZsQixRQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSCxPQUY4RSxDQUU3RUMsSUFGNkUsQ0FFeEUsSUFGd0UsQ0FBL0U7QUFHSDs7QUFDRCxRQUFHLE9BQU8sS0FBS2pCLFVBQUwsQ0FBZ0JrQixDQUF2QixJQUE0QixLQUFLbEIsVUFBTCxDQUFnQmtCLENBQWhCLElBQXFCLEdBQWpELElBQ0gsT0FBTyxLQUFLbEIsVUFBTCxDQUFnQm1CLENBRHBCLElBQ3lCLEtBQUtuQixVQUFMLENBQWdCbUIsQ0FBaEIsSUFBcUIsR0FEOUMsSUFDcUQsS0FBS25CLFVBQUwsQ0FBZ0JNLFlBQWhCLENBQTZCLFlBQTdCLEVBQTJDYyxXQUEzQyxLQUEyRCxJQURuSCxFQUN5SDtBQUNySCxVQUFHLEtBQUtwQixVQUFMLENBQWdCTSxZQUFoQixDQUE2QixZQUE3QixFQUEyQ2Usb0JBQTNDLEtBQW9FLEtBQXZFLEVBQThFO0FBQzFFLGFBQUtsQixTQUFMLENBQWVLLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxhQUFLTCxTQUFMLENBQWVNLGNBQWYsQ0FBOEIsTUFBOUIsRUFBc0NILFlBQXRDLENBQW1EVixFQUFFLENBQUNjLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxpQ0FBdEU7QUFDQSxhQUFLUixTQUFMLENBQWVNLGNBQWYsQ0FBOEIsZUFBOUIsRUFBK0NELE1BQS9DLEdBQXdELElBQXhEO0FBQ0EsYUFBS0wsU0FBTCxDQUFlTSxjQUFmLENBQThCLGVBQTlCLEVBQStDRyxFQUEvQyxDQUFrRGhCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRVyxTQUFSLENBQWtCQyxTQUFwRSxFQUErRSxZQUFXO0FBQ3RGbEIsVUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsU0FGOEUsQ0FFN0VDLElBRjZFLENBRXhFLElBRndFLENBQS9FO0FBR0gsT0FQRCxNQU9PLElBQUcsS0FBS2pCLFVBQUwsQ0FBZ0JNLFlBQWhCLENBQTZCLFlBQTdCLEVBQTJDZ0IsbUJBQTNDLEtBQW1FLEtBQXRFLEVBQTZFO0FBQ2hGLGFBQUtuQixTQUFMLENBQWVLLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxhQUFLTCxTQUFMLENBQWVNLGNBQWYsQ0FBOEIsTUFBOUIsRUFBc0NILFlBQXRDLENBQW1EVixFQUFFLENBQUNjLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxvQ0FBdEU7QUFDQSxhQUFLUixTQUFMLENBQWVNLGNBQWYsQ0FBOEIsZUFBOUIsRUFBK0NELE1BQS9DLEdBQXdELElBQXhEO0FBQ0EsYUFBS0wsU0FBTCxDQUFlTSxjQUFmLENBQThCLGVBQTlCLEVBQStDRyxFQUEvQyxDQUFrRGhCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRVyxTQUFSLENBQWtCQyxTQUFwRSxFQUErRSxZQUFXO0FBQ3RGbEIsVUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsU0FGOEUsQ0FFN0VDLElBRjZFLENBRXhFLElBRndFLENBQS9FO0FBR0g7QUFDSjtBQUVKLEdBdEVJO0FBd0VMTSxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDckIsUUFBRyxPQUFPLEtBQUt2QixVQUFMLENBQWdCa0IsQ0FBdkIsSUFBNEIsS0FBS2xCLFVBQUwsQ0FBZ0JrQixDQUFoQixJQUFxQixHQUFqRCxJQUNILE9BQU8sS0FBS2xCLFVBQUwsQ0FBZ0JtQixDQURwQixJQUN5QixLQUFLbkIsVUFBTCxDQUFnQm1CLENBQWhCLElBQXFCLEdBRDlDLElBRUgsS0FBS25CLFVBQUwsQ0FBZ0JNLFlBQWhCLENBQTZCLFlBQTdCLEVBQTJDYyxXQUEzQyxLQUEyRCxJQUZ4RCxJQUdILEtBQUtwQixVQUFMLENBQWdCTSxZQUFoQixDQUE2QixZQUE3QixFQUEyQ2Usb0JBQTNDLEtBQW9FLElBSGpFLElBSUgsS0FBS3JCLFVBQUwsQ0FBZ0JNLFlBQWhCLENBQTZCLFlBQTdCLEVBQTJDZ0IsbUJBQTNDLEtBQW1FLElBSm5FLEVBSXlFO0FBQ3JFLFdBQUtuQixTQUFMLENBQWVLLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxXQUFLTCxTQUFMLENBQWVNLGNBQWYsQ0FBOEIsTUFBOUIsRUFBc0NILFlBQXRDLENBQW1EVixFQUFFLENBQUNjLEtBQXRELEVBQTZEQyxNQUE3RCxHQUFzRSxnQkFBdEU7QUFDQSxXQUFLUixTQUFMLENBQWVNLGNBQWYsQ0FBOEIsZUFBOUIsRUFBK0NELE1BQS9DLEdBQXdELElBQXhEO0FBQ0EsV0FBS0wsU0FBTCxDQUFlTSxjQUFmLENBQThCLGVBQTlCLEVBQStDRyxFQUEvQyxDQUFrRGhCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRVyxTQUFSLENBQWtCQyxTQUFwRSxFQUErRSxZQUFXO0FBQ3RGbEIsUUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsT0FGOEUsQ0FFN0VDLElBRjZFLENBRXhFLElBRndFLENBQS9FO0FBR0g7QUFDSixHQXJGSTtBQXVGTE8sRUFBQUEsYUFBYSxFQUFFLHlCQUFXO0FBQ3RCNUIsSUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0F6Rkk7QUEyRkxTLEVBQUFBLE1BM0ZLLGtCQTJGR0MsRUEzRkgsRUEyRk87QUFDUixTQUFLckIsU0FBTDtBQUNBLFNBQUtrQixZQUFMO0FBQ0g7QUE5RkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGdhbWVQbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHByb21wdEJveDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIGp1ZGdlRmFpbDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgLypcclxuICAgICAgICB2YXIgZmxhZyA9IGZhbHNlO1xyXG4gICAgICAgIGlmKHRoaXMuZ2FtZVBsYXllci5nZXRDb21wb25lbnQoJ2dhbWVQbGF5ZXInKS5pbmZlY3RQb3NzaWJpbGl0eSA+PSA0MCkge1xyXG4gICAgICAgICAgICBmbGFnID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoNzgwIDw9IHRoaXMuZ2FtZVBsYXllci54ICYmIHRoaXMuZ2FtZVBsYXllci54IDw9IDg5MCAmJlxyXG4gICAgICAgIDE3MCA8PSB0aGlzLmdhbWVQbGF5ZXIueSAmJiB0aGlzLmdhbWVQbGF5ZXIueSA8PSAyNDApIHtcclxuICAgICAgICAgICAgaWYodGhpcy5nYW1lUGxheWVyLmdldENvbXBvbmVudCgnZ2FtZVBsYXllcicpLmhhc1JlbGVhc2VkID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJykuaGFzV2FzaGVkSGFuZHNCZWZvcmUgPT09IGZhbHNlIHx8XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJykuaGFzV2FzaGVkSGFuZHNBZnRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKGZsYWcgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ3Nob3cnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9ICdmYWlsJztcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ2J1dHRvbkNvbmZpcm0nKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAqL1xyXG4gICAgICAgIGlmKHRoaXMuZ2FtZVBsYXllci5nZXRDb21wb25lbnQoJ2dhbWVQbGF5ZXInKS5pbmZlY3RQb3NzaWJpbGl0eSA+PSA0MCkge1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5nZXRDaGlsZEJ5TmFtZSgnc2hvdycpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+S9oOeahOafk+eXheamgueOh+W3sue7j+W+iOmrmOS6hu+8jOivt+mHjeaWsOWGjeadpe+8gSc7XHJcbiAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmdldENoaWxkQnlOYW1lKCdidXR0b25Db25maXJtJykuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ2J1dHRvbkNvbmZpcm0nKS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfooZTmjqXlnLrmma8nKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKTsgICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoNzgwIDw9IHRoaXMuZ2FtZVBsYXllci54ICYmIHRoaXMuZ2FtZVBsYXllci54IDw9IDg5MCAmJlxyXG4gICAgICAgIDE3MCA8PSB0aGlzLmdhbWVQbGF5ZXIueSAmJiB0aGlzLmdhbWVQbGF5ZXIueSA8PSAyNDAgJiYgdGhpcy5nYW1lUGxheWVyLmdldENvbXBvbmVudCgnZ2FtZVBsYXllcicpLmhhc1JlbGVhc2VkID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuZ2FtZVBsYXllci5nZXRDb21wb25lbnQoJ2dhbWVQbGF5ZXInKS5oYXNXYXNoZWRIYW5kc0JlZm9yZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5nZXRDaGlsZEJ5TmFtZSgnc2hvdycpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+aOqOW8gOWNq+eUn+mXtOeahOmXqOaXtuWPr+iDveS8muayvuafk+WIsOeXheavku+8jOWmguWOleWJjeivt+a0l+aJi++8jOatpOasoea4uOaIj+Wksei0pX4nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ2J1dHRvbkNvbmZpcm0nKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ2J1dHRvbkNvbmZpcm0nKS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgn6KGU5o6l5Zy65pmvJyk7XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcykpOyAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSBlbHNlIGlmKHRoaXMuZ2FtZVBsYXllci5nZXRDb21wb25lbnQoJ2dhbWVQbGF5ZXInKS5oYXNXYXNoZWRIYW5kc0FmdGVyID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmdldENoaWxkQnlOYW1lKCdzaG93JykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAn5o6o5byA5Y2r55Sf6Ze055qE6Zeo5pe25Y+v6IO95Lya5rK+5p+T5Yiw55eF5q+S77yM5aaC5Y6V5ZCO5b+Y6K6w5rSX5omL5LqG5ZOm77yM5q2k5qyh5ri45oiP5aSx6LSlfic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5nZXRDaGlsZEJ5TmFtZSgnYnV0dG9uQ29uZmlybScpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5nZXRDaGlsZEJ5TmFtZSgnYnV0dG9uQ29uZmlybScpLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfooZTmjqXlnLrmma8nKTtcclxuICAgICAgICAgICAgICAgIH0uYmluZCh0aGlzKSk7ICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSAgICAgICBcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIGp1ZGdlU3VjY2VlZDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgaWYoNzgwIDw9IHRoaXMuZ2FtZVBsYXllci54ICYmIHRoaXMuZ2FtZVBsYXllci54IDw9IDg5MCAmJlxyXG4gICAgICAgIDE3MCA8PSB0aGlzLmdhbWVQbGF5ZXIueSAmJiB0aGlzLmdhbWVQbGF5ZXIueSA8PSAyNDAgJiZcclxuICAgICAgICB0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJykuaGFzUmVsZWFzZWQgPT09IHRydWUgJiZcclxuICAgICAgICB0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJykuaGFzV2FzaGVkSGFuZHNCZWZvcmUgPT09IHRydWUgJiZcclxuICAgICAgICB0aGlzLmdhbWVQbGF5ZXIuZ2V0Q29tcG9uZW50KCdnYW1lUGxheWVyJykuaGFzV2FzaGVkSGFuZHNBZnRlciA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLnByb21wdEJveC5nZXRDaGlsZEJ5TmFtZSgnc2hvdycpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+aBreWWnOS9oOi+vuaIkOS6huebruagh++8jOmYsuaKpOaIkOWKn++8gSc7XHJcbiAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmdldENoaWxkQnlOYW1lKCdidXR0b25Db25maXJtJykuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHRCb3guZ2V0Q2hpbGRCeU5hbWUoJ2J1dHRvbkNvbmZpcm0nKS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfooZTmjqXlnLrmma8nKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKTsgICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ2xpY2tSZXR1cm46IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgn6KGU5o6l5Zy65pmvJyk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmp1ZGdlRmFpbCgpO1xyXG4gICAgICAgIHRoaXMuanVkZ2VTdWNjZWVkKCk7XHJcbiAgICB9LFxyXG59KTtcclxuIl19