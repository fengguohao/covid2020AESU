
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/propTool.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4f4dblGNElDHYomZRGKtF0X', 'propTool');
// 火车防护/scripts/propTool.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    speed: cc.Node,
    selectRet: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.timeDur1 = 15;
    this.timeDur2 = 13;
    this.speed.getComponent(cc.Button).interactable = false;
    this.speed.opacity = 60;
    this.selectRet.getComponent(cc.Button).interactable = false;
    this.selectRet.opacity = 60;
    this.speed.getComponent(cc.Button).schedule(function () {
      if (this.speed.getComponent(cc.Button).interactable == false) {
        if (Math.random() > 0.4) {
          this.speed.getComponent(cc.Button).interactable = true;
          this.speed.opacity = 255;
          cc.director.getScheduler().pauseTarget(this.speed.getComponent(cc.Button));
        }
      }
    }.bind(this), this.timeDur1);
    this.selectRet.getComponent(cc.Button).schedule(function () {
      if (this.selectRet.getComponent(cc.Button).interactable == false) {
        if (Math.random() > 0.4) {
          this.selectRet.getComponent(cc.Button).interactable = true;
          this.selectRet.opacity = 255;
          cc.director.getScheduler().pauseTarget(this.selectRet.getComponent(cc.Button));
        }
      }
    }.bind(this), this.timeDur2);
  },
  onClickFunSpeed: function onClickFunSpeed() {
    this.speed.getComponent(cc.Button).interactable = false;
    this.speed.opacity = 60;
    cc.director.getScheduler().resumeTarget(this.speed.getComponent(cc.Button));
  },
  onClickFunRet: function onClickFunRet() {
    this.selectRet.getComponent(cc.Button).interactable = false;
    this.selectRet.opacity = 60;
    cc.director.getScheduler().resumeTarget(this.selectRet.getComponent(cc.Button));
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxwcm9wVG9vbC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNwZWVkIiwiTm9kZSIsInNlbGVjdFJldCIsInN0YXJ0IiwidGltZUR1cjEiLCJ0aW1lRHVyMiIsImdldENvbXBvbmVudCIsIkJ1dHRvbiIsImludGVyYWN0YWJsZSIsIm9wYWNpdHkiLCJzY2hlZHVsZSIsIk1hdGgiLCJyYW5kb20iLCJkaXJlY3RvciIsImdldFNjaGVkdWxlciIsInBhdXNlVGFyZ2V0IiwiYmluZCIsIm9uQ2xpY2tGdW5TcGVlZCIsInJlc3VtZVRhcmdldCIsIm9uQ2xpY2tGdW5SZXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUVSQyxJQUFBQSxLQUFLLEVBQUNKLEVBQUUsQ0FBQ0ssSUFGRDtBQUdSQyxJQUFBQSxTQUFTLEVBQUNOLEVBQUUsQ0FBQ0s7QUFITCxHQUhQO0FBVUw7QUFFQTtBQUVBRSxFQUFBQSxLQWRLLG1CQWNJO0FBQ0wsU0FBS0MsUUFBTCxHQUFjLEVBQWQ7QUFDQSxTQUFLQyxRQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUtMLEtBQUwsQ0FBV00sWUFBWCxDQUF3QlYsRUFBRSxDQUFDVyxNQUEzQixFQUFtQ0MsWUFBbkMsR0FBZ0QsS0FBaEQ7QUFDQSxTQUFLUixLQUFMLENBQVdTLE9BQVgsR0FBbUIsRUFBbkI7QUFDQSxTQUFLUCxTQUFMLENBQWVJLFlBQWYsQ0FBNEJWLEVBQUUsQ0FBQ1csTUFBL0IsRUFBdUNDLFlBQXZDLEdBQW9ELEtBQXBEO0FBQ0EsU0FBS04sU0FBTCxDQUFlTyxPQUFmLEdBQXVCLEVBQXZCO0FBSUEsU0FBS1QsS0FBTCxDQUFXTSxZQUFYLENBQXdCVixFQUFFLENBQUNXLE1BQTNCLEVBQW1DRyxRQUFuQyxDQUE0QyxZQUFVO0FBQ2xELFVBQUcsS0FBS1YsS0FBTCxDQUFXTSxZQUFYLENBQXdCVixFQUFFLENBQUNXLE1BQTNCLEVBQW1DQyxZQUFuQyxJQUFpRCxLQUFwRCxFQUEwRDtBQUN0RCxZQUFHRyxJQUFJLENBQUNDLE1BQUwsS0FBYyxHQUFqQixFQUFxQjtBQUNqQixlQUFLWixLQUFMLENBQVdNLFlBQVgsQ0FBd0JWLEVBQUUsQ0FBQ1csTUFBM0IsRUFBbUNDLFlBQW5DLEdBQWdELElBQWhEO0FBQ0EsZUFBS1IsS0FBTCxDQUFXUyxPQUFYLEdBQW1CLEdBQW5CO0FBQ0FiLFVBQUFBLEVBQUUsQ0FBQ2lCLFFBQUgsQ0FBWUMsWUFBWixHQUEyQkMsV0FBM0IsQ0FBdUMsS0FBS2YsS0FBTCxDQUFXTSxZQUFYLENBQXdCVixFQUFFLENBQUNXLE1BQTNCLENBQXZDO0FBRUg7QUFDSjtBQUVKLEtBVjJDLENBVTFDUyxJQVYwQyxDQVVyQyxJQVZxQyxDQUE1QyxFQVVhLEtBQUtaLFFBVmxCO0FBV0EsU0FBS0YsU0FBTCxDQUFlSSxZQUFmLENBQTRCVixFQUFFLENBQUNXLE1BQS9CLEVBQXVDRyxRQUF2QyxDQUFnRCxZQUFVO0FBQ3RELFVBQUcsS0FBS1IsU0FBTCxDQUFlSSxZQUFmLENBQTRCVixFQUFFLENBQUNXLE1BQS9CLEVBQXVDQyxZQUF2QyxJQUFxRCxLQUF4RCxFQUE4RDtBQUMxRCxZQUFHRyxJQUFJLENBQUNDLE1BQUwsS0FBYyxHQUFqQixFQUFxQjtBQUNqQixlQUFLVixTQUFMLENBQWVJLFlBQWYsQ0FBNEJWLEVBQUUsQ0FBQ1csTUFBL0IsRUFBdUNDLFlBQXZDLEdBQW9ELElBQXBEO0FBQ0EsZUFBS04sU0FBTCxDQUFlTyxPQUFmLEdBQXVCLEdBQXZCO0FBQ0FiLFVBQUFBLEVBQUUsQ0FBQ2lCLFFBQUgsQ0FBWUMsWUFBWixHQUEyQkMsV0FBM0IsQ0FBdUMsS0FBS2IsU0FBTCxDQUFlSSxZQUFmLENBQTRCVixFQUFFLENBQUNXLE1BQS9CLENBQXZDO0FBQ0g7QUFDSjtBQUVKLEtBVCtDLENBUzlDUyxJQVQ4QyxDQVN6QyxJQVR5QyxDQUFoRCxFQVNhLEtBQUtYLFFBVGxCO0FBVUgsR0E3Q0k7QUFnRExZLEVBQUFBLGVBaERLLDZCQWdEWTtBQUNiLFNBQUtqQixLQUFMLENBQVdNLFlBQVgsQ0FBd0JWLEVBQUUsQ0FBQ1csTUFBM0IsRUFBbUNDLFlBQW5DLEdBQWdELEtBQWhEO0FBQ0EsU0FBS1IsS0FBTCxDQUFXUyxPQUFYLEdBQW1CLEVBQW5CO0FBRUFiLElBQUFBLEVBQUUsQ0FBQ2lCLFFBQUgsQ0FBWUMsWUFBWixHQUEyQkksWUFBM0IsQ0FBd0MsS0FBS2xCLEtBQUwsQ0FBV00sWUFBWCxDQUF3QlYsRUFBRSxDQUFDVyxNQUEzQixDQUF4QztBQUNILEdBckRJO0FBdURMWSxFQUFBQSxhQXZESywyQkF1RFU7QUFDWCxTQUFLakIsU0FBTCxDQUFlSSxZQUFmLENBQTRCVixFQUFFLENBQUNXLE1BQS9CLEVBQXVDQyxZQUF2QyxHQUFvRCxLQUFwRDtBQUNBLFNBQUtOLFNBQUwsQ0FBZU8sT0FBZixHQUF1QixFQUF2QjtBQUNBYixJQUFBQSxFQUFFLENBQUNpQixRQUFILENBQVlDLFlBQVosR0FBMkJJLFlBQTNCLENBQXdDLEtBQUtoQixTQUFMLENBQWVJLFlBQWYsQ0FBNEJWLEVBQUUsQ0FBQ1csTUFBL0IsQ0FBeEM7QUFDSCxHQTNESSxDQTZETDs7QUE3REssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgICAgIHNwZWVkOmNjLk5vZGUsXHJcbiAgICAgICAgc2VsZWN0UmV0OmNjLk5vZGVcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy50aW1lRHVyMT0xNTtcclxuICAgICAgICB0aGlzLnRpbWVEdXIyPTEzO1xyXG4gICAgICAgIHRoaXMuc3BlZWQuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuaW50ZXJhY3RhYmxlPWZhbHNlO1xyXG4gICAgICAgIHRoaXMuc3BlZWQub3BhY2l0eT02MDtcclxuICAgICAgICB0aGlzLnNlbGVjdFJldC5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGU9ZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RSZXQub3BhY2l0eT02MDtcclxuXHJcbiAgICAgICAgXHJcblxyXG4gICAgICAgIHRoaXMuc3BlZWQuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuc2NoZWR1bGUoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgaWYodGhpcy5zcGVlZC5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGU9PWZhbHNlKXtcclxuICAgICAgICAgICAgICAgIGlmKE1hdGgucmFuZG9tKCk+MC40KXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNwZWVkLmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZT10cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3BlZWQub3BhY2l0eT0yNTU7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IuZ2V0U2NoZWR1bGVyKCkucGF1c2VUYXJnZXQodGhpcy5zcGVlZC5nZXRDb21wb25lbnQoY2MuQnV0dG9uKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLHRoaXMudGltZUR1cjEpO1xyXG4gICAgICAgIHRoaXMuc2VsZWN0UmV0LmdldENvbXBvbmVudChjYy5CdXR0b24pLnNjaGVkdWxlKGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuc2VsZWN0UmV0LmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgaWYoTWF0aC5yYW5kb20oKT4wLjQpe1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0UmV0LmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZT10cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0UmV0Lm9wYWNpdHk9MjU1O1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLmdldFNjaGVkdWxlcigpLnBhdXNlVGFyZ2V0KHRoaXMuc2VsZWN0UmV0LmdldENvbXBvbmVudChjYy5CdXR0b24pKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9LmJpbmQodGhpcyksdGhpcy50aW1lRHVyMik7XHJcbiAgICB9LFxyXG4gICAgXHJcblxyXG4gICAgb25DbGlja0Z1blNwZWVkKCl7XHJcbiAgICAgICAgdGhpcy5zcGVlZC5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5pbnRlcmFjdGFibGU9ZmFsc2U7XHJcbiAgICAgICAgdGhpcy5zcGVlZC5vcGFjaXR5PTYwO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFNjaGVkdWxlcigpLnJlc3VtZVRhcmdldCh0aGlzLnNwZWVkLmdldENvbXBvbmVudChjYy5CdXR0b24pKTtcclxuICAgIH0sXHJcblxyXG4gICAgb25DbGlja0Z1blJldCgpe1xyXG4gICAgICAgIHRoaXMuc2VsZWN0UmV0LmdldENvbXBvbmVudChjYy5CdXR0b24pLmludGVyYWN0YWJsZT1mYWxzZTtcclxuICAgICAgICB0aGlzLnNlbGVjdFJldC5vcGFjaXR5PTYwO1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFNjaGVkdWxlcigpLnJlc3VtZVRhcmdldCh0aGlzLnNlbGVjdFJldC5nZXRDb21wb25lbnQoY2MuQnV0dG9uKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19