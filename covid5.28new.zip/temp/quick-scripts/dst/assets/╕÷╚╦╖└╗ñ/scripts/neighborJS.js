
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/neighborJS.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fd53496MOdME5ghSeit0f6c', 'neighborJS');
// 火车防护/scripts/neighborJS.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    buttonYes: {
      "default": null,
      type: cc.Node
    },
    buttonNo: {
      "default": null,
      type: cc.Node
    },
    buttonConfirm: {
      "default": null,
      type: cc.Node
    },
    promptBox: {
      "default": null,
      type: cc.Node
    },
    Neighbor01: {
      "default": null,
      type: cc.TextAsset
    },
    controlLimit: {
      "default": null,
      type: cc.Node
    },
    control: {
      "default": null,
      type: cc.Node
    },
    gamePlayer: {
      "default": null,
      type: cc.Node
    },
    hasAdded: false
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.promptBox.active = false;
    this.buttonYes.active = false;
    this.buttonNo.active = false;
    this.buttonConfirm.active = false;
    this.node.active = false;
    var neighbor = this.node.getComponent(cc.Label);
    this.hasLaunched = false;
    this.node.on("shortDistanceNeighbor", function () {
      if (this.hasAdded === false) {
        this.promptBox.active = true;
        this.buttonYes.active = true;
        this.buttonNo.active = true;
        this.node.active = true;
        this.node.getComponent(cc.Label).string = this.Neighbor01.text;
        this.control.x = this.control.getComponent('UIcontrol').defaultPos.x;
        this.control.y = this.control.getComponent('UIcontrol').defaultPos.y;
        this.controlLimit.active = false;
      }
      /*
      this.buttonYes.on(cc.Node.EventType.TOUCH_END, function() {
          //this.node.dispatchEvent(new cc.Event.EventCustom("yes"));
          this.gamePlayer.getComponent('gamePlayer').infectPossibility += 25;
          neighbor = null;
          this.promptBox.active = false;
          this.buttonYes.active = false;
          this.buttonNo.active = false;
          this.node.active = false;
          this.controlLimit.active = true;
          this.control.getComponent('UIcontrol').ontouch = 0;
      }, this);
      this.buttonNo.on(cc.Node.EventType.TOUCH_END, function() {
          //this.node.dispatchEvent(new cc.Event.EventCustom("no"));
          this.promptBox.active = false;
          this.buttonYes.active = false;
          this.buttonNo.active = false;
          this.node.active = false;
          this.hasLaunched = true;
          this.controlLimit.active = true;
          this.control.getComponent('UIcontrol').ontouch = 0;                
      }, this);
      */

    }, this);
    /*
    this.node.on("yes", function() {
        this.gamePlayer.getComponent('gamePlayer').infectPossibility += 25;
        neighbor = null;
        this.promptBox.active = false;
        this.buttonYes.active = false;
        this.buttonNo.active = false;
        this.node.active = false;
        this.controlLimit.active = true;
        this.control.getComponent('UIcontrol').ontouch = 0;
    }, this);
      this.node.on("no", function() {
        this.promptBox.active = false;
        this.buttonYes.active = false;
        this.buttonNo.active = false;
        this.node.active = false;
        this.hasLaunched = true;
        this.controlLimit.active = true;
        this.control.getComponent('UIcontrol').ontouch = 0;
    }, this);
    */
  },
  start: function start() {},
  onClickYes: function onClickYes() {
    this.gamePlayer.getComponent('gamePlayer').infectPossibility += 25;
    this.hasAdded = true;
    this.promptBox.active = false;
    this.buttonYes.active = false;
    this.buttonNo.active = false;
    this.node.active = false;
    this.controlLimit.active = true;
    this.control.getComponent('UIcontrol').ontouch = 0;
  },
  onClickNo: function onClickNo() {
    this.promptBox.active = false;
    this.buttonYes.active = false;
    this.buttonNo.active = false;
    this.node.active = false;
    this.hasLaunched = true;
    this.controlLimit.active = true;
    this.control.getComponent('UIcontrol').ontouch = 0;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxuZWlnaGJvckpTLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYnV0dG9uWWVzIiwidHlwZSIsIk5vZGUiLCJidXR0b25ObyIsImJ1dHRvbkNvbmZpcm0iLCJwcm9tcHRCb3giLCJOZWlnaGJvcjAxIiwiVGV4dEFzc2V0IiwiY29udHJvbExpbWl0IiwiY29udHJvbCIsImdhbWVQbGF5ZXIiLCJoYXNBZGRlZCIsIm9uTG9hZCIsImFjdGl2ZSIsIm5vZGUiLCJuZWlnaGJvciIsImdldENvbXBvbmVudCIsIkxhYmVsIiwiaGFzTGF1bmNoZWQiLCJvbiIsInN0cmluZyIsInRleHQiLCJ4IiwiZGVmYXVsdFBvcyIsInkiLCJzdGFydCIsIm9uQ2xpY2tZZXMiLCJpbmZlY3RQb3NzaWJpbGl0eSIsIm9udG91Y2giLCJvbkNsaWNrTm8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxTQUFTLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZGLEtBREg7QUFNUkMsSUFBQUEsUUFBUSxFQUFFO0FBQ04saUJBQVMsSUFESDtBQUVORixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSCxLQU5GO0FBV1JFLElBQUFBLGFBQWEsRUFBRTtBQUNYLGlCQUFTLElBREU7QUFFWEgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkUsS0FYUDtBQWdCUkcsSUFBQUEsU0FBUyxFQUFFO0FBQ1AsaUJBQVMsSUFERjtBQUVQSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRixLQWhCSDtBQXFCUkksSUFBQUEsVUFBVSxFQUFFO0FBQ1IsaUJBQVMsSUFERDtBQUVSTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1c7QUFGRCxLQXJCSjtBQTBCUkMsSUFBQUEsWUFBWSxFQUFFO0FBQ1YsaUJBQVMsSUFEQztBQUVWUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGQyxLQTFCTjtBQStCUk8sSUFBQUEsT0FBTyxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMUixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGSixLQS9CRDtBQW9DUlEsSUFBQUEsVUFBVSxFQUFFO0FBQ1IsaUJBQVMsSUFERDtBQUVSVCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGRCxLQXBDSjtBQXdDUlMsSUFBQUEsUUFBUSxFQUFFO0FBeENGLEdBSFA7QUE4Q0w7QUFFQUMsRUFBQUEsTUFoREssb0JBZ0RLO0FBRU4sU0FBS1AsU0FBTCxDQUFlUSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS2IsU0FBTCxDQUFlYSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS1YsUUFBTCxDQUFjVSxNQUFkLEdBQXVCLEtBQXZCO0FBQ0EsU0FBS1QsYUFBTCxDQUFtQlMsTUFBbkIsR0FBNEIsS0FBNUI7QUFDQSxTQUFLQyxJQUFMLENBQVVELE1BQVYsR0FBbUIsS0FBbkI7QUFDQSxRQUFJRSxRQUFRLEdBQUcsS0FBS0QsSUFBTCxDQUFVRSxZQUFWLENBQXVCcEIsRUFBRSxDQUFDcUIsS0FBMUIsQ0FBZjtBQUVBLFNBQUtDLFdBQUwsR0FBbUIsS0FBbkI7QUFFQSxTQUFLSixJQUFMLENBQVVLLEVBQVYsQ0FBYSx1QkFBYixFQUFzQyxZQUFXO0FBRTdDLFVBQUcsS0FBS1IsUUFBTCxLQUFrQixLQUFyQixFQUE0QjtBQUN4QixhQUFLTixTQUFMLENBQWVRLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxhQUFLYixTQUFMLENBQWVhLE1BQWYsR0FBd0IsSUFBeEI7QUFDQSxhQUFLVixRQUFMLENBQWNVLE1BQWQsR0FBdUIsSUFBdkI7QUFDQSxhQUFLQyxJQUFMLENBQVVELE1BQVYsR0FBbUIsSUFBbkI7QUFDQSxhQUFLQyxJQUFMLENBQVVFLFlBQVYsQ0FBdUJwQixFQUFFLENBQUNxQixLQUExQixFQUFpQ0csTUFBakMsR0FBMEMsS0FBS2QsVUFBTCxDQUFnQmUsSUFBMUQ7QUFDQSxhQUFLWixPQUFMLENBQWFhLENBQWIsR0FBaUIsS0FBS2IsT0FBTCxDQUFhTyxZQUFiLENBQTBCLFdBQTFCLEVBQXVDTyxVQUF2QyxDQUFrREQsQ0FBbkU7QUFDQSxhQUFLYixPQUFMLENBQWFlLENBQWIsR0FBaUIsS0FBS2YsT0FBTCxDQUFhTyxZQUFiLENBQTBCLFdBQTFCLEVBQXVDTyxVQUF2QyxDQUFrREMsQ0FBbkU7QUFDQSxhQUFLaEIsWUFBTCxDQUFrQkssTUFBbEIsR0FBMkIsS0FBM0I7QUFFSDtBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF3QkgsS0F0Q0QsRUFzQ0csSUF0Q0g7QUF3Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCSCxHQTFISTtBQTRITFksRUFBQUEsS0E1SEssbUJBNEhJLENBRVIsQ0E5SEk7QUFnSUxDLEVBQUFBLFVBQVUsRUFBRSxzQkFBVztBQUNuQixTQUFLaEIsVUFBTCxDQUFnQk0sWUFBaEIsQ0FBNkIsWUFBN0IsRUFBMkNXLGlCQUEzQyxJQUFnRSxFQUFoRTtBQUNBLFNBQUtoQixRQUFMLEdBQWdCLElBQWhCO0FBQ0EsU0FBS04sU0FBTCxDQUFlUSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS2IsU0FBTCxDQUFlYSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS1YsUUFBTCxDQUFjVSxNQUFkLEdBQXVCLEtBQXZCO0FBQ0EsU0FBS0MsSUFBTCxDQUFVRCxNQUFWLEdBQW1CLEtBQW5CO0FBQ0EsU0FBS0wsWUFBTCxDQUFrQkssTUFBbEIsR0FBMkIsSUFBM0I7QUFDQSxTQUFLSixPQUFMLENBQWFPLFlBQWIsQ0FBMEIsV0FBMUIsRUFBdUNZLE9BQXZDLEdBQWlELENBQWpEO0FBQ0gsR0F6SUk7QUEySUxDLEVBQUFBLFNBQVMsRUFBRSxxQkFBVztBQUNsQixTQUFLeEIsU0FBTCxDQUFlUSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS2IsU0FBTCxDQUFlYSxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS1YsUUFBTCxDQUFjVSxNQUFkLEdBQXVCLEtBQXZCO0FBQ0EsU0FBS0MsSUFBTCxDQUFVRCxNQUFWLEdBQW1CLEtBQW5CO0FBQ0EsU0FBS0ssV0FBTCxHQUFtQixJQUFuQjtBQUNBLFNBQUtWLFlBQUwsQ0FBa0JLLE1BQWxCLEdBQTJCLElBQTNCO0FBQ0EsU0FBS0osT0FBTCxDQUFhTyxZQUFiLENBQTBCLFdBQTFCLEVBQXVDWSxPQUF2QyxHQUFpRCxDQUFqRDtBQUNILEdBbkpJLENBcUpMOztBQXJKSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgYnV0dG9uWWVzOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgYnV0dG9uTm86IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBidXR0b25Db25maXJtOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgcHJvbXB0Qm94OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgTmVpZ2hib3IwMToge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5UZXh0QXNzZXQsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgY29udHJvbExpbWl0OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgY29udHJvbDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIGdhbWVQbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGhhc0FkZGVkOiBmYWxzZSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHJcbiAgICAgICAgdGhpcy5wcm9tcHRCb3guYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5idXR0b25ZZXMuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5idXR0b25Oby5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmJ1dHRvbkNvbmZpcm0uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHZhciBuZWlnaGJvciA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cclxuICAgICAgICB0aGlzLmhhc0xhdW5jaGVkID0gZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS5vbihcInNob3J0RGlzdGFuY2VOZWlnaGJvclwiLCBmdW5jdGlvbigpIHtcclxuXHJcbiAgICAgICAgICAgIGlmKHRoaXMuaGFzQWRkZWQgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5idXR0b25ZZXMuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYnV0dG9uTm8uYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gdGhpcy5OZWlnaGJvcjAxLnRleHQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRyb2wueCA9IHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLmRlZmF1bHRQb3MueDtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udHJvbC55ID0gdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykuZGVmYXVsdFBvcy55O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgdGhpcy5idXR0b25ZZXMub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgICAgIC8vdGhpcy5ub2RlLmRpc3BhdGNoRXZlbnQobmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKFwieWVzXCIpKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ2FtZVBsYXllci5nZXRDb21wb25lbnQoJ2dhbWVQbGF5ZXInKS5pbmZlY3RQb3NzaWJpbGl0eSArPSAyNTtcclxuICAgICAgICAgICAgICAgIG5laWdoYm9yID0gbnVsbDtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5idXR0b25ZZXMuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmJ1dHRvbk5vLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLm9udG91Y2ggPSAwO1xyXG4gICAgICAgICAgICB9LCB0aGlzKTtcclxuICAgICAgICAgICAgdGhpcy5idXR0b25Oby5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgLy90aGlzLm5vZGUuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJub1wiKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnByb21wdEJveC5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYnV0dG9uWWVzLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5idXR0b25Oby5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGFzTGF1bmNoZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udHJvbC5nZXRDb21wb25lbnQoJ1VJY29udHJvbCcpLm9udG91Y2ggPSAwOyAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH0sIHRoaXMpO1xyXG5cclxuICAgICAgICAvKlxyXG4gICAgICAgIHRoaXMubm9kZS5vbihcInllc1wiLCBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgdGhpcy5nYW1lUGxheWVyLmdldENvbXBvbmVudCgnZ2FtZVBsYXllcicpLmluZmVjdFBvc3NpYmlsaXR5ICs9IDI1O1xyXG4gICAgICAgICAgICBuZWlnaGJvciA9IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvblllcy5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5idXR0b25Oby5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRyb2xMaW1pdC5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRyb2wuZ2V0Q29tcG9uZW50KCdVSWNvbnRyb2wnKS5vbnRvdWNoID0gMDtcclxuICAgICAgICB9LCB0aGlzKTtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwibm9cIiwgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvblllcy5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5idXR0b25Oby5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmhhc0xhdW5jaGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykub250b3VjaCA9IDA7XHJcbiAgICAgICAgfSwgdGhpcyk7XHJcbiAgICAgICAgKi9cclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgb25DbGlja1llczogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdGhpcy5nYW1lUGxheWVyLmdldENvbXBvbmVudCgnZ2FtZVBsYXllcicpLmluZmVjdFBvc3NpYmlsaXR5ICs9IDI1O1xyXG4gICAgICAgIHRoaXMuaGFzQWRkZWQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucHJvbXB0Qm94LmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuYnV0dG9uWWVzLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuYnV0dG9uTm8uYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY29udHJvbExpbWl0LmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5jb250cm9sLmdldENvbXBvbmVudCgnVUljb250cm9sJykub250b3VjaCA9IDA7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ2xpY2tObzogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdGhpcy5wcm9tcHRCb3guYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5idXR0b25ZZXMuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5idXR0b25Oby5hY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5oYXNMYXVuY2hlZCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5jb250cm9sTGltaXQuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmNvbnRyb2wuZ2V0Q29tcG9uZW50KCdVSWNvbnRyb2wnKS5vbnRvdWNoID0gMDtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=