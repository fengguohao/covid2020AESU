
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/showTime.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'af56coCf9BPTYCTdF3Ob/tP', 'showTime');
// 火车防护/scripts/showTime.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.time = 0;
    var func = cc.callFunc(function () {
      this.time++;
    }.bind(this));
    var remain = cc.fadeTo(1, 255);
    this.node.runAction(cc.sequence([remain, func])).repeatForever();
  },
  start: function start() {},
  update: function update(dt) {
    var l = this.node.getComponent(cc.Label);
    l.string = "用时：" + this.time + "秒";
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxzaG93VGltZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsInRpbWUiLCJmdW5jIiwiY2FsbEZ1bmMiLCJiaW5kIiwicmVtYWluIiwiZmFkZVRvIiwibm9kZSIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwicmVwZWF0Rm9yZXZlciIsInN0YXJ0IiwidXBkYXRlIiwiZHQiLCJsIiwiZ2V0Q29tcG9uZW50IiwiTGFiZWwiLCJzdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsTUFUSyxvQkFTSztBQUVOLFNBQUtDLElBQUwsR0FBWSxDQUFaO0FBQ0EsUUFBSUMsSUFBSSxHQUFHTixFQUFFLENBQUNPLFFBQUgsQ0FBWSxZQUFXO0FBQzlCLFdBQUtGLElBQUw7QUFDSCxLQUZzQixDQUVyQkcsSUFGcUIsQ0FFaEIsSUFGZ0IsQ0FBWixDQUFYO0FBR0EsUUFBSUMsTUFBTSxHQUFHVCxFQUFFLENBQUNVLE1BQUgsQ0FBVSxDQUFWLEVBQWEsR0FBYixDQUFiO0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxTQUFWLENBQW9CWixFQUFFLENBQUNhLFFBQUgsQ0FBWSxDQUFDSixNQUFELEVBQVNILElBQVQsQ0FBWixDQUFwQixFQUFpRFEsYUFBakQ7QUFFSCxHQWxCSTtBQW9CTEMsRUFBQUEsS0FwQkssbUJBb0JJLENBRVIsQ0F0Qkk7QUF3QkxDLEVBQUFBLE1BeEJLLGtCQXdCR0MsRUF4QkgsRUF3Qk87QUFDUixRQUFJQyxDQUFDLEdBQUcsS0FBS1AsSUFBTCxDQUFVUSxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBUjtBQUNBRixJQUFBQSxDQUFDLENBQUNHLE1BQUYsR0FBVyxRQUFRLEtBQUtoQixJQUFiLEdBQW9CLEdBQS9CO0FBQ0g7QUEzQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG5cclxuICAgICAgICB0aGlzLnRpbWUgPSAwO1xyXG4gICAgICAgIHZhciBmdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIHRoaXMudGltZSsrO1xyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcbiAgICAgICAgdmFyIHJlbWFpbiA9IGNjLmZhZGVUbygxLCAyNTUpO1xyXG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoW3JlbWFpbiwgZnVuY10pKS5yZXBlYXRGb3JldmVyKCk7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB2YXIgbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gICAgICAgIGwuc3RyaW5nID0gXCLnlKjml7bvvJpcIiArIHRoaXMudGltZSArIFwi56eSXCI7XHJcbiAgICB9LFxyXG59KTtcclxuIl19