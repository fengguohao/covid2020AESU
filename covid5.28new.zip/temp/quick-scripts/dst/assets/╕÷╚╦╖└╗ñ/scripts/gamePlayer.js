
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/个人防护/scripts/gamePlayer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd1855pVuHBJSIPgdzrnITjU', 'gamePlayer');
// 火车防护/scripts/gamePlayer.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    referenceNode: {
      "default": null,
      type: cc.Node
    },
    //被传染的概率
    infectPossibility: 1,
    //关联提示框
    //sameOnce: cc.Node,
    //sameTwice: cc.Node,
    //oppositeOnce: cc.Node,
    //oppositeTwice: cc.Node,
    neighbor: cc.Node,
    neighborShortDistance: cc.Node,
    //关联其他乘客
    npc: cc.Node,
    //移动方向
    direction: cc.String,
    //走廊宽度的一半
    corridorWidth: 85,
    //走廊长度的一半
    corridorLength: 360,
    //面对面最小距离
    faceDisLim: 100,
    //一般距离
    faceDis: 480,
    //邻座距离
    neighborDis: 60,
    //可能性我实在分不出来了，最好分一下
    chechLabel: cc.Label,
    onBump: 0,
    hasWashedHandsBefore: false,
    hasWashedHandsAfter: false,
    hasReleased: false,
    audioMgr: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.npc = this.npc.getComponent('npc');
    this.direction = 'left';
    this.corridorWidth = 85; //好像有点小

    this.corridorLength = 360;
    this.faceDisLim = 100;
    this.faceDis = 480;
    this.neighborDis = 60;
    this.audioMgr = this.audioMgr.getComponent("AudioMgr");
    this.scheduleOnce(function () {
      this.audioMgr.playMusic("trainMusic");
    }.bind(this), 5);
    this.lastY = 75;
  },
  // start () {
  // },
  update: function update(dt) {
    this.judgeDistance();
    this.judgeNeighbor();
  },
  //判断gamePlayer和npc的距离
  judgeDistance: function judgeDistance() {
    var npc = this.npc.getComponent('npc'); //console.log(this.npc.others[0].x-this.node.x);

    for (var i = 0; i <= 8; i++) {
      var Dx = this.node.x - npc.others[i].x;
      var Dy = this.node.y - npc.others[i].y; //console.log(npc.others[i].isVisited);
      //从背后距离不足够大的情况

      if (npc.others[i].isVisited === false && npc.others[i].direction === this.direction && (this.direction === 'left' && this.node.x < npc.others[i].x || this.direction === 'right' && this.node.x > npc.others[i].x)) {
        if (Math.abs(this.node.x - npc.others[i].x) <= this.corridorLength && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
          if (npc.others[i].isVisitedSameOnce === true) {
            this.infectPossibility += 4;
          } else {
            this.infectPossibility += 7;
          }

          npc.others[i].isVisited = true; //弹出提示框
          //this.sameTwice.dispatchEvent(new cc.Event.EventCustom("SameTwice01"));
          //npc.tip[i].string = "背后有人距离最近";

          /*
          cc.log("others", i, "isVisited", npc.others[i].isVisited);
          cc.log("others", i, "isVisitedSameOnce", npc.others[i].isVisitedSameOnce);
          cc.log("others", i, "isVisitedOppositeOnce", npc.others[i].isVisitedOppositeOnce);
          cc.log("others", i, "isVisitedOppositeTwice", npc.others[i].isVisitedOppositeTwice);
          */

          /*
          cc.log("gamePlayer.direction", this.direction);
          cc.log("others", i, npc.others[i].direction);
          cc.log("背后有人距离最近");
          */
        } else if (this.corridorLength < Math.abs(this.node.x - npc.others[i].x) && Math.abs(this.node.x - npc.others[i].x) <= 2 * this.corridorLength && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
          if (npc.others[i].isVisitedSameOnce === false) {
            this.infectPossibility += 3;
          }

          npc.others[i].isVisitedSameOnce = true;
          /*
          cc.log("others", i, "isVisited", npc.others[i].isVisited);
          cc.log("others", i, "isVisitedSameOnce", npc.others[i].isVisitedSameOnce);
          cc.log("others", i, "isVisitedOppositeOnce", npc.others[i].isVisitedOppositeOnce);
          cc.log("others", i, "isVisitedOppositeTwice", npc.others[i].isVisitedOppositeTwice);
          */

          /*
          cc.log("gamePlayer.direction", this.direction);
          cc.log("others", i, npc.others[i].direction);
          cc.log("背后有人");
          */
          //弹出提示框
          //this.sameOnce.dispatchEvent(new cc.Event.EventCustom("SameOnce01"));
          //npc.tip[i].string = "背后有人";
        }
      } //面对面距离不够大的情况
      else if (npc.others[i].isVisited === false && (npc.others[i].direction === 'left' && this.direction === 'right' && this.node.x < npc.others[i].x || npc.others[i].direction === 'right' && this.direction === 'left' && this.node.x > npc.others[i].x)) {
          if (Math.abs(this.node.x - npc.others[i].x) <= this.faceDisLim && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            if (npc.others[i].isVisitedOppositeOnce === true && npc.others[i].isVisitedOppositeTwice === true) {
              this.infectPossibility += 10;
            } else if (npc.others[i].isVisitedOppositeOnce === true && npc.others[i].isVisitedOppositeTwice === false) {
              this.infectPossibility += 20;
            } else if (npc.others[i].isVisitedOppositeOnce === false && npc.others[i].isVisitedOppositeTwice === true) {
              this.infectPossibility += 10;
            } else {
              this.infectPossibility += 25;
            }

            npc.others[i].isVisited = true;
            /*
            cc.log("others", i, "isVisited", npc.others[i].isVisited);
            cc.log("others", i, "isVisitedSameOnce", npc.others[i].isVisitedSameOnce);
            cc.log("others", i, "isVisitedOppositeOnce", npc.others[i].isVisitedOppositeOnce);
            cc.log("others", i, "isVisitedOppositeTwice", npc.others[i].isVisitedOppositeTwice);
            */

            /*
            cc.log("gamePlayer.direction", this.direction);
            cc.log("others", i, npc.others[i].direction);
            cc.log("正面有人距离最近");
            */
            //npc.tip[i].string = "正面有人距离最近";
          } else if (this.faceDisLim < Math.abs(this.node.x - npc.others[i].x) && Math.abs(this.node.x - npc.others[i].x) <= this.faceDis && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            if (npc.others[i].isVisitedOppositeTwice === false) {
              if (npc.others[i].isVisitedOppositeOnce === true) {
                this.infectPossibility += 10;
              } else {
                this.infectPossibility += 15;
              }

              npc.others[i].isVisitedOppositeTwice = true;
            } //弹出提示框
            //this.oppositeTwice.dispatchEvent(new cc.Event.EventCustom("OppositeTwice01"));
            //npc.tip[i].string = "正面有人距离比较近";

            /*
            cc.log("others", i, "isVisited", npc.others[i].isVisited);
            cc.log("others", i, "isVisitedSameOnce", npc.others[i].isVisitedSameOnce);
            cc.log("others", i, "isVisitedOppositeOnce", npc.others[i].isVisitedOppositeOnce);
            cc.log("others", i, "isVisitedOppositeTwice", npc.others[i].isVisitedOppositeTwice);
            */

            /*
            cc.log("gamePlayer.direction", this.direction);
            cc.log("others", i, npc.others[i].direction);
            cc.log("正面有人距离比较近");
            */

          } else if (Math.abs(this.node.x - npc.others[i].x) > this.faceDis && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            if (npc.others[i].isVisitedOppositeOnce === false) {
              this.infectPossibility += 5;
            }

            npc.others[i].isVisitedOppositeOnce = true; //弹出提示框
            //this.oppositeOnce.dispatchEvent(new cc.Event.EventCustom("OppositeOnce01"));
            //npc.tip[i].string = "正面有人";

            /*
            cc.log("others", i, "isVisited", npc.others[i].isVisited);
            cc.log("others", i, "isVisitedSameOnce", npc.others[i].isVisitedSameOnce);
            cc.log("others", i, "isVisitedOppositeOnce", npc.others[i].isVisitedOppositeOnce);
            cc.log("others", i, "isVisitedOppositeTwice", npc.others[i].isVisitedOppositeTwice);
            */

            /*
            cc.log("gamePlayer.direction", this.direction);
            cc.log("others", i, npc.others[i].direction);
            cc.log("正面有人");
            */
          }
        } else {//npc.tip[i].string = "";
          }

      if (npc.others[i].direction === this.direction && (this.direction === 'left' && this.node.x < npc.others[i].x || this.direction === 'right' && this.node.x > npc.others[i].x)) {
        if (Math.abs(this.node.x - npc.others[i].x) <= this.corridorLength && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
          //弹出提示
          npc.tip[i].string = "背后有人距离最近";
        } else if (this.corridorLength < Math.abs(this.node.x - npc.others[i].x) && Math.abs(this.node.x - npc.others[i].x) <= 2 * this.corridorLength && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
          //弹出提示
          npc.tip[i].string = "背后有人";
        }
      } //面对面距离不够大的情况
      else if (npc.others[i].direction === 'left' && this.direction === 'right' && this.node.x < npc.others[i].x || npc.others[i].direction === 'right' && this.direction === 'left' && this.node.x > npc.others[i].x) {
          if (Math.abs(this.node.x - npc.others[i].x) <= this.faceDisLim && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            npc.tip[i].string = "正面有人距离最近";
          } else if (this.faceDisLim < Math.abs(this.node.x - npc.others[i].x) && Math.abs(this.node.x - npc.others[i].x) <= this.faceDis && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            //弹出提示
            npc.tip[i].string = "正面有人距离比较近";
          } else if (Math.abs(this.node.x - npc.others[i].x) > this.faceDis && Math.abs(this.node.y) <= this.corridorWidth && Math.abs(npc.others[i].y) <= this.corridorWidth) {
            //弹出提示
            npc.tip[i].string = "正面有人";
          }
        } else {
          npc.tip[i].string = "";
        }
    } // console.info(this.direction);
    // console.info(this.infectPossibility);

  },
  //判断邻座是否有人
  judgeNeighbor: function judgeNeighbor() {
    var npc = this.npc.getComponent('npc'); //cc.log("玩家的y坐标：", this.node.y);
    //cc.log("邻座的y坐标：", npc.neighborSeat.y);

    if (Math.abs(this.node.y - npc.neighborSeat.y) <= this.neighborDis && this.neighborShortDistance.getComponent('neighborJS').hasLaunched === false && npc.neighborSeat.x <= 790) {
      //弹出提示框
      if (this.direction == 'down' && Math.abs(this.lastY - this.node.y) >= 10) {
        this.neighborShortDistance.dispatchEvent(new cc.Event.EventCustom("shortDistanceNeighbor"));
        this.lastY = this.node.y;
      } //this.neighborShortDistance.dispatchEvent(new cc.Event.EventCustom("shortDistanceNeighbor"));

    }
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log(this.onBump);

    if (this.onBump == 0) {
      this.audioMgr.playMusic("bump");
      console.log("pal");
    }

    this.onBump = other.tag;
    console.log(this.onBump);
  },
  onCollisionExit: function onCollisionExit() {
    this.onBump = 0;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc54Gr6L2m6Ziy5oqkXFxzY3JpcHRzXFxnYW1lUGxheWVyLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwicmVmZXJlbmNlTm9kZSIsInR5cGUiLCJOb2RlIiwiaW5mZWN0UG9zc2liaWxpdHkiLCJuZWlnaGJvciIsIm5laWdoYm9yU2hvcnREaXN0YW5jZSIsIm5wYyIsImRpcmVjdGlvbiIsIlN0cmluZyIsImNvcnJpZG9yV2lkdGgiLCJjb3JyaWRvckxlbmd0aCIsImZhY2VEaXNMaW0iLCJmYWNlRGlzIiwibmVpZ2hib3JEaXMiLCJjaGVjaExhYmVsIiwiTGFiZWwiLCJvbkJ1bXAiLCJoYXNXYXNoZWRIYW5kc0JlZm9yZSIsImhhc1dhc2hlZEhhbmRzQWZ0ZXIiLCJoYXNSZWxlYXNlZCIsImF1ZGlvTWdyIiwib25Mb2FkIiwiZ2V0Q29tcG9uZW50Iiwic2NoZWR1bGVPbmNlIiwicGxheU11c2ljIiwiYmluZCIsImxhc3RZIiwidXBkYXRlIiwiZHQiLCJqdWRnZURpc3RhbmNlIiwianVkZ2VOZWlnaGJvciIsImkiLCJEeCIsIm5vZGUiLCJ4Iiwib3RoZXJzIiwiRHkiLCJ5IiwiaXNWaXNpdGVkIiwiTWF0aCIsImFicyIsImlzVmlzaXRlZFNhbWVPbmNlIiwiaXNWaXNpdGVkT3Bwb3NpdGVPbmNlIiwiaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZSIsInRpcCIsInN0cmluZyIsIm5laWdoYm9yU2VhdCIsImhhc0xhdW5jaGVkIiwiZGlzcGF0Y2hFdmVudCIsIkV2ZW50IiwiRXZlbnRDdXN0b20iLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwiY29uc29sZSIsImxvZyIsInRhZyIsIm9uQ29sbGlzaW9uRXhpdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLGFBQWEsRUFBQztBQUNWLGlCQUFRLElBREU7QUFFVkMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNO0FBRkUsS0FETjtBQUtSO0FBQ0FDLElBQUFBLGlCQUFpQixFQUFFLENBTlg7QUFPUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLElBQUFBLFFBQVEsRUFBRVIsRUFBRSxDQUFDTSxJQVpMO0FBYVJHLElBQUFBLHFCQUFxQixFQUFFVCxFQUFFLENBQUNNLElBYmxCO0FBY1I7QUFDQUksSUFBQUEsR0FBRyxFQUFFVixFQUFFLENBQUNNLElBZkE7QUFnQlI7QUFDQUssSUFBQUEsU0FBUyxFQUFDWCxFQUFFLENBQUNZLE1BakJMO0FBa0JSO0FBQ0FDLElBQUFBLGFBQWEsRUFBQyxFQW5CTjtBQW9CUjtBQUNBQyxJQUFBQSxjQUFjLEVBQUMsR0FyQlA7QUFzQlI7QUFDQUMsSUFBQUEsVUFBVSxFQUFDLEdBdkJIO0FBd0JSO0FBQ0FDLElBQUFBLE9BQU8sRUFBQyxHQXpCQTtBQTBCUjtBQUNBQyxJQUFBQSxXQUFXLEVBQUMsRUEzQko7QUE0QlI7QUFFQUMsSUFBQUEsVUFBVSxFQUFDbEIsRUFBRSxDQUFDbUIsS0E5Qk47QUFnQ1JDLElBQUFBLE1BQU0sRUFBQyxDQWhDQztBQWtDUkMsSUFBQUEsb0JBQW9CLEVBQUUsS0FsQ2Q7QUFtQ1JDLElBQUFBLG1CQUFtQixFQUFFLEtBbkNiO0FBb0NSQyxJQUFBQSxXQUFXLEVBQUUsS0FwQ0w7QUFxQ1JDLElBQUFBLFFBQVEsRUFBQ3hCLEVBQUUsQ0FBQ007QUFyQ0osR0FIUDtBQThDTDtBQUVBbUIsRUFBQUEsTUFoREssb0JBZ0RLO0FBRU4sU0FBS2YsR0FBTCxHQUFXLEtBQUtBLEdBQUwsQ0FBU2dCLFlBQVQsQ0FBc0IsS0FBdEIsQ0FBWDtBQUNBLFNBQUtmLFNBQUwsR0FBaUIsTUFBakI7QUFDQSxTQUFLRSxhQUFMLEdBQW1CLEVBQW5CLENBSk0sQ0FJZ0I7O0FBQ3RCLFNBQUtDLGNBQUwsR0FBb0IsR0FBcEI7QUFDQSxTQUFLQyxVQUFMLEdBQWdCLEdBQWhCO0FBQ0EsU0FBS0MsT0FBTCxHQUFhLEdBQWI7QUFDQSxTQUFLQyxXQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBS08sUUFBTCxHQUFjLEtBQUtBLFFBQUwsQ0FBY0UsWUFBZCxDQUEyQixVQUEzQixDQUFkO0FBQ0EsU0FBS0MsWUFBTCxDQUFrQixZQUFVO0FBQ3hCLFdBQUtILFFBQUwsQ0FBY0ksU0FBZCxDQUF3QixZQUF4QjtBQUNILEtBRmlCLENBRWhCQyxJQUZnQixDQUVYLElBRlcsQ0FBbEIsRUFFYSxDQUZiO0FBSUEsU0FBS0MsS0FBTCxHQUFhLEVBQWI7QUFFSCxHQWhFSTtBQWtFTDtBQUNBO0FBRUFDLEVBQUFBLE1BckVLLGtCQXFFR0MsRUFyRUgsRUFxRU87QUFDUixTQUFLQyxhQUFMO0FBQ0EsU0FBS0MsYUFBTDtBQUNILEdBeEVJO0FBMEVMO0FBQ0FELEVBQUFBLGFBQWEsRUFBRSx5QkFBVztBQUN0QixRQUFJdkIsR0FBRyxHQUFHLEtBQUtBLEdBQUwsQ0FBU2dCLFlBQVQsQ0FBc0IsS0FBdEIsQ0FBVixDQURzQixDQUV0Qjs7QUFHQSxTQUFJLElBQUlTLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsSUFBSSxDQUFwQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUN4QixVQUFJQyxFQUFFLEdBQUMsS0FBS0MsSUFBTCxDQUFVQyxDQUFWLEdBQWM1QixHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY0csQ0FBbkM7QUFDQSxVQUFJRSxFQUFFLEdBQUMsS0FBS0gsSUFBTCxDQUFVSSxDQUFWLEdBQWMvQixHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY00sQ0FBbkMsQ0FGd0IsQ0FHeEI7QUFDQTs7QUFDQSxVQUFHL0IsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNPLFNBQWQsS0FBNEIsS0FBNUIsSUFBcUNoQyxHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY3hCLFNBQWQsS0FBNEIsS0FBS0EsU0FBdEUsS0FDRSxLQUFLQSxTQUFMLEtBQW1CLE1BQW5CLElBQTZCLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUF6RCxJQUNBLEtBQUszQixTQUFMLEtBQW1CLE9BQW5CLElBQThCLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUY1RCxDQUFILEVBRW1FO0FBRS9ELFlBQUdLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLEtBQUt4QixjQUFoRCxJQUNINkIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEM0IsSUFDNEM4QixJQUFJLENBQUNDLEdBQUwsQ0FBU2xDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjTSxDQUF2QixLQUE2QixLQUFLNUIsYUFEakYsRUFDZ0c7QUFFNUYsY0FBR0gsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNVLGlCQUFkLEtBQW9DLElBQXZDLEVBQTZDO0FBQ3pDLGlCQUFLdEMsaUJBQUwsSUFBMEIsQ0FBMUI7QUFDSCxXQUZELE1BRU87QUFDSCxpQkFBS0EsaUJBQUwsSUFBMEIsQ0FBMUI7QUFDSDs7QUFDREcsVUFBQUEsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNPLFNBQWQsR0FBMEIsSUFBMUIsQ0FQNEYsQ0FTNUY7QUFDQTtBQUNBOztBQUNBOzs7Ozs7O0FBTUE7Ozs7O0FBS0gsU0F4QkQsTUF5QkssSUFBRyxLQUFLNUIsY0FBTCxHQUFzQjZCLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLENBQXRCLElBQ1JLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLElBQUUsS0FBS3hCLGNBRDFDLElBRVI2QixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVJLENBQW5CLEtBQXlCLEtBQUs1QixhQUZ0QixJQUV1QzhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQUY1RSxFQUUyRjtBQUU1RixjQUFHSCxHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY1UsaUJBQWQsS0FBb0MsS0FBdkMsRUFBOEM7QUFDMUMsaUJBQUt0QyxpQkFBTCxJQUEwQixDQUExQjtBQUNIOztBQUNERyxVQUFBQSxHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY1UsaUJBQWQsR0FBa0MsSUFBbEM7QUFDQTs7Ozs7OztBQU1BOzs7OztBQUtBO0FBQ0E7QUFDQTtBQUVIO0FBQ0osT0FyREQsQ0F1REE7QUF2REEsV0F3REssSUFBR25DLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjTyxTQUFkLEtBQTRCLEtBQTVCLEtBQ0hoQyxHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY3hCLFNBQWQsS0FBNEIsTUFBNUIsSUFBc0MsS0FBS0EsU0FBTCxLQUFtQixPQUF6RCxJQUFvRSxLQUFLMEIsSUFBTCxDQUFVQyxDQUFWLEdBQWM1QixHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY0csQ0FBaEcsSUFDRDVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjeEIsU0FBZCxLQUE0QixPQUE1QixJQUF1QyxLQUFLQSxTQUFMLEtBQW1CLE1BQTFELElBQW9FLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUY1RixDQUFILEVBRW9HO0FBRXJHLGNBQUdLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLEtBQUt2QixVQUFoRCxJQUNINEIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEM0IsSUFFSDhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQUZsQyxFQUVpRDtBQUU3QyxnQkFBR0gsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNXLHFCQUFkLEtBQXdDLElBQXhDLElBQWdEcEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNZLHNCQUFkLEtBQXlDLElBQTVGLEVBQWtHO0FBQzlGLG1CQUFLeEMsaUJBQUwsSUFBMEIsRUFBMUI7QUFDSCxhQUZELE1BRU8sSUFBR0csR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNXLHFCQUFkLEtBQXdDLElBQXhDLElBQWdEcEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNZLHNCQUFkLEtBQXlDLEtBQTVGLEVBQW1HO0FBQ3RHLG1CQUFLeEMsaUJBQUwsSUFBMEIsRUFBMUI7QUFDSCxhQUZNLE1BRUEsSUFBR0csR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNXLHFCQUFkLEtBQXdDLEtBQXhDLElBQWlEcEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNZLHNCQUFkLEtBQXlDLElBQTdGLEVBQW1HO0FBQ3RHLG1CQUFLeEMsaUJBQUwsSUFBMEIsRUFBMUI7QUFDSCxhQUZNLE1BRUE7QUFDSCxtQkFBS0EsaUJBQUwsSUFBMEIsRUFBMUI7QUFDSDs7QUFDREcsWUFBQUEsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNPLFNBQWQsR0FBMEIsSUFBMUI7QUFDQTs7Ozs7OztBQU1BOzs7OztBQU1EO0FBQ0YsV0EzQkQsTUE0QkssSUFBRyxLQUFLM0IsVUFBTCxHQUFrQjRCLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLENBQWxCLElBQTZESyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUFyQyxLQUNyRSxLQUFLdEIsT0FERyxJQUNRMkIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEdEMsSUFDdUQ4QixJQUFJLENBQUNDLEdBQUwsQ0FBU2xDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjTSxDQUF2QixLQUE2QixLQUFLNUIsYUFENUYsRUFDMkc7QUFFNUcsZ0JBQUdILEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjWSxzQkFBZCxLQUF5QyxLQUE1QyxFQUFtRDtBQUMvQyxrQkFBR3JDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjVyxxQkFBZCxLQUF3QyxJQUEzQyxFQUFpRDtBQUM3QyxxQkFBS3ZDLGlCQUFMLElBQTBCLEVBQTFCO0FBQ0gsZUFGRCxNQUVPO0FBQ0gscUJBQUtBLGlCQUFMLElBQTBCLEVBQTFCO0FBQ0g7O0FBQ0RHLGNBQUFBLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjWSxzQkFBZCxHQUF1QyxJQUF2QztBQUNILGFBVDJHLENBVzVHO0FBQ0E7QUFDQTs7QUFDQTs7Ozs7OztBQU1BOzs7Ozs7QUFLSCxXQTFCSSxNQTJCQSxJQUFHSixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUFyQyxJQUEwQyxLQUFLdEIsT0FBL0MsSUFBMEQyQixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVJLENBQW5CLEtBQXlCLEtBQUs1QixhQUF4RixJQUF5RzhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQUE5SSxFQUE2SjtBQUU5SixnQkFBR0gsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNXLHFCQUFkLEtBQXdDLEtBQTNDLEVBQWtEO0FBQzlDLG1CQUFLdkMsaUJBQUwsSUFBMEIsQ0FBMUI7QUFDSDs7QUFDREcsWUFBQUEsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNXLHFCQUFkLEdBQXNDLElBQXRDLENBTDhKLENBTzlKO0FBQ0E7QUFDQTs7QUFDQTs7Ozs7OztBQU1BOzs7OztBQUtIO0FBQ0osU0FqRkksTUFrRkEsQ0FDRDtBQUNIOztBQUVELFVBQUdwQyxHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY3hCLFNBQWQsS0FBNEIsS0FBS0EsU0FBakMsS0FDRSxLQUFLQSxTQUFMLEtBQW1CLE1BQW5CLElBQTZCLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUF6RCxJQUNBLEtBQUszQixTQUFMLEtBQW1CLE9BQW5CLElBQThCLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUY1RCxDQUFILEVBRW1FO0FBRS9ELFlBQUdLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLEtBQUt4QixjQUFoRCxJQUNINkIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEM0IsSUFDNEM4QixJQUFJLENBQUNDLEdBQUwsQ0FBU2xDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjTSxDQUF2QixLQUE2QixLQUFLNUIsYUFEakYsRUFDZ0c7QUFFNUY7QUFDQUgsVUFBQUEsR0FBRyxDQUFDc0MsR0FBSixDQUFRYixDQUFSLEVBQVdjLE1BQVgsR0FBb0IsVUFBcEI7QUFFSCxTQU5ELE1BT0ssSUFBRyxLQUFLbkMsY0FBTCxHQUFzQjZCLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLENBQXRCLElBQ1JLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLElBQUUsS0FBS3hCLGNBRDFDLElBRVI2QixJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVJLENBQW5CLEtBQXlCLEtBQUs1QixhQUZ0QixJQUV1QzhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQUY1RSxFQUUyRjtBQUU1RjtBQUNBSCxVQUFBQSxHQUFHLENBQUNzQyxHQUFKLENBQVFiLENBQVIsRUFBV2MsTUFBWCxHQUFvQixNQUFwQjtBQUVIO0FBQ0osT0FuQkQsQ0FxQkE7QUFyQkEsV0FzQkssSUFDQXZDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjeEIsU0FBZCxLQUE0QixNQUE1QixJQUFzQyxLQUFLQSxTQUFMLEtBQW1CLE9BQXpELElBQW9FLEtBQUswQixJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUFoRyxJQUNENUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWN4QixTQUFkLEtBQTRCLE9BQTVCLElBQXVDLEtBQUtBLFNBQUwsS0FBbUIsTUFBMUQsSUFBb0UsS0FBSzBCLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBRi9GLEVBRW9HO0FBRXJHLGNBQUdLLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLEtBQTJDLEtBQUt2QixVQUFoRCxJQUNINEIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEM0IsSUFFSDhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQUZsQyxFQUVpRDtBQUU5Q0gsWUFBQUEsR0FBRyxDQUFDc0MsR0FBSixDQUFRYixDQUFSLEVBQVdjLE1BQVgsR0FBb0IsVUFBcEI7QUFDRixXQUxELE1BTUssSUFBRyxLQUFLbEMsVUFBTCxHQUFrQjRCLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUMsQ0FBVixHQUFjNUIsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNHLENBQXJDLENBQWxCLElBQTZESyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLUCxJQUFMLENBQVVDLENBQVYsR0FBYzVCLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjRyxDQUFyQyxLQUNqRSxLQUFLdEIsT0FERCxJQUNZMkIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFEMUMsSUFDMkQ4QixJQUFJLENBQUNDLEdBQUwsQ0FBU2xDLEdBQUcsQ0FBQzZCLE1BQUosQ0FBV0osQ0FBWCxFQUFjTSxDQUF2QixLQUE2QixLQUFLNUIsYUFEaEcsRUFDK0c7QUFFaEg7QUFDQUgsWUFBQUEsR0FBRyxDQUFDc0MsR0FBSixDQUFRYixDQUFSLEVBQVdjLE1BQVgsR0FBb0IsV0FBcEI7QUFFSCxXQU5JLE1BT0EsSUFBR04sSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVQyxDQUFWLEdBQWM1QixHQUFHLENBQUM2QixNQUFKLENBQVdKLENBQVgsRUFBY0csQ0FBckMsSUFBMEMsS0FBS3RCLE9BQS9DLElBQTBEMkIsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1AsSUFBTCxDQUFVSSxDQUFuQixLQUF5QixLQUFLNUIsYUFBeEYsSUFDTDhCLElBQUksQ0FBQ0MsR0FBTCxDQUFTbEMsR0FBRyxDQUFDNkIsTUFBSixDQUFXSixDQUFYLEVBQWNNLENBQXZCLEtBQTZCLEtBQUs1QixhQURoQyxFQUMrQztBQUVoRDtBQUNBSCxZQUFBQSxHQUFHLENBQUNzQyxHQUFKLENBQVFiLENBQVIsRUFBV2MsTUFBWCxHQUFvQixNQUFwQjtBQUVIO0FBQ0osU0F4QkksTUF5QkE7QUFDRHZDLFVBQUFBLEdBQUcsQ0FBQ3NDLEdBQUosQ0FBUWIsQ0FBUixFQUFXYyxNQUFYLEdBQW9CLEVBQXBCO0FBQ0g7QUFDSixLQTFNcUIsQ0EyTXRCO0FBQ0E7O0FBQ0gsR0F4Ukk7QUEwUkw7QUFDQWYsRUFBQUEsYUFBYSxFQUFFLHlCQUFXO0FBRXRCLFFBQUl4QixHQUFHLEdBQUMsS0FBS0EsR0FBTCxDQUFTZ0IsWUFBVCxDQUFzQixLQUF0QixDQUFSLENBRnNCLENBR3RCO0FBQ0E7O0FBQ0EsUUFBR2lCLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEtBQUtQLElBQUwsQ0FBVUksQ0FBVixHQUFjL0IsR0FBRyxDQUFDd0MsWUFBSixDQUFpQlQsQ0FBeEMsS0FBOEMsS0FBS3hCLFdBQW5ELElBQ0gsS0FBS1IscUJBQUwsQ0FBMkJpQixZQUEzQixDQUF3QyxZQUF4QyxFQUFzRHlCLFdBQXRELEtBQXNFLEtBRG5FLElBRUF6QyxHQUFHLENBQUN3QyxZQUFKLENBQWlCWixDQUFqQixJQUFzQixHQUZ6QixFQUU4QjtBQUUxQjtBQUNBLFVBQUcsS0FBSzNCLFNBQUwsSUFBa0IsTUFBbEIsSUFBNEJnQyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLZCxLQUFMLEdBQWEsS0FBS08sSUFBTCxDQUFVSSxDQUFoQyxLQUFxQyxFQUFwRSxFQUF3RTtBQUNwRSxhQUFLaEMscUJBQUwsQ0FBMkIyQyxhQUEzQixDQUF5QyxJQUFJcEQsRUFBRSxDQUFDcUQsS0FBSCxDQUFTQyxXQUFiLENBQXlCLHVCQUF6QixDQUF6QztBQUNBLGFBQUt4QixLQUFMLEdBQWEsS0FBS08sSUFBTCxDQUFVSSxDQUF2QjtBQUNILE9BTnlCLENBTzFCOztBQUNIO0FBQ0osR0EzU0k7QUE2U0xjLEVBQUFBLGdCQUFnQixFQUFFLDBCQUFVQyxLQUFWLEVBQWlCQyxJQUFqQixFQUF1QjtBQUNyQ0MsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBS3ZDLE1BQWpCOztBQUNBLFFBQUcsS0FBS0EsTUFBTCxJQUFhLENBQWhCLEVBQWtCO0FBQ2QsV0FBS0ksUUFBTCxDQUFjSSxTQUFkLENBQXdCLE1BQXhCO0FBQ0E4QixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaO0FBQ0g7O0FBQ0EsU0FBS3ZDLE1BQUwsR0FBWW9DLEtBQUssQ0FBQ0ksR0FBbEI7QUFDQUYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBS3ZDLE1BQWpCO0FBQ0gsR0FyVEc7QUFzVEx5QyxFQUFBQSxlQUFlLEVBQUUsMkJBQVc7QUFDdkIsU0FBS3pDLE1BQUwsR0FBWSxDQUFaO0FBQ0g7QUF4VEcsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHJlZmVyZW5jZU5vZGU6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy/ooqvkvKDmn5PnmoTmpoLnjodcclxuICAgICAgICBpbmZlY3RQb3NzaWJpbGl0eTogMSxcclxuICAgICAgICAvL+WFs+iBlOaPkOekuuahhlxyXG4gICAgICAgIC8vc2FtZU9uY2U6IGNjLk5vZGUsXHJcbiAgICAgICAgLy9zYW1lVHdpY2U6IGNjLk5vZGUsXHJcbiAgICAgICAgLy9vcHBvc2l0ZU9uY2U6IGNjLk5vZGUsXHJcbiAgICAgICAgLy9vcHBvc2l0ZVR3aWNlOiBjYy5Ob2RlLFxyXG4gICAgICAgIG5laWdoYm9yOiBjYy5Ob2RlLFxyXG4gICAgICAgIG5laWdoYm9yU2hvcnREaXN0YW5jZTogY2MuTm9kZSxcclxuICAgICAgICAvL+WFs+iBlOWFtuS7luS5mOWuolxyXG4gICAgICAgIG5wYzogY2MuTm9kZSxcclxuICAgICAgICAvL+enu+WKqOaWueWQkVxyXG4gICAgICAgIGRpcmVjdGlvbjpjYy5TdHJpbmcsXHJcbiAgICAgICAgLy/otbDlu4rlrr3luqbnmoTkuIDljYpcclxuICAgICAgICBjb3JyaWRvcldpZHRoOjg1LFxyXG4gICAgICAgIC8v6LWw5buK6ZW/5bqm55qE5LiA5Y2KXHJcbiAgICAgICAgY29ycmlkb3JMZW5ndGg6MzYwLFxyXG4gICAgICAgIC8v6Z2i5a+56Z2i5pyA5bCP6Led56a7XHJcbiAgICAgICAgZmFjZURpc0xpbToxMDAsXHJcbiAgICAgICAgLy/kuIDoiKzot53nprtcclxuICAgICAgICBmYWNlRGlzOjQ4MCxcclxuICAgICAgICAvL+mCu+W6p+i3neemu1xyXG4gICAgICAgIG5laWdoYm9yRGlzOjYwLFxyXG4gICAgICAgIC8v5Y+v6IO95oCn5oiR5a6e5Zyo5YiG5LiN5Ye65p2l5LqG77yM5pyA5aW95YiG5LiA5LiLXHJcblxyXG4gICAgICAgIGNoZWNoTGFiZWw6Y2MuTGFiZWwsXHJcblxyXG4gICAgICAgIG9uQnVtcDowLFxyXG5cclxuICAgICAgICBoYXNXYXNoZWRIYW5kc0JlZm9yZTogZmFsc2UsXHJcbiAgICAgICAgaGFzV2FzaGVkSGFuZHNBZnRlcjogZmFsc2UsXHJcbiAgICAgICAgaGFzUmVsZWFzZWQ6IGZhbHNlLFxyXG4gICAgICAgIGF1ZGlvTWdyOmNjLk5vZGVcclxuXHJcblxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHJcbiAgICAgICAgdGhpcy5ucGMgPSB0aGlzLm5wYy5nZXRDb21wb25lbnQoJ25wYycpO1xyXG4gICAgICAgIHRoaXMuZGlyZWN0aW9uID0gJ2xlZnQnO1xyXG4gICAgICAgIHRoaXMuY29ycmlkb3JXaWR0aD04NTsvL+WlveWDj+acieeCueWwj1xyXG4gICAgICAgIHRoaXMuY29ycmlkb3JMZW5ndGg9MzYwO1xyXG4gICAgICAgIHRoaXMuZmFjZURpc0xpbT0xMDA7XHJcbiAgICAgICAgdGhpcy5mYWNlRGlzPTQ4MDtcclxuICAgICAgICB0aGlzLm5laWdoYm9yRGlzPTYwO1xyXG4gICAgICAgIHRoaXMuYXVkaW9NZ3I9dGhpcy5hdWRpb01nci5nZXRDb21wb25lbnQoXCJBdWRpb01nclwiKTtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICB0aGlzLmF1ZGlvTWdyLnBsYXlNdXNpYyhcInRyYWluTXVzaWNcIik7XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpLDUpO1xyXG5cclxuICAgICAgICB0aGlzLmxhc3RZID0gNzU7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBzdGFydCAoKSB7XHJcbiAgICAvLyB9LFxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmp1ZGdlRGlzdGFuY2UoKTtcclxuICAgICAgICB0aGlzLmp1ZGdlTmVpZ2hib3IoKTtcclxuICAgIH0sXHJcblxyXG4gICAgLy/liKTmlq1nYW1lUGxheWVy5ZKMbnBj55qE6Led56a7XHJcbiAgICBqdWRnZURpc3RhbmNlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgbnBjID0gdGhpcy5ucGMuZ2V0Q29tcG9uZW50KCducGMnKTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKHRoaXMubnBjLm90aGVyc1swXS54LXRoaXMubm9kZS54KTtcclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICBmb3IodmFyIGkgPSAwOyBpIDw9IDg7IGkrKykge1xyXG4gICAgICAgICAgICB2YXIgRHg9dGhpcy5ub2RlLnggLSBucGMub3RoZXJzW2ldLng7XHJcbiAgICAgICAgICAgIHZhciBEeT10aGlzLm5vZGUueSAtIG5wYy5vdGhlcnNbaV0ueTtcclxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhucGMub3RoZXJzW2ldLmlzVmlzaXRlZCk7XHJcbiAgICAgICAgICAgIC8v5LuO6IOM5ZCO6Led56a75LiN6Laz5aSf5aSn55qE5oOF5Ya1XHJcbiAgICAgICAgICAgIGlmKG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkID09PSBmYWxzZSAmJiBucGMub3RoZXJzW2ldLmRpcmVjdGlvbiA9PT0gdGhpcy5kaXJlY3Rpb24gJiYgXHJcbiAgICAgICAgICAgICAgICAodGhpcy5kaXJlY3Rpb24gPT09ICdsZWZ0JyAmJiB0aGlzLm5vZGUueCA8IG5wYy5vdGhlcnNbaV0ueCB8fFxyXG4gICAgICAgICAgICAgICAgIHRoaXMuZGlyZWN0aW9uID09PSAncmlnaHQnICYmIHRoaXMubm9kZS54ID4gbnBjLm90aGVyc1tpXS54KSkge1xyXG5cclxuICAgICAgICAgICAgICAgIGlmKE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSA8PSB0aGlzLmNvcnJpZG9yTGVuZ3RoICYmIFxyXG4gICAgICAgICAgICAgICAgTWF0aC5hYnModGhpcy5ub2RlLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCAmJiBNYXRoLmFicyhucGMub3RoZXJzW2ldLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZihucGMub3RoZXJzW2ldLmlzVmlzaXRlZFNhbWVPbmNlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gNDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluZmVjdFBvc3NpYmlsaXR5ICs9IDc7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy/lvLnlh7rmj5DnpLrmoYZcclxuICAgICAgICAgICAgICAgICAgICAvL3RoaXMuc2FtZVR3aWNlLmRpc3BhdGNoRXZlbnQobmV3IGNjLkV2ZW50LkV2ZW50Q3VzdG9tKFwiU2FtZVR3aWNlMDFcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuiDjOWQjuacieS6uui3neemu+acgOi/kVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRTYW1lT25jZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZFNhbWVPbmNlKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRPcHBvc2l0ZU9uY2VcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZE9wcG9zaXRlVHdpY2VcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlKTtcclxuICAgICAgICAgICAgICAgICAgICAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2FtZVBsYXllci5kaXJlY3Rpb25cIiwgdGhpcy5kaXJlY3Rpb24pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBucGMub3RoZXJzW2ldLmRpcmVjdGlvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi6IOM5ZCO5pyJ5Lq66Led56a75pyA6L+RXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmKHRoaXMuY29ycmlkb3JMZW5ndGggPCBNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgJiYgXHJcbiAgICAgICAgICAgICAgICBNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgPD0gMip0aGlzLmNvcnJpZG9yTGVuZ3RoICYmIFxyXG4gICAgICAgICAgICAgICAgTWF0aC5hYnModGhpcy5ub2RlLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCAmJiBNYXRoLmFicyhucGMub3RoZXJzW2ldLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGlmKG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkU2FtZU9uY2UgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gMztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRTYW1lT25jZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZFNhbWVPbmNlXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkU2FtZU9uY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZE9wcG9zaXRlT25jZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZE9wcG9zaXRlT25jZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZE9wcG9zaXRlVHdpY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJnYW1lUGxheWVyLmRpcmVjdGlvblwiLCB0aGlzLmRpcmVjdGlvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIG5wYy5vdGhlcnNbaV0uZGlyZWN0aW9uKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLog4zlkI7mnInkurpcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgKi9cclxuICAgICAgICAgICAgICAgICAgICAvL+W8ueWHuuaPkOekuuahhlxyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5zYW1lT25jZS5kaXNwYXRjaEV2ZW50KG5ldyBjYy5FdmVudC5FdmVudEN1c3RvbShcIlNhbWVPbmNlMDFcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuiDjOWQjuacieS6ulwiO1xyXG5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/pnaLlr7npnaLot53nprvkuI3lpJ/lpKfnmoTmg4XlhrVcclxuICAgICAgICAgICAgZWxzZSBpZihucGMub3RoZXJzW2ldLmlzVmlzaXRlZCA9PT0gZmFsc2UgJiYgXHJcbiAgICAgICAgICAgICAgICAobnBjLm90aGVyc1tpXS5kaXJlY3Rpb24gPT09ICdsZWZ0JyAmJiB0aGlzLmRpcmVjdGlvbiA9PT0gJ3JpZ2h0JyAmJiB0aGlzLm5vZGUueCA8IG5wYy5vdGhlcnNbaV0ueCB8fCBcclxuICAgICAgICAgICAgICAgIG5wYy5vdGhlcnNbaV0uZGlyZWN0aW9uID09PSAncmlnaHQnICYmIHRoaXMuZGlyZWN0aW9uID09PSAnbGVmdCcgJiYgdGhpcy5ub2RlLnggPiBucGMub3RoZXJzW2ldLnggKSkge1xyXG5cclxuICAgICAgICAgICAgICAgIGlmKE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSA8PSB0aGlzLmZhY2VEaXNMaW0gJiYgXHJcbiAgICAgICAgICAgICAgICBNYXRoLmFicyh0aGlzLm5vZGUueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoICYmIFxyXG4gICAgICAgICAgICAgICAgTWF0aC5hYnMobnBjLm90aGVyc1tpXS55KSA8PSB0aGlzLmNvcnJpZG9yV2lkdGgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYobnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UgPT09IHRydWUgJiYgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gMTA7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmKG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkT3Bwb3NpdGVPbmNlID09PSB0cnVlICYmIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pbmZlY3RQb3NzaWJpbGl0eSArPSAyMDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYobnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UgPT09IGZhbHNlICYmIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmluZmVjdFBvc3NpYmlsaXR5ICs9IDEwO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gMjU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZFwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkU2FtZU9uY2VcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRTYW1lT25jZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkT3Bwb3NpdGVPbmNlXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkT3Bwb3NpdGVPbmNlKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgKi9cclxuICAgICAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcImdhbWVQbGF5ZXIuZGlyZWN0aW9uXCIsIHRoaXMuZGlyZWN0aW9uKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgbnBjLm90aGVyc1tpXS5kaXJlY3Rpb24pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIuato+mdouacieS6uui3neemu+acgOi/kVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAqL1xyXG5cclxuICAgICAgICAgICAgICAgICAgIC8vbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuato+mdouacieS6uui3neemu+acgOi/kVwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZih0aGlzLmZhY2VEaXNMaW0gPCBNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgJiYgTWF0aC5hYnModGhpcy5ub2RlLnggLSBucGMub3RoZXJzW2ldLngpIDw9IFxyXG4gICAgICAgICAgICAgICAgdGhpcy5mYWNlRGlzICYmIE1hdGguYWJzKHRoaXMubm9kZS55KSA8PSB0aGlzLmNvcnJpZG9yV2lkdGggJiYgTWF0aC5hYnMobnBjLm90aGVyc1tpXS55KSA8PSB0aGlzLmNvcnJpZG9yV2lkdGgpIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYobnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihucGMub3RoZXJzW2ldLmlzVmlzaXRlZE9wcG9zaXRlT25jZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pbmZlY3RQb3NzaWJpbGl0eSArPSAxMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gMTU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8v5by55Ye65o+Q56S65qGGXHJcbiAgICAgICAgICAgICAgICAgICAgLy90aGlzLm9wcG9zaXRlVHdpY2UuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJPcHBvc2l0ZVR3aWNlMDFcIikpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuato+mdouacieS6uui3neemu+avlOi+g+i/kVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRTYW1lT25jZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZFNhbWVPbmNlKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRPcHBvc2l0ZU9uY2VcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZE9wcG9zaXRlVHdpY2VcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZVR3aWNlKTtcclxuICAgICAgICAgICAgICAgICAgICAqL1xyXG4gICAgICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwiZ2FtZVBsYXllci5kaXJlY3Rpb25cIiwgdGhpcy5kaXJlY3Rpb24pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBucGMub3RoZXJzW2ldLmRpcmVjdGlvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwi5q2j6Z2i5pyJ5Lq66Led56a75q+U6L6D6L+RXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmKE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSA+IHRoaXMuZmFjZURpcyAmJiBNYXRoLmFicyh0aGlzLm5vZGUueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoICYmIE1hdGguYWJzKG5wYy5vdGhlcnNbaV0ueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgaWYobnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuaW5mZWN0UG9zc2liaWxpdHkgKz0gNTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWRPcHBvc2l0ZU9uY2UgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvL+W8ueWHuuaPkOekuuahhlxyXG4gICAgICAgICAgICAgICAgICAgIC8vdGhpcy5vcHBvc2l0ZU9uY2UuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJPcHBvc2l0ZU9uY2UwMVwiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy9ucGMudGlwW2ldLnN0cmluZyA9IFwi5q2j6Z2i5pyJ5Lq6XCI7XHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJvdGhlcnNcIiwgaSwgXCJpc1Zpc2l0ZWRcIiwgbnBjLm90aGVyc1tpXS5pc1Zpc2l0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZFNhbWVPbmNlXCIsIG5wYy5vdGhlcnNbaV0uaXNWaXNpdGVkU2FtZU9uY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIm90aGVyc1wiLCBpLCBcImlzVmlzaXRlZE9wcG9zaXRlT25jZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZE9wcG9zaXRlT25jZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIFwiaXNWaXNpdGVkT3Bwb3NpdGVUd2ljZVwiLCBucGMub3RoZXJzW2ldLmlzVmlzaXRlZE9wcG9zaXRlVHdpY2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCJnYW1lUGxheWVyLmRpcmVjdGlvblwiLCB0aGlzLmRpcmVjdGlvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKFwib3RoZXJzXCIsIGksIG5wYy5vdGhlcnNbaV0uZGlyZWN0aW9uKTtcclxuICAgICAgICAgICAgICAgICAgICBjYy5sb2coXCLmraPpnaLmnInkurpcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgKi9cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vbnBjLnRpcFtpXS5zdHJpbmcgPSBcIlwiO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZihucGMub3RoZXJzW2ldLmRpcmVjdGlvbiA9PT0gdGhpcy5kaXJlY3Rpb24gJiYgXHJcbiAgICAgICAgICAgICAgICAodGhpcy5kaXJlY3Rpb24gPT09ICdsZWZ0JyAmJiB0aGlzLm5vZGUueCA8IG5wYy5vdGhlcnNbaV0ueCB8fFxyXG4gICAgICAgICAgICAgICAgIHRoaXMuZGlyZWN0aW9uID09PSAncmlnaHQnICYmIHRoaXMubm9kZS54ID4gbnBjLm90aGVyc1tpXS54KSkge1xyXG5cclxuICAgICAgICAgICAgICAgIGlmKE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSA8PSB0aGlzLmNvcnJpZG9yTGVuZ3RoICYmIFxyXG4gICAgICAgICAgICAgICAgTWF0aC5hYnModGhpcy5ub2RlLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCAmJiBNYXRoLmFicyhucGMub3RoZXJzW2ldLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvL+W8ueWHuuaPkOekulxyXG4gICAgICAgICAgICAgICAgICAgIG5wYy50aXBbaV0uc3RyaW5nID0gXCLog4zlkI7mnInkurrot53nprvmnIDov5FcIjtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYodGhpcy5jb3JyaWRvckxlbmd0aCA8IE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSAmJiBcclxuICAgICAgICAgICAgICAgIE1hdGguYWJzKHRoaXMubm9kZS54IC0gbnBjLm90aGVyc1tpXS54KSA8PSAyKnRoaXMuY29ycmlkb3JMZW5ndGggJiYgXHJcbiAgICAgICAgICAgICAgICBNYXRoLmFicyh0aGlzLm5vZGUueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoICYmIE1hdGguYWJzKG5wYy5vdGhlcnNbaV0ueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAvL+W8ueWHuuaPkOekulxyXG4gICAgICAgICAgICAgICAgICAgIG5wYy50aXBbaV0uc3RyaW5nID0gXCLog4zlkI7mnInkurpcIjtcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8v6Z2i5a+56Z2i6Led56a75LiN5aSf5aSn55qE5oOF5Ya1XHJcbiAgICAgICAgICAgIGVsc2UgaWYoIFxyXG4gICAgICAgICAgICAgICAgKG5wYy5vdGhlcnNbaV0uZGlyZWN0aW9uID09PSAnbGVmdCcgJiYgdGhpcy5kaXJlY3Rpb24gPT09ICdyaWdodCcgJiYgdGhpcy5ub2RlLnggPCBucGMub3RoZXJzW2ldLnggfHwgXHJcbiAgICAgICAgICAgICAgICBucGMub3RoZXJzW2ldLmRpcmVjdGlvbiA9PT0gJ3JpZ2h0JyAmJiB0aGlzLmRpcmVjdGlvbiA9PT0gJ2xlZnQnICYmIHRoaXMubm9kZS54ID4gbnBjLm90aGVyc1tpXS54ICkpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgPD0gdGhpcy5mYWNlRGlzTGltICYmIFxyXG4gICAgICAgICAgICAgICAgTWF0aC5hYnModGhpcy5ub2RlLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCAmJiBcclxuICAgICAgICAgICAgICAgIE1hdGguYWJzKG5wYy5vdGhlcnNbaV0ueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuato+mdouacieS6uui3neemu+acgOi/kVwiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZih0aGlzLmZhY2VEaXNMaW0gPCBNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgJiYgTWF0aC5hYnModGhpcy5ub2RlLnggLSBucGMub3RoZXJzW2ldLngpXHJcbiAgICAgICAgICAgICAgICAgPD0gdGhpcy5mYWNlRGlzICYmIE1hdGguYWJzKHRoaXMubm9kZS55KSA8PSB0aGlzLmNvcnJpZG9yV2lkdGggJiYgTWF0aC5hYnMobnBjLm90aGVyc1tpXS55KSA8PSB0aGlzLmNvcnJpZG9yV2lkdGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAvL+W8ueWHuuaPkOekulxyXG4gICAgICAgICAgICAgICAgICAgIG5wYy50aXBbaV0uc3RyaW5nID0gXCLmraPpnaLmnInkurrot53nprvmr5TovoPov5FcIjtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZihNYXRoLmFicyh0aGlzLm5vZGUueCAtIG5wYy5vdGhlcnNbaV0ueCkgPiB0aGlzLmZhY2VEaXMgJiYgTWF0aC5hYnModGhpcy5ub2RlLnkpIDw9IHRoaXMuY29ycmlkb3JXaWR0aCBcclxuICAgICAgICAgICAgICAgICYmIE1hdGguYWJzKG5wYy5vdGhlcnNbaV0ueSkgPD0gdGhpcy5jb3JyaWRvcldpZHRoKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8v5by55Ye65o+Q56S6XHJcbiAgICAgICAgICAgICAgICAgICAgbnBjLnRpcFtpXS5zdHJpbmcgPSBcIuato+mdouacieS6ulwiO1xyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBucGMudGlwW2ldLnN0cmluZyA9IFwiXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY29uc29sZS5pbmZvKHRoaXMuZGlyZWN0aW9uKTtcclxuICAgICAgICAvLyBjb25zb2xlLmluZm8odGhpcy5pbmZlY3RQb3NzaWJpbGl0eSk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8v5Yik5pat6YK75bqn5piv5ZCm5pyJ5Lq6XHJcbiAgICBqdWRnZU5laWdoYm9yOiBmdW5jdGlvbigpIHtcclxuXHJcbiAgICAgICAgdmFyIG5wYz10aGlzLm5wYy5nZXRDb21wb25lbnQoJ25wYycpO1xyXG4gICAgICAgIC8vY2MubG9nKFwi546p5a6255qEeeWdkOagh++8mlwiLCB0aGlzLm5vZGUueSk7XHJcbiAgICAgICAgLy9jYy5sb2coXCLpgrvluqfnmoR55Z2Q5qCH77yaXCIsIG5wYy5uZWlnaGJvclNlYXQueSk7XHJcbiAgICAgICAgaWYoTWF0aC5hYnModGhpcy5ub2RlLnkgLSBucGMubmVpZ2hib3JTZWF0LnkpIDw9IHRoaXMubmVpZ2hib3JEaXMgJiYgXHJcbiAgICAgICAgdGhpcy5uZWlnaGJvclNob3J0RGlzdGFuY2UuZ2V0Q29tcG9uZW50KCduZWlnaGJvckpTJykuaGFzTGF1bmNoZWQgPT09IGZhbHNlXHJcbiAgICAgICAgJiYgbnBjLm5laWdoYm9yU2VhdC54IDw9IDc5MCkge1xyXG5cclxuICAgICAgICAgICAgLy/lvLnlh7rmj5DnpLrmoYZcclxuICAgICAgICAgICAgaWYodGhpcy5kaXJlY3Rpb24gPT0gJ2Rvd24nICYmIE1hdGguYWJzKHRoaXMubGFzdFkgLSB0aGlzLm5vZGUueSkgPj0xMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5uZWlnaGJvclNob3J0RGlzdGFuY2UuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJzaG9ydERpc3RhbmNlTmVpZ2hib3JcIikpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sYXN0WSA9IHRoaXMubm9kZS55O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vdGhpcy5uZWlnaGJvclNob3J0RGlzdGFuY2UuZGlzcGF0Y2hFdmVudChuZXcgY2MuRXZlbnQuRXZlbnRDdXN0b20oXCJzaG9ydERpc3RhbmNlTmVpZ2hib3JcIikpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgb25Db2xsaXNpb25FbnRlcjogZnVuY3Rpb24gKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5vbkJ1bXApO1xyXG4gICAgICAgIGlmKHRoaXMub25CdW1wPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5hdWRpb01nci5wbGF5TXVzaWMoXCJidW1wXCIpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInBhbFwiKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgIHRoaXMub25CdW1wPW90aGVyLnRhZztcclxuICAgICAgICAgY29uc29sZS5sb2codGhpcy5vbkJ1bXApO1xyXG4gICAgIH0sXHJcbiAgICBvbkNvbGxpc2lvbkV4aXQ6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgICB0aGlzLm9uQnVtcD0wO1xyXG4gICAgIH0sXHJcbiBcclxufSk7XHJcbiJdfQ==