
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/家园/script/jiayuanCtrl.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ae0333uYxRMd7GWxIW+NjF0', 'jiayuanCtrl');
// 家园/script/jiayuanCtrl.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    newsPanel: cc.Node,
    ourMessage: cc.Node,
    webBox: cc.WebView,
    now: 0,
    news: 0,
    nowLabel: cc.Label
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.news = ["https://ncov.dxy.cn/ncovh5/view/pneumonia"];
    this.newsTitle = ["丁香园疫情实况"];
    this.now = 0;
    this.webBox.url = this.news[this.now];
    this.nowLabel.string = this.newsTitle[this.now];
  },
  previousNews: function previousNews() {
    if (this.now == 0) {
      this.nowLabel.string = "前面没有了哦";
    } else {
      this.now -= 1;
      this.webBox.url = this.news[this.now];
      this.nowLabel.string = this.newsTitle[this.now];
    }
  },
  nextNews: function nextNews() {
    if (this.now == this.news.length - 1) {
      this.nowLabel.string = "后面没有了哦";
    } else {
      this.now += 1;
      this.webBox.url = this.news[this.now];
      this.nowLabel.string = this.newsTitle[this.now];
    }
  },
  openNews: function openNews() {
    this.newsPanel.active = true;
  },
  closeNews: function closeNews() {
    this.newsPanel.active = false;
  },
  openMessage: function openMessage() {
    this.ourMessage.active = true;
  },
  closeMessage: function closeMessage() {
    this.ourMessage.active = false;
  },
  returnBack: function returnBack() {
    cc.director.loadScene("衔接场景");
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc5a625ZutXFxzY3JpcHRcXGppYXl1YW5DdHJsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibmV3c1BhbmVsIiwiTm9kZSIsIm91ck1lc3NhZ2UiLCJ3ZWJCb3giLCJXZWJWaWV3Iiwibm93IiwibmV3cyIsIm5vd0xhYmVsIiwiTGFiZWwiLCJzdGFydCIsIm5ld3NUaXRsZSIsInVybCIsInN0cmluZyIsInByZXZpb3VzTmV3cyIsIm5leHROZXdzIiwibGVuZ3RoIiwib3Blbk5ld3MiLCJhY3RpdmUiLCJjbG9zZU5ld3MiLCJvcGVuTWVzc2FnZSIsImNsb3NlTWVzc2FnZSIsInJldHVybkJhY2siLCJkaXJlY3RvciIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFNBQVMsRUFBQ0osRUFBRSxDQUFDSyxJQURMO0FBRVJDLElBQUFBLFVBQVUsRUFBQ04sRUFBRSxDQUFDSyxJQUZOO0FBR1JFLElBQUFBLE1BQU0sRUFBQ1AsRUFBRSxDQUFDUSxPQUhGO0FBSVJDLElBQUFBLEdBQUcsRUFBQyxDQUpJO0FBS1JDLElBQUFBLElBQUksRUFBQyxDQUxHO0FBTVJDLElBQUFBLFFBQVEsRUFBQ1gsRUFBRSxDQUFDWTtBQU5KLEdBSFA7QUFZTDtBQUVBO0FBRUFDLEVBQUFBLEtBaEJLLG1CQWdCSTtBQUNMLFNBQUtILElBQUwsR0FBVSxDQUFDLDJDQUFELENBQVY7QUFDQSxTQUFLSSxTQUFMLEdBQWUsQ0FBQyxTQUFELENBQWY7QUFDQSxTQUFLTCxHQUFMLEdBQVMsQ0FBVDtBQUNBLFNBQUtGLE1BQUwsQ0FBWVEsR0FBWixHQUFnQixLQUFLTCxJQUFMLENBQVUsS0FBS0QsR0FBZixDQUFoQjtBQUNBLFNBQUtFLFFBQUwsQ0FBY0ssTUFBZCxHQUFxQixLQUFLRixTQUFMLENBQWUsS0FBS0wsR0FBcEIsQ0FBckI7QUFDSCxHQXRCSTtBQXdCTFEsRUFBQUEsWUF4QkssMEJBd0JTO0FBQ1YsUUFBRyxLQUFLUixHQUFMLElBQVUsQ0FBYixFQUFlO0FBQ1gsV0FBS0UsUUFBTCxDQUFjSyxNQUFkLEdBQXFCLFFBQXJCO0FBQ0gsS0FGRCxNQUdJO0FBQ0EsV0FBS1AsR0FBTCxJQUFVLENBQVY7QUFDQSxXQUFLRixNQUFMLENBQVlRLEdBQVosR0FBZ0IsS0FBS0wsSUFBTCxDQUFVLEtBQUtELEdBQWYsQ0FBaEI7QUFDQSxXQUFLRSxRQUFMLENBQWNLLE1BQWQsR0FBcUIsS0FBS0YsU0FBTCxDQUFlLEtBQUtMLEdBQXBCLENBQXJCO0FBQ0g7QUFFSixHQWxDSTtBQW9DTFMsRUFBQUEsUUFwQ0ssc0JBb0NLO0FBQ04sUUFBRyxLQUFLVCxHQUFMLElBQVUsS0FBS0MsSUFBTCxDQUFVUyxNQUFWLEdBQWlCLENBQTlCLEVBQWdDO0FBQzVCLFdBQUtSLFFBQUwsQ0FBY0ssTUFBZCxHQUFxQixRQUFyQjtBQUNILEtBRkQsTUFHSTtBQUNBLFdBQUtQLEdBQUwsSUFBVSxDQUFWO0FBQ0EsV0FBS0YsTUFBTCxDQUFZUSxHQUFaLEdBQWdCLEtBQUtMLElBQUwsQ0FBVSxLQUFLRCxHQUFmLENBQWhCO0FBQ0EsV0FBS0UsUUFBTCxDQUFjSyxNQUFkLEdBQXFCLEtBQUtGLFNBQUwsQ0FBZSxLQUFLTCxHQUFwQixDQUFyQjtBQUNIO0FBQ0osR0E3Q0k7QUErQ0xXLEVBQUFBLFFBL0NLLHNCQStDSztBQUNOLFNBQUtoQixTQUFMLENBQWVpQixNQUFmLEdBQXNCLElBQXRCO0FBQ0gsR0FqREk7QUFtRExDLEVBQUFBLFNBbkRLLHVCQW1ETTtBQUNQLFNBQUtsQixTQUFMLENBQWVpQixNQUFmLEdBQXNCLEtBQXRCO0FBQ0gsR0FyREk7QUF1RExFLEVBQUFBLFdBdkRLLHlCQXVEUTtBQUNULFNBQUtqQixVQUFMLENBQWdCZSxNQUFoQixHQUF1QixJQUF2QjtBQUNILEdBekRJO0FBMERMRyxFQUFBQSxZQTFESywwQkEwRFM7QUFDVixTQUFLbEIsVUFBTCxDQUFnQmUsTUFBaEIsR0FBdUIsS0FBdkI7QUFDSCxHQTVESTtBQThETEksRUFBQUEsVUE5REssd0JBOERPO0FBQ1J6QixJQUFBQSxFQUFFLENBQUMwQixRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSCxHQWhFSSxDQWlFTDs7QUFqRUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG5ld3NQYW5lbDpjYy5Ob2RlLFxyXG4gICAgICAgIG91ck1lc3NhZ2U6Y2MuTm9kZSxcclxuICAgICAgICB3ZWJCb3g6Y2MuV2ViVmlldyxcclxuICAgICAgICBub3c6MCxcclxuICAgICAgICBuZXdzOjAsXHJcbiAgICAgICAgbm93TGFiZWw6Y2MuTGFiZWwsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5uZXdzPVtcImh0dHBzOi8vbmNvdi5keHkuY24vbmNvdmg1L3ZpZXcvcG5ldW1vbmlhXCJdO1xyXG4gICAgICAgIHRoaXMubmV3c1RpdGxlPVtcIuS4gemmmeWbreeWq+aDheWunuWGtVwiXTtcclxuICAgICAgICB0aGlzLm5vdz0wO1xyXG4gICAgICAgIHRoaXMud2ViQm94LnVybD10aGlzLm5ld3NbdGhpcy5ub3ddO1xyXG4gICAgICAgIHRoaXMubm93TGFiZWwuc3RyaW5nPXRoaXMubmV3c1RpdGxlW3RoaXMubm93XTtcclxuICAgIH0sXHJcblxyXG4gICAgcHJldmlvdXNOZXdzKCl7XHJcbiAgICAgICAgaWYodGhpcy5ub3c9PTApe1xyXG4gICAgICAgICAgICB0aGlzLm5vd0xhYmVsLnN0cmluZz1cIuWJjemdouayoeacieS6huWTplwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICB0aGlzLm5vdy09MTtcclxuICAgICAgICAgICAgdGhpcy53ZWJCb3gudXJsPXRoaXMubmV3c1t0aGlzLm5vd107XHJcbiAgICAgICAgICAgIHRoaXMubm93TGFiZWwuc3RyaW5nPXRoaXMubmV3c1RpdGxlW3RoaXMubm93XTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIG5leHROZXdzKCl7XHJcbiAgICAgICAgaWYodGhpcy5ub3c9PXRoaXMubmV3cy5sZW5ndGgtMSl7XHJcbiAgICAgICAgICAgIHRoaXMubm93TGFiZWwuc3RyaW5nPVwi5ZCO6Z2i5rKh5pyJ5LqG5ZOmXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIHRoaXMubm93Kz0xO1xyXG4gICAgICAgICAgICB0aGlzLndlYkJveC51cmw9dGhpcy5uZXdzW3RoaXMubm93XTtcclxuICAgICAgICAgICAgdGhpcy5ub3dMYWJlbC5zdHJpbmc9dGhpcy5uZXdzVGl0bGVbdGhpcy5ub3ddO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgb3Blbk5ld3MoKXtcclxuICAgICAgICB0aGlzLm5ld3NQYW5lbC5hY3RpdmU9dHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgY2xvc2VOZXdzKCl7XHJcbiAgICAgICAgdGhpcy5uZXdzUGFuZWwuYWN0aXZlPWZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvcGVuTWVzc2FnZSgpe1xyXG4gICAgICAgIHRoaXMub3VyTWVzc2FnZS5hY3RpdmU9dHJ1ZTtcclxuICAgIH0sXHJcbiAgICBjbG9zZU1lc3NhZ2UoKXtcclxuICAgICAgICB0aGlzLm91ck1lc3NhZ2UuYWN0aXZlPWZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICByZXR1cm5CYWNrKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi6KGU5o6l5Zy65pmvXCIpO1xyXG4gICAgfVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=