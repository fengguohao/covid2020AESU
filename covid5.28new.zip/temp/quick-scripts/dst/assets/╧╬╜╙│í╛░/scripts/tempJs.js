
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/衔接场景/scripts/tempJs.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '36eb385L3tL4qxmq4wYgixT', 'tempJs');
// 衔接场景/scripts/tempJs.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    resizableNode: [cc.Node],
    gerenfanghu: cc.Node,
    yiMiaoYanZhi: cc.Node,
    sheQvFangYi: cc.Node,
    yaoYanPanel: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene("个人防护");
    cc.director.preloadScene("疫苗研制");
    cc.director.preloadScene("社区防疫");
    this.node.getChildByName('personalProtectionPageview').active = false;
  },
  start: function start() {
    var speed = 20;
    var time = 2;

    for (var i = 0; i < this.resizableNode.length; i++) {
      if (i % 2 == 0) {
        this.resizableNode[i].runAction(cc.sequence(cc.moveBy(time, 0, -speed), cc.moveBy(time, 0, speed)).repeatForever());
      } else {
        this.resizableNode[i].runAction(cc.sequence(cc.moveBy(time, 0, speed), cc.moveBy(time, 0, -speed)).repeatForever());
      }
    }
  },
  buttonCtrl: function buttonCtrl(event) {
    // if(event.target.name === '个人防护') {
    //     this.node.getChildByName('personalProtectionPageview').active = true;
    // } else if(event.target.name === '人体免疫(总)') {
    //     cc.director.loadScene('人体免疫(总)');
    // }else if()
    switch (event.target.name) {
      case "个人防护":
        this.node.getChildByName('personalProtectionPageview').active = true;
        break;

      case "人体免疫(总)":
        cc.director.loadScene('人体免疫(总)');
        break;

      case "社区防疫":
        this.node.getChildByName('sheqvPageview').active = true;
        break;

      case "疫苗研制":
        this.node.getChildByName('yimiaoPageview').active = true;
        break;

      case "谣言破除":
        this.node.getChildByName('yaoyanPageview').active = true;
        break;

      case "家园":
        cc.director.loadScene('家园');
        break;

      case "退出":
        cc.game.end();
        break;
    }
  },
  onClickPersonalProtection: function onClickPersonalProtection() {
    cc.director.loadScene('个人防护');
  },
  onClickYiMiao: function onClickYiMiao() {
    cc.director.loadScene('疫苗研制');
  },
  onClickSheQv: function onClickSheQv() {
    cc.director.loadScene('社区防疫');
  },
  onClickYaoYan: function onClickYaoYan() {
    cc.director.loadScene('谣言破除');
  } // exitFun(){
  //     cc.game.end();
  // }

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc6KGU5o6l5Zy65pmvXFxzY3JpcHRzXFx0ZW1wSnMuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJyZXNpemFibGVOb2RlIiwiTm9kZSIsImdlcmVuZmFuZ2h1IiwieWlNaWFvWWFuWmhpIiwic2hlUXZGYW5nWWkiLCJ5YW9ZYW5QYW5lbCIsIm9uTG9hZCIsImRpcmVjdG9yIiwicHJlbG9hZFNjZW5lIiwibm9kZSIsImdldENoaWxkQnlOYW1lIiwiYWN0aXZlIiwic3RhcnQiLCJzcGVlZCIsInRpbWUiLCJpIiwibGVuZ3RoIiwicnVuQWN0aW9uIiwic2VxdWVuY2UiLCJtb3ZlQnkiLCJyZXBlYXRGb3JldmVyIiwiYnV0dG9uQ3RybCIsImV2ZW50IiwidGFyZ2V0IiwibmFtZSIsImxvYWRTY2VuZSIsImdhbWUiLCJlbmQiLCJvbkNsaWNrUGVyc29uYWxQcm90ZWN0aW9uIiwib25DbGlja1lpTWlhbyIsIm9uQ2xpY2tTaGVRdiIsIm9uQ2xpY2tZYW9ZYW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxhQUFhLEVBQUMsQ0FBQ0osRUFBRSxDQUFDSyxJQUFKLENBRE47QUFFUkMsSUFBQUEsV0FBVyxFQUFDTixFQUFFLENBQUNLLElBRlA7QUFHUkUsSUFBQUEsWUFBWSxFQUFDUCxFQUFFLENBQUNLLElBSFI7QUFJUkcsSUFBQUEsV0FBVyxFQUFDUixFQUFFLENBQUNLLElBSlA7QUFLUkksSUFBQUEsV0FBVyxFQUFDVCxFQUFFLENBQUNLO0FBTFAsR0FIUDtBQVdMO0FBRUNLLEVBQUFBLE1BYkksb0JBYU07QUFDTlYsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLFlBQVosQ0FBeUIsTUFBekI7QUFDQVosSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLFlBQVosQ0FBeUIsTUFBekI7QUFDQVosSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLFlBQVosQ0FBeUIsTUFBekI7QUFDQSxTQUFLQyxJQUFMLENBQVVDLGNBQVYsQ0FBeUIsNEJBQXpCLEVBQXVEQyxNQUF2RCxHQUFnRSxLQUFoRTtBQUNILEdBbEJHO0FBb0JMQyxFQUFBQSxLQXBCSyxtQkFvQkk7QUFDTCxRQUFJQyxLQUFLLEdBQUMsRUFBVjtBQUNBLFFBQUlDLElBQUksR0FBQyxDQUFUOztBQUNBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDLEtBQUtmLGFBQUwsQ0FBbUJnQixNQUFqQyxFQUF3Q0QsQ0FBQyxFQUF6QyxFQUE0QztBQUN4QyxVQUFHQSxDQUFDLEdBQUMsQ0FBRixJQUFLLENBQVIsRUFBVTtBQUNOLGFBQUtmLGFBQUwsQ0FBbUJlLENBQW5CLEVBQXNCRSxTQUF0QixDQUFnQ3JCLEVBQUUsQ0FBQ3NCLFFBQUgsQ0FBWXRCLEVBQUUsQ0FBQ3VCLE1BQUgsQ0FBVUwsSUFBVixFQUFlLENBQWYsRUFBaUIsQ0FBQ0QsS0FBbEIsQ0FBWixFQUFxQ2pCLEVBQUUsQ0FBQ3VCLE1BQUgsQ0FBVUwsSUFBVixFQUFlLENBQWYsRUFBaUJELEtBQWpCLENBQXJDLEVBQThETyxhQUE5RCxFQUFoQztBQUNILE9BRkQsTUFHSTtBQUNBLGFBQUtwQixhQUFMLENBQW1CZSxDQUFuQixFQUFzQkUsU0FBdEIsQ0FBZ0NyQixFQUFFLENBQUNzQixRQUFILENBQVl0QixFQUFFLENBQUN1QixNQUFILENBQVVMLElBQVYsRUFBZSxDQUFmLEVBQWlCRCxLQUFqQixDQUFaLEVBQW9DakIsRUFBRSxDQUFDdUIsTUFBSCxDQUFVTCxJQUFWLEVBQWUsQ0FBZixFQUFpQixDQUFDRCxLQUFsQixDQUFwQyxFQUE4RE8sYUFBOUQsRUFBaEM7QUFDSDtBQUVKO0FBQ0osR0FoQ0k7QUFrQ0xDLEVBQUFBLFVBbENLLHNCQWtDTUMsS0FsQ04sRUFrQ1k7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0EsWUFBT0EsS0FBSyxDQUFDQyxNQUFOLENBQWFDLElBQXBCO0FBQ0ksV0FBSyxNQUFMO0FBQ0ksYUFBS2YsSUFBTCxDQUFVQyxjQUFWLENBQXlCLDRCQUF6QixFQUF1REMsTUFBdkQsR0FBZ0UsSUFBaEU7QUFDQTs7QUFDSixXQUFLLFNBQUw7QUFDSWYsUUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlrQixTQUFaLENBQXNCLFNBQXRCO0FBQ0E7O0FBQ0osV0FBSyxNQUFMO0FBQ0ksYUFBS2hCLElBQUwsQ0FBVUMsY0FBVixDQUF5QixlQUF6QixFQUEwQ0MsTUFBMUMsR0FBbUQsSUFBbkQ7QUFDQTs7QUFDSixXQUFLLE1BQUw7QUFDSSxhQUFLRixJQUFMLENBQVVDLGNBQVYsQ0FBeUIsZ0JBQXpCLEVBQTJDQyxNQUEzQyxHQUFvRCxJQUFwRDtBQUNBOztBQUNKLFdBQUssTUFBTDtBQUNJLGFBQUtGLElBQUwsQ0FBVUMsY0FBVixDQUF5QixnQkFBekIsRUFBMkNDLE1BQTNDLEdBQW9ELElBQXBEO0FBQ0E7O0FBQ0osV0FBSyxJQUFMO0FBQ0lmLFFBQUFBLEVBQUUsQ0FBQ1csUUFBSCxDQUFZa0IsU0FBWixDQUFzQixJQUF0QjtBQUNBOztBQUNKLFdBQUssSUFBTDtBQUNJN0IsUUFBQUEsRUFBRSxDQUFDOEIsSUFBSCxDQUFRQyxHQUFSO0FBQ0E7QUFyQlI7QUF1QkgsR0FqRUk7QUFtRUxDLEVBQUFBLHlCQUF5QixFQUFFLHFDQUFXO0FBQ2xDaEMsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlrQixTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0FyRUk7QUF1RUxJLEVBQUFBLGFBdkVLLDJCQXVFVTtBQUNYakMsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlrQixTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0F6RUk7QUEyRUxLLEVBQUFBLFlBM0VLLDBCQTJFUztBQUNWbEMsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlrQixTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0E3RUk7QUErRUxNLEVBQUFBLGFBL0VLLDJCQStFVTtBQUNYbkMsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlrQixTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0FqRkksQ0FrRkw7QUFDQTtBQUNBOztBQXBGSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgcmVzaXphYmxlTm9kZTpbY2MuTm9kZV0sXHJcbiAgICAgICAgZ2VyZW5mYW5naHU6Y2MuTm9kZSxcclxuICAgICAgICB5aU1pYW9ZYW5aaGk6Y2MuTm9kZSxcclxuICAgICAgICBzaGVRdkZhbmdZaTpjYy5Ob2RlLFxyXG4gICAgICAgIHlhb1lhblBhbmVsOmNjLk5vZGVcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgIGNjLmRpcmVjdG9yLnByZWxvYWRTY2VuZShcIuS4quS6uumYsuaKpFwiKTtcclxuICAgICAgICAgY2MuZGlyZWN0b3IucHJlbG9hZFNjZW5lKFwi55ar6IuX56CU5Yi2XCIpO1xyXG4gICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUoXCLnpL7ljLrpmLLnlqtcIik7XHJcbiAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgncGVyc29uYWxQcm90ZWN0aW9uUGFnZXZpZXcnKS5hY3RpdmUgPSBmYWxzZTtcclxuICAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB2YXIgc3BlZWQ9MjA7XHJcbiAgICAgICAgdmFyIHRpbWU9MjtcclxuICAgICAgICBmb3IodmFyIGk9MDtpPHRoaXMucmVzaXphYmxlTm9kZS5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgaWYoaSUyPT0wKXtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVzaXphYmxlTm9kZVtpXS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoY2MubW92ZUJ5KHRpbWUsMCwtc3BlZWQpLGNjLm1vdmVCeSh0aW1lLDAsc3BlZWQpKS5yZXBlYXRGb3JldmVyKCkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlc2l6YWJsZU5vZGVbaV0ucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLm1vdmVCeSh0aW1lLDAsc3BlZWQpLGNjLm1vdmVCeSh0aW1lLDAsLXNwZWVkKSkucmVwZWF0Rm9yZXZlcigpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGJ1dHRvbkN0cmwoZXZlbnQpe1xyXG4gICAgICAgIC8vIGlmKGV2ZW50LnRhcmdldC5uYW1lID09PSAn5Liq5Lq66Ziy5oqkJykge1xyXG4gICAgICAgIC8vICAgICB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ3BlcnNvbmFsUHJvdGVjdGlvblBhZ2V2aWV3JykuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvLyB9IGVsc2UgaWYoZXZlbnQudGFyZ2V0Lm5hbWUgPT09ICfkurrkvZPlhY3nlqso5oC7KScpIHtcclxuICAgICAgICAvLyAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfkurrkvZPlhY3nlqso5oC7KScpO1xyXG4gICAgICAgIC8vIH1lbHNlIGlmKClcclxuXHJcblxyXG4gICAgICAgIHN3aXRjaChldmVudC50YXJnZXQubmFtZSl7XHJcbiAgICAgICAgICAgIGNhc2UgXCLkuKrkurrpmLLmiqRcIjpcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgncGVyc29uYWxQcm90ZWN0aW9uUGFnZXZpZXcnKS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCLkurrkvZPlhY3nlqso5oC7KVwiOlxyXG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfkurrkvZPlhY3nlqso5oC7KScpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCLnpL7ljLrpmLLnlqtcIjpcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZSgnc2hlcXZQYWdldmlldycpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIueWq+iLl+eglOWItlwiOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCd5aW1pYW9QYWdldmlldycpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIuiwo+iogOegtOmZpFwiOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKCd5YW95YW5QYWdldmlldycpLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcIuWutuWbrVwiOlxyXG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCflrrblm60nKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwi6YCA5Ye6XCI6XHJcbiAgICAgICAgICAgICAgICBjYy5nYW1lLmVuZCgpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkNsaWNrUGVyc29uYWxQcm90ZWN0aW9uOiBmdW5jdGlvbigpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ+S4quS6uumYsuaKpCcpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkNsaWNrWWlNaWFvKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfnlqvoi5fnoJTliLYnKTtcclxuICAgIH0sXHJcblxyXG4gICAgb25DbGlja1NoZVF2KCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCfnpL7ljLrpmLLnlqsnKTtcclxuICAgIH0sXHJcblxyXG4gICAgb25DbGlja1lhb1lhbigpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgn6LCj6KiA56C06ZmkJyk7XHJcbiAgICB9LFxyXG4gICAgLy8gZXhpdEZ1bigpe1xyXG4gICAgLy8gICAgIGNjLmdhbWUuZW5kKCk7XHJcbiAgICAvLyB9XHJcbn0pO1xyXG4iXX0=