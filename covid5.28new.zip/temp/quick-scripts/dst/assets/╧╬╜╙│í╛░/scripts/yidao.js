
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/衔接场景/scripts/yidao.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '64d9dxW3uNGXLXgQ78vpQKu', 'yidao');
// 衔接场景/script/yidao.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    yindao: cc.Node,
    bar: cc.Button,
    picPlace: cc.Sprite,
    message: cc.Label,
    sheqv: cc.SpriteFrame
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  showPanel: function showPanel(frame, message) {
    this.yindao.active = true;
    this.picPlace.spriteFrame = frame;
    this.message.string = message;
  },
  sheqvOnClick: function sheqvOnClick() {
    this.showPanel(this.sheqv, "快来社区帮我们控制疫情吧！(点此继续)");
    this.bar.node.on("click", function () {
      cc.director.loadScene("社区防疫");
    }, this);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc6KGU5o6l5Zy65pmvXFxzY3JpcHRcXHlpZGFvLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwieWluZGFvIiwiTm9kZSIsImJhciIsIkJ1dHRvbiIsInBpY1BsYWNlIiwiU3ByaXRlIiwibWVzc2FnZSIsIkxhYmVsIiwic2hlcXYiLCJTcHJpdGVGcmFtZSIsInN0YXJ0Iiwic2hvd1BhbmVsIiwiZnJhbWUiLCJhY3RpdmUiLCJzcHJpdGVGcmFtZSIsInN0cmluZyIsInNoZXF2T25DbGljayIsIm5vZGUiLCJvbiIsImRpcmVjdG9yIiwibG9hZFNjZW5lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFDSixFQUFFLENBQUNLLElBREY7QUFFUkMsSUFBQUEsR0FBRyxFQUFDTixFQUFFLENBQUNPLE1BRkM7QUFHUkMsSUFBQUEsUUFBUSxFQUFDUixFQUFFLENBQUNTLE1BSEo7QUFJUkMsSUFBQUEsT0FBTyxFQUFDVixFQUFFLENBQUNXLEtBSkg7QUFLUkMsSUFBQUEsS0FBSyxFQUFDWixFQUFFLENBQUNhO0FBTEQsR0FIUDtBQVdMO0FBRUE7QUFFQUMsRUFBQUEsS0FmSyxtQkFlSSxDQUVSLENBakJJO0FBa0JMQyxFQUFBQSxTQWxCSyxxQkFrQktDLEtBbEJMLEVBa0JXTixPQWxCWCxFQWtCbUI7QUFDcEIsU0FBS04sTUFBTCxDQUFZYSxNQUFaLEdBQW1CLElBQW5CO0FBQ0EsU0FBS1QsUUFBTCxDQUFjVSxXQUFkLEdBQTBCRixLQUExQjtBQUNBLFNBQUtOLE9BQUwsQ0FBYVMsTUFBYixHQUFvQlQsT0FBcEI7QUFDSCxHQXRCSTtBQXVCTFUsRUFBQUEsWUF2QkssMEJBdUJTO0FBQ1YsU0FBS0wsU0FBTCxDQUFlLEtBQUtILEtBQXBCLEVBQTBCLHFCQUExQjtBQUNBLFNBQUtOLEdBQUwsQ0FBU2UsSUFBVCxDQUFjQyxFQUFkLENBQWlCLE9BQWpCLEVBQXlCLFlBQVU7QUFBQ3RCLE1BQUFBLEVBQUUsQ0FBQ3VCLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUE4QixLQUFsRSxFQUFtRSxJQUFuRTtBQUNILEdBMUJJLENBMkJMOztBQTNCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgeWluZGFvOmNjLk5vZGUsXHJcbiAgICAgICAgYmFyOmNjLkJ1dHRvbixcclxuICAgICAgICBwaWNQbGFjZTpjYy5TcHJpdGUsXHJcbiAgICAgICAgbWVzc2FnZTpjYy5MYWJlbCxcclxuICAgICAgICBzaGVxdjpjYy5TcHJpdGVGcmFtZVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcbiAgICBzaG93UGFuZWwoZnJhbWUsbWVzc2FnZSl7XHJcbiAgICAgICAgdGhpcy55aW5kYW8uYWN0aXZlPXRydWU7XHJcbiAgICAgICAgdGhpcy5waWNQbGFjZS5zcHJpdGVGcmFtZT1mcmFtZTtcclxuICAgICAgICB0aGlzLm1lc3NhZ2Uuc3RyaW5nPW1lc3NhZ2U7XHJcbiAgICB9LFxyXG4gICAgc2hlcXZPbkNsaWNrKCl7XHJcbiAgICAgICAgdGhpcy5zaG93UGFuZWwodGhpcy5zaGVxdixcIuW/q+adpeekvuWMuuW4ruaIkeS7rOaOp+WItueWq+aDheWQp++8gSjngrnmraTnu6fnu60pXCIpO1xyXG4gICAgICAgIHRoaXMuYmFyLm5vZGUub24oXCJjbGlja1wiLGZ1bmN0aW9uKCl7Y2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi56S+5Yy66Ziy55arXCIpfSx0aGlzKTtcclxuICAgIH1cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19