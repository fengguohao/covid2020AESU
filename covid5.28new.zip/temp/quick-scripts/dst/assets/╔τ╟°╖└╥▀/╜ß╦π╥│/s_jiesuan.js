
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/社区防疫/结算页/s_jiesuan.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'dc51cuGzh9G0KEV5mksvkJm', 's_jiesuan');
// 社区防疫/结算页/s_jiesuan.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    winPic: cc.SpriteFrame,
    losePic: cc.SpriteFrame,
    panel: cc.Node,
    prompt: cc.Label,
    picBox: cc.Sprite,
    stage: null,
    overTip: null,
    successMusic: {
      "default": null,
      type: cc.AudioClip
    },
    failClip: {
      "default": null,
      type: cc.AudioClip
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this.prompt.string = "疫情在您的有力治理下得到控制。\n恭喜您，游戏通关";
    this.stage = cc.sys.localStorage.getItem("s_gameStage");
    this.overTip = cc.sys.localStorage.getItem("s_gameOver");
    cc.log(this.stage);
    this.panel.runAction(cc.moveTo(2, 0, 0).easing(cc.easeBackIn()));

    if (this.stage == "lose") {
      this.picBox.spriteFrame = this.losePic;
      this.current = cc.audioEngine.play(this.failClip, false, 1);

      if (this.overTip == "itemNotEnough") {
        this.prompt.string = "由于物资储备严重不足，人们开始抗议，疫情无法控制。\n很抱歉，游戏失败";
      } else if (this.overTip == "numExceed") {
        this.prompt.string = "患病人数过多，严重超过医院承载能力，疫情无法控制。\n很抱歉，游戏失败";
      }
    } else if (this.stage == "win") {
      this.current = cc.audioEngine.play(this.successMusic, false, 1);
      this.picBox.spriteFrame = this.winPic;
      this.prompt.string = "疫情在您的有力治理下得到控制。\n恭喜您，游戏通关";
    }
  },
  againOnClick: function againOnClick() {
    cc.director.loadScene("社区防疫");
  },
  exitOnClick: function exitOnClick() {
    cc.director.loadScene("衔接场景");
  },
  onDestroy: function onDestroy() {
    cc.audioEngine.stop(this.current);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc56S+5Yy66Ziy55arXFznu5PnrpfpobVcXHNfamllc3Vhbi5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIndpblBpYyIsIlNwcml0ZUZyYW1lIiwibG9zZVBpYyIsInBhbmVsIiwiTm9kZSIsInByb21wdCIsIkxhYmVsIiwicGljQm94IiwiU3ByaXRlIiwic3RhZ2UiLCJvdmVyVGlwIiwic3VjY2Vzc011c2ljIiwidHlwZSIsIkF1ZGlvQ2xpcCIsImZhaWxDbGlwIiwic3RhcnQiLCJzdHJpbmciLCJzeXMiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibG9nIiwicnVuQWN0aW9uIiwibW92ZVRvIiwiZWFzaW5nIiwiZWFzZUJhY2tJbiIsInNwcml0ZUZyYW1lIiwiY3VycmVudCIsImF1ZGlvRW5naW5lIiwicGxheSIsImFnYWluT25DbGljayIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwiZXhpdE9uQ2xpY2siLCJvbkRlc3Ryb3kiLCJzdG9wIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFDSixFQUFFLENBQUNLLFdBREY7QUFFUkMsSUFBQUEsT0FBTyxFQUFDTixFQUFFLENBQUNLLFdBRkg7QUFHUkUsSUFBQUEsS0FBSyxFQUFDUCxFQUFFLENBQUNRLElBSEQ7QUFJUkMsSUFBQUEsTUFBTSxFQUFDVCxFQUFFLENBQUNVLEtBSkY7QUFLUkMsSUFBQUEsTUFBTSxFQUFDWCxFQUFFLENBQUNZLE1BTEY7QUFNUkMsSUFBQUEsS0FBSyxFQUFDLElBTkU7QUFPUkMsSUFBQUEsT0FBTyxFQUFDLElBUEE7QUFRUkMsSUFBQUEsWUFBWSxFQUFDO0FBQ1QsaUJBQVEsSUFEQztBQUVUQyxNQUFBQSxJQUFJLEVBQUNoQixFQUFFLENBQUNpQjtBQUZDLEtBUkw7QUFZUkMsSUFBQUEsUUFBUSxFQUFDO0FBQ0wsaUJBQVEsSUFESDtBQUVMRixNQUFBQSxJQUFJLEVBQUNoQixFQUFFLENBQUNpQjtBQUZIO0FBWkQsR0FIUDtBQXFCTDtBQUVBO0FBRUFFLEVBQUFBLEtBekJLLG1CQXlCSTtBQUVMLFNBQUtWLE1BQUwsQ0FBWVcsTUFBWixHQUFtQiwyQkFBbkI7QUFDQSxTQUFLUCxLQUFMLEdBQVdiLEVBQUUsQ0FBQ3FCLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsYUFBNUIsQ0FBWDtBQUNBLFNBQUtULE9BQUwsR0FBYWQsRUFBRSxDQUFDcUIsR0FBSCxDQUFPQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QixZQUE1QixDQUFiO0FBQ0F2QixJQUFBQSxFQUFFLENBQUN3QixHQUFILENBQU8sS0FBS1gsS0FBWjtBQUNBLFNBQUtOLEtBQUwsQ0FBV2tCLFNBQVgsQ0FBcUJ6QixFQUFFLENBQUMwQixNQUFILENBQVUsQ0FBVixFQUFZLENBQVosRUFBYyxDQUFkLEVBQWlCQyxNQUFqQixDQUF3QjNCLEVBQUUsQ0FBQzRCLFVBQUgsRUFBeEIsQ0FBckI7O0FBQ0EsUUFBRyxLQUFLZixLQUFMLElBQVksTUFBZixFQUFzQjtBQUNsQixXQUFLRixNQUFMLENBQVlrQixXQUFaLEdBQXdCLEtBQUt2QixPQUE3QjtBQUNBLFdBQUt3QixPQUFMLEdBQWE5QixFQUFFLENBQUMrQixXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS2QsUUFBekIsRUFBbUMsS0FBbkMsRUFBMEMsQ0FBMUMsQ0FBYjs7QUFDQSxVQUFHLEtBQUtKLE9BQUwsSUFBYyxlQUFqQixFQUFpQztBQUM3QixhQUFLTCxNQUFMLENBQVlXLE1BQVosR0FBbUIscUNBQW5CO0FBQ0gsT0FGRCxNQUdLLElBQUcsS0FBS04sT0FBTCxJQUFjLFdBQWpCLEVBQTZCO0FBQzlCLGFBQUtMLE1BQUwsQ0FBWVcsTUFBWixHQUFtQixxQ0FBbkI7QUFDSDtBQUVKLEtBVkQsTUFXSyxJQUFHLEtBQUtQLEtBQUwsSUFBWSxLQUFmLEVBQXFCO0FBQ3RCLFdBQUtpQixPQUFMLEdBQWE5QixFQUFFLENBQUMrQixXQUFILENBQWVDLElBQWYsQ0FBb0IsS0FBS2pCLFlBQXpCLEVBQXVDLEtBQXZDLEVBQThDLENBQTlDLENBQWI7QUFDQSxXQUFLSixNQUFMLENBQVlrQixXQUFaLEdBQXdCLEtBQUt6QixNQUE3QjtBQUNBLFdBQUtLLE1BQUwsQ0FBWVcsTUFBWixHQUFtQiwyQkFBbkI7QUFDSDtBQUNKLEdBaERJO0FBa0RMYSxFQUFBQSxZQWxESywwQkFrRFM7QUFDVmpDLElBQUFBLEVBQUUsQ0FBQ2tDLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBcERJO0FBc0RMQyxFQUFBQSxXQXRESyx5QkFzRFE7QUFDVHBDLElBQUFBLEVBQUUsQ0FBQ2tDLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBeERJO0FBMERMRSxFQUFBQSxTQUFTLEVBQUUscUJBQVk7QUFDbkJyQyxJQUFBQSxFQUFFLENBQUMrQixXQUFILENBQWVPLElBQWYsQ0FBb0IsS0FBS1IsT0FBekI7QUFDSDtBQTVESSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgd2luUGljOmNjLlNwcml0ZUZyYW1lLFxyXG4gICAgICAgIGxvc2VQaWM6Y2MuU3ByaXRlRnJhbWUsXHJcbiAgICAgICAgcGFuZWw6Y2MuTm9kZSxcclxuICAgICAgICBwcm9tcHQ6Y2MuTGFiZWwsXHJcbiAgICAgICAgcGljQm94OmNjLlNwcml0ZSxcclxuICAgICAgICBzdGFnZTpudWxsLFxyXG4gICAgICAgIG92ZXJUaXA6bnVsbCxcclxuICAgICAgICBzdWNjZXNzTXVzaWM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuQXVkaW9DbGlwXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmYWlsQ2xpcDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5BdWRpb0NsaXBcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgICAgICB0aGlzLnByb21wdC5zdHJpbmc9XCLnlqvmg4XlnKjmgqjnmoTmnInlipvmsrvnkIbkuIvlvpfliLDmjqfliLbjgIJcXG7mga3llpzmgqjvvIzmuLjmiI/pgJrlhbNcIjtcclxuICAgICAgICB0aGlzLnN0YWdlPWNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInNfZ2FtZVN0YWdlXCIpO1xyXG4gICAgICAgIHRoaXMub3ZlclRpcD1jYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJzX2dhbWVPdmVyXCIpO1xyXG4gICAgICAgIGNjLmxvZyh0aGlzLnN0YWdlKTtcclxuICAgICAgICB0aGlzLnBhbmVsLnJ1bkFjdGlvbihjYy5tb3ZlVG8oMiwwLDApLmVhc2luZyhjYy5lYXNlQmFja0luKCkpKTtcclxuICAgICAgICBpZih0aGlzLnN0YWdlPT1cImxvc2VcIil7XHJcbiAgICAgICAgICAgIHRoaXMucGljQm94LnNwcml0ZUZyYW1lPXRoaXMubG9zZVBpYztcclxuICAgICAgICAgICAgdGhpcy5jdXJyZW50PWNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5mYWlsQ2xpcCwgZmFsc2UsIDEpO1xyXG4gICAgICAgICAgICBpZih0aGlzLm92ZXJUaXA9PVwiaXRlbU5vdEVub3VnaFwiKXtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvbXB0LnN0cmluZz1cIueUseS6jueJqei1hOWCqOWkh+S4pemHjeS4jei2s++8jOS6uuS7rOW8gOWni+aKl+iuru+8jOeWq+aDheaXoOazleaOp+WItuOAglxcbuW+iOaKseatie+8jOa4uOaIj+Wksei0pVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYodGhpcy5vdmVyVGlwPT1cIm51bUV4Y2VlZFwiKXtcclxuICAgICAgICAgICAgICAgIHRoaXMucHJvbXB0LnN0cmluZz1cIuaCo+eXheS6uuaVsOi/h+Wkmu+8jOS4pemHjei2hei/h+WMu+mZouaJv+i9veiDveWKm++8jOeWq+aDheaXoOazleaOp+WItuOAglxcbuW+iOaKseatie+8jOa4uOaIj+Wksei0pVwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmKHRoaXMuc3RhZ2U9PVwid2luXCIpe1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnQ9Y2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLnN1Y2Nlc3NNdXNpYywgZmFsc2UsIDEpO1xyXG4gICAgICAgICAgICB0aGlzLnBpY0JveC5zcHJpdGVGcmFtZT10aGlzLndpblBpYztcclxuICAgICAgICAgICAgdGhpcy5wcm9tcHQuc3RyaW5nPVwi55ar5oOF5Zyo5oKo55qE5pyJ5Yqb5rK755CG5LiL5b6X5Yiw5o6n5Yi244CCXFxu5oGt5Zac5oKo77yM5ri45oiP6YCa5YWzXCI7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBhZ2Fpbk9uQ2xpY2soKXtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCLnpL7ljLrpmLLnlqtcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIGV4aXRPbkNsaWNrKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi6KGU5o6l5Zy65pmvXCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkRlc3Ryb3k6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjYy5hdWRpb0VuZ2luZS5zdG9wKHRoaXMuY3VycmVudCk7XHJcbiAgICB9XHJcbn0pO1xyXG4iXX0=