
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/社区防疫/scripts/s_hospital.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7fa88I52/VIi4g5+YdaV3T7', 's_hospital');
// 社区防疫/scripts/s_hospital.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    hospital: cc.Node,
    s_map: cc.Node,
    improvingCheck: 0,
    checkCount: 0,
    capacityCount: 0,
    improvingCapacity: 0,
    improveingAbility: 0,
    s_globalParameter: cc.Node,
    zhuangtai: cc.Label,
    infoPrompt: cc.Label
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  showHospital: function showHospital() {
    this.hospital.active = true;
    console.log("hospital on show");
  },
  start: function start() {
    this.improvingCapacity = 0;
    this.improvingCheck = 0;
    this.capacityCount = 0;
    this.checkCount = 0;
    this.s_map = this.s_map.getComponent("s_map");
    this.s_globalParameter = this.s_globalParameter.getComponent("s_globalParameter");
  },
  closeHospital: function closeHospital() {
    this.s_map.closeAll();
    this.hospital.active = false;
  },
  showInfo: function showInfo(str) {
    this.infoPrompt.node.active = true;
    this.infoPrompt.node.parent.active = true;
    this.infoPrompt.string = str;
    this.scheduleOnce(function () {
      this.infoPrompt.node.active = false;
      this.infoPrompt.node.parent.active = false;
    }, 2);
  },
  improveCapacity: function improveCapacity() {
    if (this.improvingCapacity == 0 && this.s_globalParameter.money >= 30) {
      this.improvingCapacity = 1;
      this.s_globalParameter.money -= 30;
      this.showInfo("医院正在扩建");
      this.scheduleOnce(function () {
        this.checkCount += 1;
        this.improvingCapacity = 0;
        this.s_globalParameter.hospitalNum += this.s_globalParameter.injuredNum * 0.1 > 100 ? parseInt(this.s_globalParameter.injuredNum * 0.1) : 100;
        this.showInfo("扩建成功，容量" + this.s_globalParameter.hospitalNum);
      }.bind(this), 10);
    } else {
      if (this.s_globalParameter.money < 30) {
        this.showInfo("金钱不足，请稍后再试");
      } else {
        this.showInfo("医院正在扩建中，请稍后再试");
      }
    }
  },
  improveCheck: function improveCheck() {
    if (this.improvingCheck == 0 && this.s_globalParameter.money >= 20) {
      this.s_globalParameter.money -= 20;
      this.improvingCheck = 1;
      this.showInfo("正在努力提高检测能力");
      this.scheduleOnce(function () {
        this.s_globalParameter.spreadIndex -= 0.03;
        this.improvingCheck = 0;
      }.bind(this), 10);
    } else {
      if (this.s_globalParameter.money < 20) {
        this.showInfo("金钱不足，请稍后再试");
      } else {
        this.showInfo("操作失败，请稍后再试");
      }
    }
  },
  improveAbility: function improveAbility() {
    if (this.improveingAbility == 0 && this.s_globalParameter.money >= 10) {
      this.s_globalParameter.money -= 10;
      this.improveingAbility = 1;
      this.showInfo("正在购买设备");
      this.scheduleOnce(function () {
        if (this.s_globalParameter.mCapability + 0.1 <= 1) {
          this.s_globalParameter.mCapability += 0.1;
        } else {
          this.s_globalParameter.mCapability = 1;
        }

        this.improveingAbility = 0;
      }.bind(this), 10);
    } else {
      if (this.s_globalParameter.money < 10) {
        this.showInfo("金钱不足，请稍后再试");
      } else {
        this.showInfo("操作失败，请稍后再试");
      }
    }
  },
  update: function update(dt) {
    this.zhuangtai.string = "当前医院总容量：" + this.s_globalParameter.hospitalNum + "\n实际在院患者：" + this.s_globalParameter.separatedNum + "\n载荷率" + parseInt(this.s_globalParameter.separatedNum * 100 / this.s_globalParameter.hospitalNum) + "%";
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc56S+5Yy66Ziy55arXFxzY3JpcHRzXFxzX2hvc3BpdGFsLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiaG9zcGl0YWwiLCJOb2RlIiwic19tYXAiLCJpbXByb3ZpbmdDaGVjayIsImNoZWNrQ291bnQiLCJjYXBhY2l0eUNvdW50IiwiaW1wcm92aW5nQ2FwYWNpdHkiLCJpbXByb3ZlaW5nQWJpbGl0eSIsInNfZ2xvYmFsUGFyYW1ldGVyIiwiemh1YW5ndGFpIiwiTGFiZWwiLCJpbmZvUHJvbXB0Iiwic2hvd0hvc3BpdGFsIiwiYWN0aXZlIiwiY29uc29sZSIsImxvZyIsInN0YXJ0IiwiZ2V0Q29tcG9uZW50IiwiY2xvc2VIb3NwaXRhbCIsImNsb3NlQWxsIiwic2hvd0luZm8iLCJzdHIiLCJub2RlIiwicGFyZW50Iiwic3RyaW5nIiwic2NoZWR1bGVPbmNlIiwiaW1wcm92ZUNhcGFjaXR5IiwibW9uZXkiLCJob3NwaXRhbE51bSIsImluanVyZWROdW0iLCJwYXJzZUludCIsImJpbmQiLCJpbXByb3ZlQ2hlY2siLCJzcHJlYWRJbmRleCIsImltcHJvdmVBYmlsaXR5IiwibUNhcGFiaWxpdHkiLCJ1cGRhdGUiLCJkdCIsInNlcGFyYXRlZE51bSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFFBQVEsRUFBQ0osRUFBRSxDQUFDSyxJQURKO0FBRVJDLElBQUFBLEtBQUssRUFBQ04sRUFBRSxDQUFDSyxJQUZEO0FBR1JFLElBQUFBLGNBQWMsRUFBQyxDQUhQO0FBSVJDLElBQUFBLFVBQVUsRUFBQyxDQUpIO0FBS1JDLElBQUFBLGFBQWEsRUFBQyxDQUxOO0FBTVJDLElBQUFBLGlCQUFpQixFQUFDLENBTlY7QUFPUkMsSUFBQUEsaUJBQWlCLEVBQUMsQ0FQVjtBQVFSQyxJQUFBQSxpQkFBaUIsRUFBQ1osRUFBRSxDQUFDSyxJQVJiO0FBU1JRLElBQUFBLFNBQVMsRUFBQ2IsRUFBRSxDQUFDYyxLQVRMO0FBVVJDLElBQUFBLFVBQVUsRUFBQ2YsRUFBRSxDQUFDYztBQVZOLEdBSFA7QUFpQkw7QUFFQTtBQUlBRSxFQUFBQSxZQXZCSywwQkF1QlM7QUFDVixTQUFLWixRQUFMLENBQWNhLE1BQWQsR0FBcUIsSUFBckI7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVo7QUFFSCxHQTNCSTtBQTZCTEMsRUFBQUEsS0E3QkssbUJBNkJJO0FBQ0wsU0FBS1YsaUJBQUwsR0FBdUIsQ0FBdkI7QUFDQSxTQUFLSCxjQUFMLEdBQW9CLENBQXBCO0FBQ0EsU0FBS0UsYUFBTCxHQUFtQixDQUFuQjtBQUNBLFNBQUtELFVBQUwsR0FBZ0IsQ0FBaEI7QUFDQSxTQUFLRixLQUFMLEdBQVcsS0FBS0EsS0FBTCxDQUFXZSxZQUFYLENBQXdCLE9BQXhCLENBQVg7QUFDQSxTQUFLVCxpQkFBTCxHQUF1QixLQUFLQSxpQkFBTCxDQUF1QlMsWUFBdkIsQ0FBb0MsbUJBQXBDLENBQXZCO0FBQ0gsR0FwQ0k7QUF1Q0xDLEVBQUFBLGFBdkNLLDJCQXVDVTtBQUNYLFNBQUtoQixLQUFMLENBQVdpQixRQUFYO0FBQ0EsU0FBS25CLFFBQUwsQ0FBY2EsTUFBZCxHQUFxQixLQUFyQjtBQUVILEdBM0NJO0FBNENMTyxFQUFBQSxRQTVDSyxvQkE0Q0lDLEdBNUNKLEVBNENRO0FBQ1QsU0FBS1YsVUFBTCxDQUFnQlcsSUFBaEIsQ0FBcUJULE1BQXJCLEdBQTRCLElBQTVCO0FBQ0EsU0FBS0YsVUFBTCxDQUFnQlcsSUFBaEIsQ0FBcUJDLE1BQXJCLENBQTRCVixNQUE1QixHQUFtQyxJQUFuQztBQUNBLFNBQUtGLFVBQUwsQ0FBZ0JhLE1BQWhCLEdBQXVCSCxHQUF2QjtBQUVBLFNBQUtJLFlBQUwsQ0FBa0IsWUFBVTtBQUN4QixXQUFLZCxVQUFMLENBQWdCVyxJQUFoQixDQUFxQlQsTUFBckIsR0FBNEIsS0FBNUI7QUFDQSxXQUFLRixVQUFMLENBQWdCVyxJQUFoQixDQUFxQkMsTUFBckIsQ0FBNEJWLE1BQTVCLEdBQW1DLEtBQW5DO0FBQ0gsS0FIRCxFQUdFLENBSEY7QUFJSCxHQXJESTtBQXdETGEsRUFBQUEsZUF4REssNkJBd0RZO0FBQ2IsUUFBRyxLQUFLcEIsaUJBQUwsSUFBd0IsQ0FBeEIsSUFBMkIsS0FBS0UsaUJBQUwsQ0FBdUJtQixLQUF2QixJQUE4QixFQUE1RCxFQUErRDtBQUMzRCxXQUFLckIsaUJBQUwsR0FBdUIsQ0FBdkI7QUFDQSxXQUFLRSxpQkFBTCxDQUF1Qm1CLEtBQXZCLElBQThCLEVBQTlCO0FBQ0EsV0FBS1AsUUFBTCxDQUFjLFFBQWQ7QUFDQSxXQUFLSyxZQUFMLENBQWtCLFlBQVU7QUFDeEIsYUFBS3JCLFVBQUwsSUFBaUIsQ0FBakI7QUFDQSxhQUFLRSxpQkFBTCxHQUF1QixDQUF2QjtBQUNBLGFBQUtFLGlCQUFMLENBQXVCb0IsV0FBdkIsSUFBb0MsS0FBS3BCLGlCQUFMLENBQXVCcUIsVUFBdkIsR0FBa0MsR0FBbEMsR0FBc0MsR0FBdEMsR0FBMENDLFFBQVEsQ0FBQyxLQUFLdEIsaUJBQUwsQ0FBdUJxQixVQUF2QixHQUFrQyxHQUFuQyxDQUFsRCxHQUEwRixHQUE5SDtBQUNBLGFBQUtULFFBQUwsQ0FBYyxZQUFVLEtBQUtaLGlCQUFMLENBQXVCb0IsV0FBL0M7QUFDSCxPQUxpQixDQUtoQkcsSUFMZ0IsQ0FLWCxJQUxXLENBQWxCLEVBS2EsRUFMYjtBQU1ILEtBVkQsTUFXSTtBQUNBLFVBQUcsS0FBS3ZCLGlCQUFMLENBQXVCbUIsS0FBdkIsR0FBNkIsRUFBaEMsRUFBbUM7QUFDL0IsYUFBS1AsUUFBTCxDQUFjLFlBQWQ7QUFDSCxPQUZELE1BR0k7QUFDQSxhQUFLQSxRQUFMLENBQWMsZUFBZDtBQUNIO0FBQ0o7QUFDSixHQTVFSTtBQWdGTFksRUFBQUEsWUFoRkssMEJBZ0ZTO0FBQ1YsUUFBRyxLQUFLN0IsY0FBTCxJQUFxQixDQUFyQixJQUF3QixLQUFLSyxpQkFBTCxDQUF1Qm1CLEtBQXZCLElBQThCLEVBQXpELEVBQTREO0FBQ3hELFdBQUtuQixpQkFBTCxDQUF1Qm1CLEtBQXZCLElBQThCLEVBQTlCO0FBQ0EsV0FBS3hCLGNBQUwsR0FBb0IsQ0FBcEI7QUFDQSxXQUFLaUIsUUFBTCxDQUFjLFlBQWQ7QUFDQSxXQUFLSyxZQUFMLENBQWtCLFlBQVU7QUFDeEIsYUFBS2pCLGlCQUFMLENBQXVCeUIsV0FBdkIsSUFBb0MsSUFBcEM7QUFDQSxhQUFLOUIsY0FBTCxHQUFvQixDQUFwQjtBQUNILE9BSGlCLENBR2hCNEIsSUFIZ0IsQ0FHWCxJQUhXLENBQWxCLEVBR2EsRUFIYjtBQUlILEtBUkQsTUFTSTtBQUNBLFVBQUcsS0FBS3ZCLGlCQUFMLENBQXVCbUIsS0FBdkIsR0FBNkIsRUFBaEMsRUFBbUM7QUFDL0IsYUFBS1AsUUFBTCxDQUFjLFlBQWQ7QUFDSCxPQUZELE1BR0k7QUFDQSxhQUFLQSxRQUFMLENBQWMsWUFBZDtBQUNIO0FBQ0o7QUFDSixHQWxHSTtBQW9HTGMsRUFBQUEsY0FwR0ssNEJBb0dXO0FBQ1osUUFBRyxLQUFLM0IsaUJBQUwsSUFBd0IsQ0FBeEIsSUFBMkIsS0FBS0MsaUJBQUwsQ0FBdUJtQixLQUF2QixJQUE4QixFQUE1RCxFQUErRDtBQUMzRCxXQUFLbkIsaUJBQUwsQ0FBdUJtQixLQUF2QixJQUE4QixFQUE5QjtBQUNBLFdBQUtwQixpQkFBTCxHQUF1QixDQUF2QjtBQUNBLFdBQUthLFFBQUwsQ0FBYyxRQUFkO0FBQ0EsV0FBS0ssWUFBTCxDQUFrQixZQUFVO0FBQ3hCLFlBQUcsS0FBS2pCLGlCQUFMLENBQXVCMkIsV0FBdkIsR0FBbUMsR0FBbkMsSUFBd0MsQ0FBM0MsRUFDQTtBQUNJLGVBQUszQixpQkFBTCxDQUF1QjJCLFdBQXZCLElBQW9DLEdBQXBDO0FBQ0gsU0FIRCxNQUlJO0FBQ0EsZUFBSzNCLGlCQUFMLENBQXVCMkIsV0FBdkIsR0FBbUMsQ0FBbkM7QUFDSDs7QUFDRCxhQUFLNUIsaUJBQUwsR0FBdUIsQ0FBdkI7QUFDSCxPQVRpQixDQVNoQndCLElBVGdCLENBU1gsSUFUVyxDQUFsQixFQVNhLEVBVGI7QUFVSCxLQWRELE1BZUk7QUFDQSxVQUFHLEtBQUt2QixpQkFBTCxDQUF1Qm1CLEtBQXZCLEdBQTZCLEVBQWhDLEVBQW1DO0FBQy9CLGFBQUtQLFFBQUwsQ0FBYyxZQUFkO0FBQ0gsT0FGRCxNQUdJO0FBQ0EsYUFBS0EsUUFBTCxDQUFjLFlBQWQ7QUFDSDtBQUNKO0FBQ0osR0E1SEk7QUE2SEpnQixFQUFBQSxNQTdISSxrQkE2SElDLEVBN0hKLEVBNkhRO0FBQ1QsU0FBSzVCLFNBQUwsQ0FBZWUsTUFBZixHQUFzQixhQUFXLEtBQUtoQixpQkFBTCxDQUF1Qm9CLFdBQWxDLEdBQ3RCLFdBRHNCLEdBQ1YsS0FBS3BCLGlCQUFMLENBQXVCOEIsWUFEYixHQUV0QixPQUZzQixHQUVkUixRQUFRLENBQUMsS0FBS3RCLGlCQUFMLENBQXVCOEIsWUFBdkIsR0FBb0MsR0FBcEMsR0FBd0MsS0FBSzlCLGlCQUFMLENBQXVCb0IsV0FBaEUsQ0FGTSxHQUV1RSxHQUY3RjtBQUdGO0FBaklHLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBob3NwaXRhbDpjYy5Ob2RlLFxyXG4gICAgICAgIHNfbWFwOmNjLk5vZGUsXHJcbiAgICAgICAgaW1wcm92aW5nQ2hlY2s6MCxcclxuICAgICAgICBjaGVja0NvdW50OjAsXHJcbiAgICAgICAgY2FwYWNpdHlDb3VudDowLFxyXG4gICAgICAgIGltcHJvdmluZ0NhcGFjaXR5OjAsXHJcbiAgICAgICAgaW1wcm92ZWluZ0FiaWxpdHk6MCxcclxuICAgICAgICBzX2dsb2JhbFBhcmFtZXRlcjpjYy5Ob2RlLFxyXG4gICAgICAgIHpodWFuZ3RhaTpjYy5MYWJlbCxcclxuICAgICAgICBpbmZvUHJvbXB0OmNjLkxhYmVsLFxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHJcblxyXG4gICAgc2hvd0hvc3BpdGFsKCl7XHJcbiAgICAgICAgdGhpcy5ob3NwaXRhbC5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImhvc3BpdGFsIG9uIHNob3dcIik7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLmltcHJvdmluZ0NhcGFjaXR5PTA7XHJcbiAgICAgICAgdGhpcy5pbXByb3ZpbmdDaGVjaz0wO1xyXG4gICAgICAgIHRoaXMuY2FwYWNpdHlDb3VudD0wO1xyXG4gICAgICAgIHRoaXMuY2hlY2tDb3VudD0wO1xyXG4gICAgICAgIHRoaXMuc19tYXA9dGhpcy5zX21hcC5nZXRDb21wb25lbnQoXCJzX21hcFwiKTtcclxuICAgICAgICB0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyPXRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuZ2V0Q29tcG9uZW50KFwic19nbG9iYWxQYXJhbWV0ZXJcIik7XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBjbG9zZUhvc3BpdGFsKCl7XHJcbiAgICAgICAgdGhpcy5zX21hcC5jbG9zZUFsbCgpO1xyXG4gICAgICAgIHRoaXMuaG9zcGl0YWwuYWN0aXZlPWZhbHNlO1xyXG5cclxuICAgIH0sXHJcbiAgICBzaG93SW5mbyhzdHIpe1xyXG4gICAgICAgIHRoaXMuaW5mb1Byb21wdC5ub2RlLmFjdGl2ZT10cnVlO1xyXG4gICAgICAgIHRoaXMuaW5mb1Byb21wdC5ub2RlLnBhcmVudC5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICB0aGlzLmluZm9Qcm9tcHQuc3RyaW5nPXN0cjtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICB0aGlzLmluZm9Qcm9tcHQubm9kZS5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuaW5mb1Byb21wdC5ub2RlLnBhcmVudC5hY3RpdmU9ZmFsc2U7XHJcbiAgICAgICAgfSwyKTtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIGltcHJvdmVDYXBhY2l0eSgpe1xyXG4gICAgICAgIGlmKHRoaXMuaW1wcm92aW5nQ2FwYWNpdHk9PTAmJnRoaXMuc19nbG9iYWxQYXJhbWV0ZXIubW9uZXk+PTMwKXtcclxuICAgICAgICAgICAgdGhpcy5pbXByb3ZpbmdDYXBhY2l0eT0xO1xyXG4gICAgICAgICAgICB0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLm1vbmV5LT0zMDtcclxuICAgICAgICAgICAgdGhpcy5zaG93SW5mbyhcIuWMu+mZouato+WcqOaJqeW7ulwiKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tDb3VudCs9MTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaW1wcm92aW5nQ2FwYWNpdHk9MDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuaG9zcGl0YWxOdW0rPXRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuaW5qdXJlZE51bSowLjE+MTAwP3BhcnNlSW50KHRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuaW5qdXJlZE51bSowLjEpOjEwMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0luZm8oXCLmianlu7rmiJDlip/vvIzlrrnph49cIit0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLmhvc3BpdGFsTnVtKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpLDEwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgaWYodGhpcy5zX2dsb2JhbFBhcmFtZXRlci5tb25leTwzMCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dJbmZvKFwi6YeR6ZKx5LiN6Laz77yM6K+356iN5ZCO5YaN6K+VXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dJbmZvKFwi5Yy76Zmi5q2j5Zyo5omp5bu65Lit77yM6K+356iN5ZCO5YaN6K+VXCIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcblxyXG5cclxuICAgIGltcHJvdmVDaGVjaygpe1xyXG4gICAgICAgIGlmKHRoaXMuaW1wcm92aW5nQ2hlY2s9PTAmJnRoaXMuc19nbG9iYWxQYXJhbWV0ZXIubW9uZXk+PTIwKXtcclxuICAgICAgICAgICAgdGhpcy5zX2dsb2JhbFBhcmFtZXRlci5tb25leS09MjA7XHJcbiAgICAgICAgICAgIHRoaXMuaW1wcm92aW5nQ2hlY2s9MTtcclxuICAgICAgICAgICAgdGhpcy5zaG93SW5mbyhcIuato+WcqOWKquWKm+aPkOmrmOajgOa1i+iDveWKm1wiKTtcclxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuc3ByZWFkSW5kZXgtPTAuMDM7ICAgICAgXHJcbiAgICAgICAgICAgICAgICB0aGlzLmltcHJvdmluZ0NoZWNrPTA7ICAgICAgICAgIFxyXG4gICAgICAgICAgICB9LmJpbmQodGhpcyksMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBpZih0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLm1vbmV5PDIwKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0luZm8oXCLph5HpkrHkuI3otrPvvIzor7fnqI3lkI7lho3or5VcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0luZm8oXCLmk43kvZzlpLHotKXvvIzor7fnqI3lkI7lho3or5VcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGltcHJvdmVBYmlsaXR5KCl7XHJcbiAgICAgICAgaWYodGhpcy5pbXByb3ZlaW5nQWJpbGl0eT09MCYmdGhpcy5zX2dsb2JhbFBhcmFtZXRlci5tb25leT49MTApe1xyXG4gICAgICAgICAgICB0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLm1vbmV5LT0xMDtcclxuICAgICAgICAgICAgdGhpcy5pbXByb3ZlaW5nQWJpbGl0eT0xO1xyXG4gICAgICAgICAgICB0aGlzLnNob3dJbmZvKFwi5q2j5Zyo6LSt5Lmw6K6+5aSHXCIpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5zX2dsb2JhbFBhcmFtZXRlci5tQ2FwYWJpbGl0eSswLjE8PTEpXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zX2dsb2JhbFBhcmFtZXRlci5tQ2FwYWJpbGl0eSs9MC4xO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLm1DYXBhYmlsaXR5PTE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmltcHJvdmVpbmdBYmlsaXR5PTA7XHJcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSwxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuc19nbG9iYWxQYXJhbWV0ZXIubW9uZXk8MTApe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93SW5mbyhcIumHkemSseS4jei2s++8jOivt+eojeWQjuWGjeivlVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93SW5mbyhcIuaTjeS9nOWksei0pe+8jOivt+eojeWQjuWGjeivlVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIHRoaXMuemh1YW5ndGFpLnN0cmluZz1cIuW9k+WJjeWMu+mZouaAu+WuuemHj++8mlwiK3RoaXMuc19nbG9iYWxQYXJhbWV0ZXIuaG9zcGl0YWxOdW0rXHJcbiAgICAgICAgXCJcXG7lrp7pmYXlnKjpmaLmgqPogIXvvJpcIit0aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLnNlcGFyYXRlZE51bStcclxuICAgICAgICBcIlxcbui9veiNt+eOh1wiK3BhcnNlSW50KHRoaXMuc19nbG9iYWxQYXJhbWV0ZXIuc2VwYXJhdGVkTnVtKjEwMC90aGlzLnNfZ2xvYmFsUGFyYW1ldGVyLmhvc3BpdGFsTnVtKStcIiVcIjtcclxuICAgICB9LFxyXG59KTtcclxuIl19