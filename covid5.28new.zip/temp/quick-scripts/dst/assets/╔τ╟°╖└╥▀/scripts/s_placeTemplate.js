
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/社区防疫/scripts/s_placeTemplate.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ef2faU9LAJKbJM845GVVvin', 's_placeTemplate');
// 社区防疫/scripts/s_placeTemplate.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    sideButton: cc.Node,
    scene: cc.Node,
    layout: cc.Node,
    test: cc.Label,
    labelX: 100,
    labelY: 300
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {// this.labelX=0;
    // this.labelY=0;
    // var a=this.createNewTemplate(["1222222222","456","789"],[this.addTest,this.addTest,this.addTest],0);
    //var a=this.createNewTemplate(["1222222222","456"],[this.addTest,this.addTest],0);
  },
  createNewTemplate: function createNewTemplate(sideButtonList, funList, startAxis) {
    var buttonList = new Array();
    var sc = cc.instantiate(this.layout);
    sc.active = true;
    sc.getComponent(cc.Layout).startAxis = startAxis;

    if (startAxis == 0) {
      sc.setContentSize(150 * sideButtonList.length + 50, 40);
      sc.getComponent(cc.Layout).paddingLeft = 50;
      sc.getComponent(cc.Layout).paddingTop = 0;
    }

    if (startAxis == 1) {
      sc.setContentSize(100, 65 * sideButtonList.length + 30);
      sc.getComponent(cc.Layout).paddingTop = 0;
      sc.getComponent(cc.Layout).paddingLeft = 0;
    }

    cc.director.getScene().addChild(sc);
    buttonList.push(sc);
    var nodeTemp;

    for (var i = 0; i < sideButtonList.length; i++) {
      nodeTemp = cc.instantiate(this.sideButton);
      sc.addChild(nodeTemp, i + 1, sideButtonList[i]);
      nodeTemp.active = true;
      nodeTemp.getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string = sideButtonList[i];
      nodeTemp.on('click', funList[i].bind(this));
      buttonList.push(nodeTemp);
    }

    return buttonList;
  },
  addTest: function addTest() {
    this.test.string += 1;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc56S+5Yy66Ziy55arXFxzY3JpcHRzXFxzX3BsYWNlVGVtcGxhdGUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzaWRlQnV0dG9uIiwiTm9kZSIsInNjZW5lIiwibGF5b3V0IiwidGVzdCIsIkxhYmVsIiwibGFiZWxYIiwibGFiZWxZIiwic3RhcnQiLCJjcmVhdGVOZXdUZW1wbGF0ZSIsInNpZGVCdXR0b25MaXN0IiwiZnVuTGlzdCIsInN0YXJ0QXhpcyIsImJ1dHRvbkxpc3QiLCJBcnJheSIsInNjIiwiaW5zdGFudGlhdGUiLCJhY3RpdmUiLCJnZXRDb21wb25lbnQiLCJMYXlvdXQiLCJzZXRDb250ZW50U2l6ZSIsImxlbmd0aCIsInBhZGRpbmdMZWZ0IiwicGFkZGluZ1RvcCIsImRpcmVjdG9yIiwiZ2V0U2NlbmUiLCJhZGRDaGlsZCIsInB1c2giLCJub2RlVGVtcCIsImkiLCJnZXRDaGlsZEJ5TmFtZSIsInN0cmluZyIsIm9uIiwiYmluZCIsImFkZFRlc3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUNKLEVBQUUsQ0FBQ0ssSUFETjtBQUVSQyxJQUFBQSxLQUFLLEVBQUNOLEVBQUUsQ0FBQ0ssSUFGRDtBQUdSRSxJQUFBQSxNQUFNLEVBQUNQLEVBQUUsQ0FBQ0ssSUFIRjtBQUlSRyxJQUFBQSxJQUFJLEVBQUNSLEVBQUUsQ0FBQ1MsS0FKQTtBQUtSQyxJQUFBQSxNQUFNLEVBQUMsR0FMQztBQU1SQyxJQUFBQSxNQUFNLEVBQUM7QUFOQyxHQUhQO0FBY0w7QUFFQTtBQUVBQyxFQUFBQSxLQWxCSyxtQkFrQkksQ0FDTDtBQUNBO0FBQ0E7QUFDQTtBQUVILEdBeEJJO0FBNEJMQyxFQUFBQSxpQkE1QkssNkJBNEJhQyxjQTVCYixFQTRCNEJDLE9BNUI1QixFQTRCb0NDLFNBNUJwQyxFQTRCOEM7QUFDL0MsUUFBSUMsVUFBVSxHQUFDLElBQUlDLEtBQUosRUFBZjtBQUNBLFFBQUlDLEVBQUUsR0FBQ25CLEVBQUUsQ0FBQ29CLFdBQUgsQ0FBZSxLQUFLYixNQUFwQixDQUFQO0FBQ0FZLElBQUFBLEVBQUUsQ0FBQ0UsTUFBSCxHQUFVLElBQVY7QUFDQUYsSUFBQUEsRUFBRSxDQUFDRyxZQUFILENBQWdCdEIsRUFBRSxDQUFDdUIsTUFBbkIsRUFBMkJQLFNBQTNCLEdBQXFDQSxTQUFyQzs7QUFDQSxRQUFHQSxTQUFTLElBQUUsQ0FBZCxFQUFnQjtBQUNaRyxNQUFBQSxFQUFFLENBQUNLLGNBQUgsQ0FBa0IsTUFBSVYsY0FBYyxDQUFDVyxNQUFuQixHQUEwQixFQUE1QyxFQUErQyxFQUEvQztBQUNBTixNQUFBQSxFQUFFLENBQUNHLFlBQUgsQ0FBZ0J0QixFQUFFLENBQUN1QixNQUFuQixFQUEyQkcsV0FBM0IsR0FBdUMsRUFBdkM7QUFDQVAsTUFBQUEsRUFBRSxDQUFDRyxZQUFILENBQWdCdEIsRUFBRSxDQUFDdUIsTUFBbkIsRUFBMkJJLFVBQTNCLEdBQXNDLENBQXRDO0FBQ0g7O0FBQ0QsUUFBR1gsU0FBUyxJQUFFLENBQWQsRUFBZ0I7QUFDWkcsTUFBQUEsRUFBRSxDQUFDSyxjQUFILENBQWtCLEdBQWxCLEVBQXNCLEtBQUdWLGNBQWMsQ0FBQ1csTUFBbEIsR0FBeUIsRUFBL0M7QUFDQU4sTUFBQUEsRUFBRSxDQUFDRyxZQUFILENBQWdCdEIsRUFBRSxDQUFDdUIsTUFBbkIsRUFBMkJJLFVBQTNCLEdBQXNDLENBQXRDO0FBQ0FSLE1BQUFBLEVBQUUsQ0FBQ0csWUFBSCxDQUFnQnRCLEVBQUUsQ0FBQ3VCLE1BQW5CLEVBQTJCRyxXQUEzQixHQUF1QyxDQUF2QztBQUNIOztBQUVEMUIsSUFBQUEsRUFBRSxDQUFDNEIsUUFBSCxDQUFZQyxRQUFaLEdBQXVCQyxRQUF2QixDQUFnQ1gsRUFBaEM7QUFDQUYsSUFBQUEsVUFBVSxDQUFDYyxJQUFYLENBQWdCWixFQUFoQjtBQUNBLFFBQUlhLFFBQUo7O0FBQ0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUNuQixjQUFjLENBQUNXLE1BQTdCLEVBQW9DUSxDQUFDLEVBQXJDLEVBQXdDO0FBRXBDRCxNQUFBQSxRQUFRLEdBQUNoQyxFQUFFLENBQUNvQixXQUFILENBQWUsS0FBS2hCLFVBQXBCLENBQVQ7QUFDQWUsTUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlFLFFBQVosRUFBcUJDLENBQUMsR0FBQyxDQUF2QixFQUF5Qm5CLGNBQWMsQ0FBQ21CLENBQUQsQ0FBdkM7QUFDQUQsTUFBQUEsUUFBUSxDQUFDWCxNQUFULEdBQWdCLElBQWhCO0FBRUFXLE1BQUFBLFFBQVEsQ0FBQ0UsY0FBVCxDQUF3QixZQUF4QixFQUFzQ0EsY0FBdEMsQ0FBcUQsT0FBckQsRUFBOERaLFlBQTlELENBQTJFdEIsRUFBRSxDQUFDUyxLQUE5RSxFQUFxRjBCLE1BQXJGLEdBQTRGckIsY0FBYyxDQUFDbUIsQ0FBRCxDQUExRztBQUNBRCxNQUFBQSxRQUFRLENBQUNJLEVBQVQsQ0FBWSxPQUFaLEVBQW9CckIsT0FBTyxDQUFDa0IsQ0FBRCxDQUFQLENBQVdJLElBQVgsQ0FBZ0IsSUFBaEIsQ0FBcEI7QUFDQXBCLE1BQUFBLFVBQVUsQ0FBQ2MsSUFBWCxDQUFnQkMsUUFBaEI7QUFDSDs7QUFDRCxXQUFPZixVQUFQO0FBQ0gsR0ExREk7QUE2RExxQixFQUFBQSxPQTdESyxxQkE2REk7QUFDTCxTQUFLOUIsSUFBTCxDQUFVMkIsTUFBVixJQUFrQixDQUFsQjtBQUNILEdBL0RJLENBa0VMOztBQWxFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgc2lkZUJ1dHRvbjpjYy5Ob2RlLFxyXG4gICAgICAgIHNjZW5lOmNjLk5vZGUsXHJcbiAgICAgICAgbGF5b3V0OmNjLk5vZGUsXHJcbiAgICAgICAgdGVzdDpjYy5MYWJlbCxcclxuICAgICAgICBsYWJlbFg6MTAwLFxyXG4gICAgICAgIGxhYmVsWTozMDAsXHJcblxyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICAvLyB0aGlzLmxhYmVsWD0wO1xyXG4gICAgICAgIC8vIHRoaXMubGFiZWxZPTA7XHJcbiAgICAgICAgLy8gdmFyIGE9dGhpcy5jcmVhdGVOZXdUZW1wbGF0ZShbXCIxMjIyMjIyMjIyXCIsXCI0NTZcIixcIjc4OVwiXSxbdGhpcy5hZGRUZXN0LHRoaXMuYWRkVGVzdCx0aGlzLmFkZFRlc3RdLDApO1xyXG4gICAgICAgIC8vdmFyIGE9dGhpcy5jcmVhdGVOZXdUZW1wbGF0ZShbXCIxMjIyMjIyMjIyXCIsXCI0NTZcIl0sW3RoaXMuYWRkVGVzdCx0aGlzLmFkZFRlc3RdLDApO1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcblxyXG5cclxuICAgIGNyZWF0ZU5ld1RlbXBsYXRlKHNpZGVCdXR0b25MaXN0LGZ1bkxpc3Qsc3RhcnRBeGlzKXtcclxuICAgICAgICB2YXIgYnV0dG9uTGlzdD1uZXcgQXJyYXkoKTtcclxuICAgICAgICB2YXIgc2M9Y2MuaW5zdGFudGlhdGUodGhpcy5sYXlvdXQpO1xyXG4gICAgICAgIHNjLmFjdGl2ZT10cnVlO1xyXG4gICAgICAgIHNjLmdldENvbXBvbmVudChjYy5MYXlvdXQpLnN0YXJ0QXhpcz1zdGFydEF4aXM7XHJcbiAgICAgICAgaWYoc3RhcnRBeGlzPT0wKXtcclxuICAgICAgICAgICAgc2Muc2V0Q29udGVudFNpemUoMTUwKnNpZGVCdXR0b25MaXN0Lmxlbmd0aCs1MCw0MCk7XHJcbiAgICAgICAgICAgIHNjLmdldENvbXBvbmVudChjYy5MYXlvdXQpLnBhZGRpbmdMZWZ0PTUwO1xyXG4gICAgICAgICAgICBzYy5nZXRDb21wb25lbnQoY2MuTGF5b3V0KS5wYWRkaW5nVG9wPTA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHN0YXJ0QXhpcz09MSl7XHJcbiAgICAgICAgICAgIHNjLnNldENvbnRlbnRTaXplKDEwMCw2NSpzaWRlQnV0dG9uTGlzdC5sZW5ndGgrMzApO1xyXG4gICAgICAgICAgICBzYy5nZXRDb21wb25lbnQoY2MuTGF5b3V0KS5wYWRkaW5nVG9wPTA7XHJcbiAgICAgICAgICAgIHNjLmdldENvbXBvbmVudChjYy5MYXlvdXQpLnBhZGRpbmdMZWZ0PTA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldFNjZW5lKCkuYWRkQ2hpbGQoc2MpO1xyXG4gICAgICAgIGJ1dHRvbkxpc3QucHVzaChzYyk7XHJcbiAgICAgICAgdmFyIG5vZGVUZW1wO1xyXG4gICAgICAgIGZvcih2YXIgaT0wO2k8c2lkZUJ1dHRvbkxpc3QubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBub2RlVGVtcD1jYy5pbnN0YW50aWF0ZSh0aGlzLnNpZGVCdXR0b24pO1xyXG4gICAgICAgICAgICBzYy5hZGRDaGlsZChub2RlVGVtcCxpKzEsc2lkZUJ1dHRvbkxpc3RbaV0pO1xyXG4gICAgICAgICAgICBub2RlVGVtcC5hY3RpdmU9dHJ1ZTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIG5vZGVUZW1wLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZFwiKS5nZXRDaGlsZEJ5TmFtZShcIkxhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPXNpZGVCdXR0b25MaXN0W2ldO1xyXG4gICAgICAgICAgICBub2RlVGVtcC5vbignY2xpY2snLGZ1bkxpc3RbaV0uYmluZCh0aGlzKSk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxpc3QucHVzaChub2RlVGVtcCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBidXR0b25MaXN0O1xyXG4gICAgfSxcclxuXHJcblxyXG4gICAgYWRkVGVzdCgpe1xyXG4gICAgICAgIHRoaXMudGVzdC5zdHJpbmcrPTE7XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==