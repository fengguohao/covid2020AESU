
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/社区防疫/scripts/s_map.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ae395PdnplIy4LuPDAQFV3U', 's_map');
// 社区防疫/scripts/s_map.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    //这里处理各个按钮的事件
    s_globalParameter: cc.Node,
    num: 0,
    hospital: cc.Button,
    office: cc.Button,
    store: cc.Button,
    test: cc.Label,
    officeJs: cc.Node,
    hospitalJs: cc.Node,
    storeJs: cc.Node,
    stage: "null",
    retPanel: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    cc.director.resume(); //this.s_placeTemplate=this.s_placeTemplate.getComponent("s_placeTemplate");

    this.officeJs = this.officeJs.getComponent("s_office");
    this.hospitalJs = this.hospitalJs.getComponent("s_hospital");
    this.storeJs = this.storeJs.getComponent("s_store");
    console.log(this.hospital.node);
    this.hospital.node.runAction(cc.sequence(cc.scaleBy(1, 1.25), cc.scaleBy(1, 0.8)).repeat(6));
    this.store.node.runAction(cc.sequence(cc.scaleBy(1, 1.25), cc.scaleBy(1, 0.8)).repeat(6));
    this.office.node.runAction(cc.sequence(cc.scaleBy(1, 1.25), cc.scaleBy(1, 0.8)).repeat(6));
  },
  hospitalOnClick: function hospitalOnClick() {
    console.log('hospital :>> ');
    this.hospitalJs.showHospital();
    this.stage = "hospital";
  },
  officeOnClick: function officeOnClick() {
    console.log('office :>> ');
    this.officeJs.showOffice();
    this.stage = "office";
  },
  storeOnclick: function storeOnclick() {
    console.log('store :>> ');
    this.storeJs.showStore();
    this.stage = "store";
  },
  closeAll: function closeAll() {
    this.stage = "null";
  },
  update: function update(dt) {},
  returnButtonOnClick: function returnButtonOnClick() {
    cc.director.pause();
    this.retPanel.active = true;
  },
  cancelRet: function cancelRet() {
    this.retPanel.active = false;
    cc.director.resume();
  },
  exitForSure: function exitForSure() {
    cc.director.resume();
    cc.director.loadScene("衔接场景");
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xc56S+5Yy66Ziy55arXFxzY3JpcHRzXFxzX21hcC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNfZ2xvYmFsUGFyYW1ldGVyIiwiTm9kZSIsIm51bSIsImhvc3BpdGFsIiwiQnV0dG9uIiwib2ZmaWNlIiwic3RvcmUiLCJ0ZXN0IiwiTGFiZWwiLCJvZmZpY2VKcyIsImhvc3BpdGFsSnMiLCJzdG9yZUpzIiwic3RhZ2UiLCJyZXRQYW5lbCIsInN0YXJ0IiwiZGlyZWN0b3IiLCJyZXN1bWUiLCJnZXRDb21wb25lbnQiLCJjb25zb2xlIiwibG9nIiwibm9kZSIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwic2NhbGVCeSIsInJlcGVhdCIsImhvc3BpdGFsT25DbGljayIsInNob3dIb3NwaXRhbCIsIm9mZmljZU9uQ2xpY2siLCJzaG93T2ZmaWNlIiwic3RvcmVPbmNsaWNrIiwic2hvd1N0b3JlIiwiY2xvc2VBbGwiLCJ1cGRhdGUiLCJkdCIsInJldHVybkJ1dHRvbk9uQ2xpY2siLCJwYXVzZSIsImFjdGl2ZSIsImNhbmNlbFJldCIsImV4aXRGb3JTdXJlIiwibG9hZFNjZW5lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUjtBQUNBQyxJQUFBQSxpQkFBaUIsRUFBQ0osRUFBRSxDQUFDSyxJQUZiO0FBR1JDLElBQUFBLEdBQUcsRUFBQyxDQUhJO0FBSVJDLElBQUFBLFFBQVEsRUFBQ1AsRUFBRSxDQUFDUSxNQUpKO0FBS1JDLElBQUFBLE1BQU0sRUFBQ1QsRUFBRSxDQUFDUSxNQUxGO0FBTVJFLElBQUFBLEtBQUssRUFBQ1YsRUFBRSxDQUFDUSxNQU5EO0FBT1JHLElBQUFBLElBQUksRUFBQ1gsRUFBRSxDQUFDWSxLQVBBO0FBUVJDLElBQUFBLFFBQVEsRUFBQ2IsRUFBRSxDQUFDSyxJQVJKO0FBU1JTLElBQUFBLFVBQVUsRUFBQ2QsRUFBRSxDQUFDSyxJQVROO0FBVVJVLElBQUFBLE9BQU8sRUFBQ2YsRUFBRSxDQUFDSyxJQVZIO0FBV1JXLElBQUFBLEtBQUssRUFBQyxNQVhFO0FBWVJDLElBQUFBLFFBQVEsRUFBQ2pCLEVBQUUsQ0FBQ0s7QUFaSixHQUhQO0FBa0JMO0FBRUE7QUFFQWEsRUFBQUEsS0F0QkssbUJBc0JJO0FBQ0xsQixJQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlDLE1BQVosR0FESyxDQUVMOztBQUNBLFNBQUtQLFFBQUwsR0FBYyxLQUFLQSxRQUFMLENBQWNRLFlBQWQsQ0FBMkIsVUFBM0IsQ0FBZDtBQUNBLFNBQUtQLFVBQUwsR0FBZ0IsS0FBS0EsVUFBTCxDQUFnQk8sWUFBaEIsQ0FBNkIsWUFBN0IsQ0FBaEI7QUFDQSxTQUFLTixPQUFMLEdBQWEsS0FBS0EsT0FBTCxDQUFhTSxZQUFiLENBQTBCLFNBQTFCLENBQWI7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBS2hCLFFBQUwsQ0FBY2lCLElBQTFCO0FBQ0EsU0FBS2pCLFFBQUwsQ0FBY2lCLElBQWQsQ0FBbUJDLFNBQW5CLENBQTZCekIsRUFBRSxDQUFDMEIsUUFBSCxDQUFZMUIsRUFBRSxDQUFDMkIsT0FBSCxDQUFXLENBQVgsRUFBYSxJQUFiLENBQVosRUFBK0IzQixFQUFFLENBQUMyQixPQUFILENBQVcsQ0FBWCxFQUFhLEdBQWIsQ0FBL0IsRUFBa0RDLE1BQWxELENBQXlELENBQXpELENBQTdCO0FBQ0EsU0FBS2xCLEtBQUwsQ0FBV2MsSUFBWCxDQUFnQkMsU0FBaEIsQ0FBMEJ6QixFQUFFLENBQUMwQixRQUFILENBQVkxQixFQUFFLENBQUMyQixPQUFILENBQVcsQ0FBWCxFQUFhLElBQWIsQ0FBWixFQUErQjNCLEVBQUUsQ0FBQzJCLE9BQUgsQ0FBVyxDQUFYLEVBQWEsR0FBYixDQUEvQixFQUFrREMsTUFBbEQsQ0FBeUQsQ0FBekQsQ0FBMUI7QUFDQSxTQUFLbkIsTUFBTCxDQUFZZSxJQUFaLENBQWlCQyxTQUFqQixDQUEyQnpCLEVBQUUsQ0FBQzBCLFFBQUgsQ0FBWTFCLEVBQUUsQ0FBQzJCLE9BQUgsQ0FBVyxDQUFYLEVBQWEsSUFBYixDQUFaLEVBQStCM0IsRUFBRSxDQUFDMkIsT0FBSCxDQUFXLENBQVgsRUFBYSxHQUFiLENBQS9CLEVBQWtEQyxNQUFsRCxDQUF5RCxDQUF6RCxDQUEzQjtBQUNILEdBaENJO0FBb0NMQyxFQUFBQSxlQXBDSyw2QkFvQ1k7QUFDZFAsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWjtBQUNBLFNBQUtULFVBQUwsQ0FBZ0JnQixZQUFoQjtBQUNBLFNBQUtkLEtBQUwsR0FBVyxVQUFYO0FBQ0YsR0F4Q0k7QUEyQ0xlLEVBQUFBLGFBM0NLLDJCQTJDVTtBQUNYVCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0EsU0FBS1YsUUFBTCxDQUFjbUIsVUFBZDtBQUNBLFNBQUtoQixLQUFMLEdBQVcsUUFBWDtBQUNILEdBL0NJO0FBaURMaUIsRUFBQUEsWUFqREssMEJBaURTO0FBQ1ZYLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVo7QUFDQSxTQUFLUixPQUFMLENBQWFtQixTQUFiO0FBQ0EsU0FBS2xCLEtBQUwsR0FBVyxPQUFYO0FBQ0gsR0FyREk7QUF1RExtQixFQUFBQSxRQXZESyxzQkF1REs7QUFDTixTQUFLbkIsS0FBTCxHQUFXLE1BQVg7QUFDSCxHQXpESTtBQTBESm9CLEVBQUFBLE1BMURJLGtCQTBESUMsRUExREosRUEwRFEsQ0FFWCxDQTVERztBQWdFSkMsRUFBQUEsbUJBaEVJLGlDQWdFaUI7QUFDbEJ0QyxJQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlvQixLQUFaO0FBQ0EsU0FBS3RCLFFBQUwsQ0FBY3VCLE1BQWQsR0FBcUIsSUFBckI7QUFDRixHQW5FRztBQXFFSkMsRUFBQUEsU0FyRUksdUJBcUVPO0FBQ1IsU0FBS3hCLFFBQUwsQ0FBY3VCLE1BQWQsR0FBcUIsS0FBckI7QUFDQXhDLElBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWUMsTUFBWjtBQUNGLEdBeEVHO0FBeUVKc0IsRUFBQUEsV0F6RUkseUJBeUVTO0FBQ1YxQyxJQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlDLE1BQVo7QUFDQXBCLElBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWXdCLFNBQVosQ0FBc0IsTUFBdEI7QUFDRjtBQTVFRyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy/ov5nph4zlpITnkIblkITkuKrmjInpkq7nmoTkuovku7ZcclxuICAgICAgICBzX2dsb2JhbFBhcmFtZXRlcjpjYy5Ob2RlLFxyXG4gICAgICAgIG51bTowLFxyXG4gICAgICAgIGhvc3BpdGFsOmNjLkJ1dHRvbixcclxuICAgICAgICBvZmZpY2U6Y2MuQnV0dG9uLFxyXG4gICAgICAgIHN0b3JlOmNjLkJ1dHRvbixcclxuICAgICAgICB0ZXN0OmNjLkxhYmVsLFxyXG4gICAgICAgIG9mZmljZUpzOmNjLk5vZGUsXHJcbiAgICAgICAgaG9zcGl0YWxKczpjYy5Ob2RlLFxyXG4gICAgICAgIHN0b3JlSnM6Y2MuTm9kZSxcclxuICAgICAgICBzdGFnZTpcIm51bGxcIixcclxuICAgICAgICByZXRQYW5lbDpjYy5Ob2RlXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IucmVzdW1lKCk7XHJcbiAgICAgICAgLy90aGlzLnNfcGxhY2VUZW1wbGF0ZT10aGlzLnNfcGxhY2VUZW1wbGF0ZS5nZXRDb21wb25lbnQoXCJzX3BsYWNlVGVtcGxhdGVcIik7XHJcbiAgICAgICAgdGhpcy5vZmZpY2VKcz10aGlzLm9mZmljZUpzLmdldENvbXBvbmVudChcInNfb2ZmaWNlXCIpO1xyXG4gICAgICAgIHRoaXMuaG9zcGl0YWxKcz10aGlzLmhvc3BpdGFsSnMuZ2V0Q29tcG9uZW50KFwic19ob3NwaXRhbFwiKTtcclxuICAgICAgICB0aGlzLnN0b3JlSnM9dGhpcy5zdG9yZUpzLmdldENvbXBvbmVudChcInNfc3RvcmVcIik7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5ob3NwaXRhbC5ub2RlKTtcclxuICAgICAgICB0aGlzLmhvc3BpdGFsLm5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLnNjYWxlQnkoMSwxLjI1KSxjYy5zY2FsZUJ5KDEsMC44KSkucmVwZWF0KDYpKTtcclxuICAgICAgICB0aGlzLnN0b3JlLm5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLnNjYWxlQnkoMSwxLjI1KSxjYy5zY2FsZUJ5KDEsMC44KSkucmVwZWF0KDYpKTtcclxuICAgICAgICB0aGlzLm9mZmljZS5ub2RlLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShjYy5zY2FsZUJ5KDEsMS4yNSksY2Muc2NhbGVCeSgxLDAuOCkpLnJlcGVhdCg2KSk7XHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG4gICAgaG9zcGl0YWxPbkNsaWNrKCl7XHJcbiAgICAgICBjb25zb2xlLmxvZygnaG9zcGl0YWwgOj4+ICcpO1xyXG4gICAgICAgdGhpcy5ob3NwaXRhbEpzLnNob3dIb3NwaXRhbCgpO1xyXG4gICAgICAgdGhpcy5zdGFnZT1cImhvc3BpdGFsXCI7XHJcbiAgICB9LFxyXG4gICAgXHJcblxyXG4gICAgb2ZmaWNlT25DbGljaygpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvZmZpY2UgOj4+ICcpO1xyXG4gICAgICAgIHRoaXMub2ZmaWNlSnMuc2hvd09mZmljZSgpO1xyXG4gICAgICAgIHRoaXMuc3RhZ2U9XCJvZmZpY2VcIjtcclxuICAgIH0sXHJcblxyXG4gICAgc3RvcmVPbmNsaWNrKCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3N0b3JlIDo+PiAnKTtcclxuICAgICAgICB0aGlzLnN0b3JlSnMuc2hvd1N0b3JlKCk7XHJcbiAgICAgICAgdGhpcy5zdGFnZT1cInN0b3JlXCI7XHJcbiAgICB9LFxyXG5cclxuICAgIGNsb3NlQWxsKCl7XHJcbiAgICAgICAgdGhpcy5zdGFnZT1cIm51bGxcIjtcclxuICAgIH0sXHJcbiAgICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIFxyXG4gICAgIH0sXHJcblxyXG5cclxuXHJcbiAgICAgcmV0dXJuQnV0dG9uT25DbGljaygpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLnBhdXNlKCk7XHJcbiAgICAgICAgdGhpcy5yZXRQYW5lbC5hY3RpdmU9dHJ1ZTtcclxuICAgICB9LFxyXG5cclxuICAgICBjYW5jZWxSZXQoKXtcclxuICAgICAgICB0aGlzLnJldFBhbmVsLmFjdGl2ZT1mYWxzZTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5yZXN1bWUoKTtcclxuICAgICB9LFxyXG4gICAgIGV4aXRGb3JTdXJlKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IucmVzdW1lKCk7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwi6KGU5o6l5Zy65pmvXCIpO1xyXG4gICAgIH1cclxufSk7XHJcbiJdfQ==