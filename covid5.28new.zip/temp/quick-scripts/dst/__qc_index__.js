
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/个人防护/scripts/AudioMgr');
require('./assets/个人防护/scripts/UIcontrol');
require('./assets/个人防护/scripts/buttonConfirmJS');
require('./assets/个人防护/scripts/closestoolJS');
require('./assets/个人防护/scripts/conveyInformation');
require('./assets/个人防护/scripts/gamePlayer');
require('./assets/个人防护/scripts/handWashingSinkJS');
require('./assets/个人防护/scripts/informationJS');
require('./assets/个人防护/scripts/judgeFailOrSucceed');
require('./assets/个人防护/scripts/neighborJS');
require('./assets/个人防护/scripts/neighborMoveJS');
require('./assets/个人防护/scripts/npc');
require('./assets/个人防护/scripts/oppositeOnceJS');
require('./assets/个人防护/scripts/oppositeTwiceJS');
require('./assets/个人防护/scripts/propTool');
require('./assets/个人防护/scripts/sameOnceJS');
require('./assets/个人防护/scripts/sameTwiceJS');
require('./assets/个人防护/scripts/showPossibility');
require('./assets/个人防护/scripts/showTime');
require('./assets/人体免疫/scripts/TCytotoxicCell');
require('./assets/人体免疫/scripts/THelperCell');
require('./assets/人体免疫/scripts/antiviral');
require('./assets/人体免疫/scripts/bianxing');
require('./assets/人体免疫/scripts/biaoji');
require('./assets/人体免疫/scripts/bozhong');
require('./assets/人体免疫/scripts/fashe');
require('./assets/人体免疫/scripts/gameControl');
require('./assets/人体免疫/scripts/huohua');
require('./assets/人体免疫/scripts/jingong');
require('./assets/人体免疫/scripts/jujue');
require('./assets/人体免疫/scripts/juxing');
require('./assets/人体免疫/scripts/ningju');
require('./assets/人体免疫/scripts/piao');
require('./assets/人体免疫/scripts/qiehuan');
require('./assets/人体免疫/scripts/showCoolingTime');
require('./assets/人体免疫/scripts/showDeadNormalCell');
require('./assets/人体免疫/scripts/sun');
require('./assets/人体免疫/scripts/tujian');
require('./assets/人体免疫/scripts/zou');
require('./assets/家园/script/jiayuanCtrl');
require('./assets/疫苗研制/script/y_fencengControl');
require('./assets/疫苗研制/script/y_item');
require('./assets/疫苗研制/script/y_itemControl');
require('./assets/疫苗研制/script/y_liejieControl');
require('./assets/疫苗研制/script/y_pcrMachine');
require('./assets/疫苗研制/script/y_safeBox');
require('./assets/疫苗研制/script/y_sceneController');
require('./assets/疫苗研制/script/y_thawControl');
require('./assets/疫苗研制/script/y_thawSecond');
require('./assets/疫苗研制/script/y_zhendangyi');
require('./assets/社区防疫/scripts/s_globalParameter');
require('./assets/社区防疫/scripts/s_hospital');
require('./assets/社区防疫/scripts/s_map');
require('./assets/社区防疫/scripts/s_office');
require('./assets/社区防疫/scripts/s_placeTemplate');
require('./assets/社区防疫/scripts/s_store');
require('./assets/社区防疫/结算页/s_jiesuan');
require('./assets/衔接场景/scripts/tempJs');
require('./assets/衔接场景/scripts/yidao');
require('./assets/谣言破除/script/r_bar');
require('./assets/谣言破除/script/r_contentCtrl');
require('./assets/谣言破除/script/r_globalStage');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();