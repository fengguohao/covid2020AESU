"use strict";
cc._RF.push(module, '64d9dxW3uNGXLXgQ78vpQKu', 'yidao');
// 衔接场景/script/yidao.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    yindao: cc.Node,
    bar: cc.Button,
    picPlace: cc.Sprite,
    message: cc.Label,
    sheqv: cc.SpriteFrame
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  showPanel: function showPanel(frame, message) {
    this.yindao.active = true;
    this.picPlace.spriteFrame = frame;
    this.message.string = message;
  },
  sheqvOnClick: function sheqvOnClick() {
    this.showPanel(this.sheqv, "快来社区帮我们控制疫情吧！(点此继续)");
    this.bar.node.on("click", function () {
      cc.director.loadScene("社区防疫");
    }, this);
  } // update (dt) {},

});

cc._RF.pop();