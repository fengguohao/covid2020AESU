"use strict";
cc._RF.push(module, 'fd6a2UATrtEZYGXQUeHr87g', 'y_safeBox');
// 疫苗研制/script/y_safeBox.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    if (other.node.name == "样品毒株") {
      console.log('other :>> ', other);
      this.node.parent.getComponent("y_thawSecond").putFinished(other);
    }
  } // update (dt) {},

});

cc._RF.pop();