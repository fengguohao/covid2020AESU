"use strict";
cc._RF.push(module, 'af56coCf9BPTYCTdF3Ob/tP', 'showTime');
// 火车防护/scripts/showTime.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.time = 0;
    var func = cc.callFunc(function () {
      this.time++;
    }.bind(this));
    var remain = cc.fadeTo(1, 255);
    this.node.runAction(cc.sequence([remain, func])).repeatForever();
  },
  start: function start() {},
  update: function update(dt) {
    var l = this.node.getComponent(cc.Label);
    l.string = "用时：" + this.time + "秒";
  }
});

cc._RF.pop();