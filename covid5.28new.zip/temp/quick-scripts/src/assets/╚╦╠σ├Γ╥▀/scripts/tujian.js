"use strict";
cc._RF.push(module, 'ef7a7af37JMM69x6bhVlkCA', 'tujian');
// 人体免疫/scripts/tujian.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    mySprite: cc.Sprite,
    myAtlas: cc.SpriteAtlas
  },
  // LIFE-CYCLE CALLBACKS:
  //onLoad () {},
  click1: function click1() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('NK介绍');
  },
  click2: function click2() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('WBC介绍');
  },
  click3: function click3() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('巨噬细胞介绍');
  },
  click4: function click4() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('树突状细胞介绍');
  },
  click5: function click5() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('B细胞介绍');
  },
  click6: function click6() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('T细胞介绍');
  },
  click7: function click7() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('辅助T细胞介绍');
  },
  click8: function click8() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞毒性T细胞介绍');
  },
  click9: function click9() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞因子介绍');
  },
  click10: function click10() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('抗病毒药物');
  },
  click11: function click11() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('细胞因子抑制剂介绍');
  },
  click12: function click12() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('病毒介绍');
  },
  click13: function click13() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('感染细胞介绍');
  },
  click14: function click14() {
    this.mySprite.spriteFrame = this.myAtlas.getSpriteFrame('规则介绍');
  },
  click15: function click15() {
    cc.director.loadScene("人体免疫(总)");
  },
  start: function start() {} //update (dt) { this.click2;},

});

cc._RF.pop();